"""
hotel_api.py
============
Wrapper asíncrono sobre la API web del hotel (Base44).
Centraliza todas las llamadas HTTP para que el bot no toque
directamente aiohttp/requests en ningún otro archivo.

Uso:
    api = HotelAPI()
    rooms = await api.get_rooms(status="available")
"""

from __future__ import annotations

import os
import logging
from typing import Any, Dict, List, Optional

import aiohttp

logger = logging.getLogger("hotel_api")

# ── Configuración desde entorno ──────────────────────────────
API_BASE_URL = os.getenv(
    "BASE44_API_URL",
    "https://von-stay-luxe-revo-rp.base44.app/api",
)
API_KEY = os.getenv("BASE44_API_KEY", "6610a6a2ffe14ef29500c004c81cc63c")
APP_ID = os.getenv("BASE44_APP_ID", "6a0dfa64e37bba86acbfb7ee")

DEFAULT_HEADERS = {
    "api_key": API_KEY,
    "Content-Type": "application/json",
}

# Mapping nombre interno entidad → nombre plural en la API
ENTITY_PLURAL = {
    "reservation": "reservations",
    "room": "rooms",
    "guest": "guests",
    "notification": "notifications",
}


class HotelAPIError(Exception):
    """Error devuelto por la API del hotel."""

    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message
        super().__init__(f"[{status}] {message}")


class HotelAPI:
    """Cliente asíncrono de la API del hotel Von Stay Luxe Revo RP."""

    def __init__(
        self,
        base_url: str = API_BASE_URL,
        api_key: str = API_KEY,
        app_id: str = APP_ID,
    ):
        self.base_url = base_url.rstrip("/")
        self.app_id = app_id
        self.headers = {
            "api_key": api_key,
            "Content-Type": "application/json",
        }

    # ── Helpers internos ──────────────────────────────────────
    def _url(self, entity: str, resource_id: Optional[str] = None) -> str:
        plural = ENTITY_PLURAL.get(entity, f"{entity}s")
        url = f"{self.base_url}/{plural}"
        if resource_id:
            url += f"/{resource_id}"
        return url

    async def _request(
        self,
        method: str,
        entity: str,
        resource_id: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
    ) -> Any:
        url = self._url(entity, resource_id)
        logger.debug("%s %s params=%s json=%s", method, url, params, json_data)
        try:
            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.request(
                    method,
                    url,
                    params=params,
                    json=json_data,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    text = await resp.text()
                    if resp.status >= 400:
                        logger.error("API error %s: %s", resp.status, text[:300])
                        raise HotelAPIError(resp.status, text[:500])
                    if not text:
                        return None
                    try:
                        return await resp.json()
                    except aiohttp.ContentTypeError:
                        return text
        except aiohttp.ClientError as exc:
            logger.error("Network error: %s", exc)
            raise HotelAPIError(0, str(exc)) from exc

    # ── RESERVATIONS ──────────────────────────────────────────
    async def get_reservations(
        self,
        discord_user: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Lista reservas, opcionalmente filtradas por usuario o estado."""
        params: Dict[str, Any] = {}
        if discord_user:
            params["discord_user"] = discord_user
        if status:
            params["status"] = status
        data = await self._request("GET", "reservation", params=params)
        if isinstance(data, dict) and "data" in data:
            return data["data"]
        return data if isinstance(data, list) else []

    async def get_reservation(self, reservation_id: str) -> Dict[str, Any]:
        return await self._request("GET", "reservation", resource_id=reservation_id)

    async def create_reservation(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Crea una reserva (status por defecto 'pending')."""
        payload = {
            "room_id": data.get("room_id"),
            "check_in": data.get("check_in"),
            "check_out": data.get("check_out"),
            "guests": data.get("guests", 1),
            "discord_user": data.get("discord_user"),
            "rp_name": data.get("rp_name"),
            "room_type": data.get("room_type", "standard"),
            "status": data.get("status", "pending"),
            "comments": data.get("comments", ""),
        }
        logger.info("Creando reserva para %s", payload.get("rp_name"))
        return await self._request("POST", "reservation", json_data=payload)

    async def update_reservation(
        self, reservation_id: str, data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Actualiza una reserva (aceptar, rechazar, check-in, etc.)."""
        logger.info("Actualizando reserva %s: %s", reservation_id, data)
        return await self._request(
            "PUT", "reservation", resource_id=reservation_id, json_data=data
        )

    async def cancel_reservation(self, reservation_id: str) -> Dict[str, Any]:
        return await self.update_reservation(reservation_id, {"status": "cancelled"})

    # ── ROOMS ─────────────────────────────────────────────────
    async def get_rooms(
        self,
        type: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        params: Dict[str, Any] = {}
        if type:
            params["type"] = type
        if status:
            params["status"] = status
        data = await self._request("GET", "room", params=params)
        if isinstance(data, dict) and "data" in data:
            return data["data"]
        return data if isinstance(data, list) else []

    async def get_room(self, room_id: str) -> Dict[str, Any]:
        return await self._request("GET", "room", resource_id=room_id)

    async def update_room(self, room_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        return await self._request("PUT", "room", resource_id=room_id, json_data=data)

    # ── GUESTS ────────────────────────────────────────────────
    async def get_guest(self, discord_id: str) -> Optional[Dict[str, Any]]:
        """Busca un huésped por discord_id (id exacto)."""
        data = await self._request("GET", "guest", params={"discord_id": discord_id})
        if isinstance(data, list) and data:
            return data[0]
        if isinstance(data, dict) and not data.get("error"):
            return data
        return None

    async def get_guest_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        data = await self._request("GET", "guest", params={"username": username})
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def create_guest(self, data: Dict[str, Any]) -> Dict[str, Any]:
        payload = {
            "discord_id": data.get("discord_id"),
            "username": data.get("username"),
            "rp_name": data.get("rp_name"),
            "phone": data.get("phone", ""),
            "vip_level": data.get("vip_level", "normal"),
            "notes": data.get("notes", ""),
            "total_spent": data.get("total_spent", 0),
        }
        logger.info("Creando huésped %s", payload.get("rp_name"))
        return await self._request("POST", "guest", json_data=payload)

    async def update_guest(
        self, guest_id: str, data: Dict[str, Any]
    ) -> Dict[str, Any]:
        return await self._request("PUT", "guest", resource_id=guest_id, json_data=data)

    # ── NOTIFICATIONS ─────────────────────────────────────────
    async def send_notification(
        self,
        title: str,
        message: str,
        type: str = "general",
        link: str = "",
    ) -> Dict[str, Any]:
        payload = {
            "title": title,
            "message": message,
            "type": type,
            "read": False,
            "link": link,
        }
        logger.info("Notificación enviada: %s", title)
        return await self._request("POST", "notification", json_data=payload)

    # ── DIAGNÓSTICOS ──────────────────────────────────────────
    async def room_diagnostics(self, room_id: str) -> Dict[str, Any]:
        """
        Genera un diagnóstico completo de una habitación combinando
        datos de la Room + métricas + alertas.
        """
        room = await self.get_room(room_id)
        if not room:
            return {"error": f"Habitación {room_id} no encontrada"}

        diagnostics: Dict[str, Any] = {
            "room": room,
            "reservation_count": room.get("reservation_count", 0),
            "status": room.get("status", "unknown"),
            "type": room.get("type", "unknown"),
            "price": room.get("price", 0),
            "capacity": room.get("capacity", 0),
            "assigned_guest": room.get("assigned_guest"),
            "amenities": room.get("amenities", []),
            "alerts": [],
        }

        # Alertas automáticas
        if room.get("status") == "maintenance":
            diagnostics["alerts"].append("🔧 Habitación en mantenimiento")
        if room.get("status") == "occupied" and not room.get("assigned_guest"):
            diagnostics["alerts"].append(
                "⚠️ Habitación ocupada sin huésped asignado"
            )
        if room.get("reservation_count", 0) == 0:
            diagnostics["alerts"].append("📊 Sin reservas históricas")
        if room.get("capacity", 0) > 0 and room.get("status") == "available":
            diagnostics["alerts"].append("✅ Disponible para reservar")

        return diagnostics
