"""
ai_responder.py
================
Sistema de respuestas conversacionales del bot.

Funciona con OpenAI si hay API key (OPENAI_API_KEY), y si no,
usa un motor de respuestas predefinidas inteligentes que detecta
intenciones y genera mensajes naturales en español.

Personalidad: recepcionista de hotel 5 estrellas de roleplay.
"""

from __future__ import annotations

import logging
import os
import re
from typing import Any, Dict, Optional, Tuple

import discord

logger = logging.getLogger("ai_responder")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# ── Personalidad del bot ──────────────────────────────────────
SYSTEM_PROMPT = (
    "Eres Lucía, la recepcionista del Von Stay Luxe Revo RP, un hotel de "
    "cinco estrellas de roleplay. Hablas español de forma amable, profesional "
    "y cercana. Usas emojis de hotel (🏨 🛎️ 🗝️ 🛏️) con moderación. "
    "Responde de forma breve y clara. Si alguien quiere reservar, "
    "indícale que use /reservar o dile que puedes iniciar el proceso. "
    "Si pregunta por habitaciones, precios o estado, ayúdale. "
    "Mantén el tono de roleplay en todo momento."
)

# ── Detección de intenciones ──────────────────────────────────
INTENT_PATTERNS: Dict[str, list] = {
    # Order matters: estado/cancelar checked before reservar so that
    # "mi reserva" / "cancelar reserva" don't match the verb pattern.
    "estado": [
        r"\b(estado\s+de\s+mi\s+reserva|c[oó]mo\s+va\s+mi\s+reserva|mi\s+reserva|ver\s+mi\s+reserva|status\s+of\s+my)",
    ],
    "cancelar": [
        r"\b(cancelar?|anular|deshacer\s+(la\s+)?reserva|cancel\s+reservation)",
    ],
    "reservar": [
        r"\b(reservar|reservo|reservarme|quiero\s+reservar|quiero\s+una?\s+habitaci[oó]n|hacer\s+una?\s+reserva|book(?:ing)?\s+(?:a|room))",
    ],
    "precio": [
        r"\b(precio|cu[aá]nto\s+cuesta|cu[aá]nto\s+vale|tarifa|cost[ae]|rate|price)",
    ],
    "habitaciones": [
        r"\b(habitaciones\s+disponibles?|qu[eé]\s+habitaciones|ver\s+habitaciones|rooms?\s+available|available\s+rooms)",
    ],
    "saludo": [
        r"^(hola|buenas|buenos\s+d[ií]as|buenas\s+tardes|buenas\s+noches|hi|hello|hey)[\s!¡,.]*$",
    ],
    "gracias": [
        r"\b(gracias|muchas\s+gracias|thank|thx)\b",
    ],
    "despedida": [
        r"\b(adi[oó]s|chao|hasta\s+luego|nos\s+vemos|bye|goodbye)\b",
    ],
    "info_hotel": [
        r"\b(d[oó]nde\s+est[aá]\s+el\s+hotel|d[oó]nde\s+estais|ubicaci[oó]n|direcci[oó]n|servicios|spa|piscina|gimnasio|desayuno|restaurant|wifi)",
    ],
    "checkin": [
        r"\b(check[- ]?in|entrada|cu[aá]ndo\s+puedo\s+entrar|hora\s+de\s+entrada)",
    ],
    "checkout": [
        r"\b(check[- ]?out|salida|hora\s+de\s+salida|dejar\s+la\s+habitaci[oó]n)",
    ],
}


def detect_intent(message: str) -> str:
    """Detecta la intención del mensaje del usuario."""
    msg_lower = message.lower().strip()
    for intent, patterns in INTENT_PATTERNS.items():
        for pat in patterns:
            if re.search(pat, msg_lower):
                return intent
    return "general"


# ── Respuestas predefinidas ───────────────────────────────────
PREDEFINED_RESPONSES: Dict[str, str] = {
    "reservar": (
        "🏨 ¡Por supuesto! Me encantaría ayudarte a reservar una habitación. "
        "Puedes iniciar el proceso con el comando **/reservar** o decirme "
        "que quieres empezar y te guiaré paso a paso. 🛎️"
    ),
    "cancelar": (
        "Entiendo que quieres cancelar tu reserva. Puedes usar el comando "
        "**/cancelar** y buscaré tu reserva para cancelarla. "
        "¿Quieres que proceda? 🗝️"
    ),
    "precio": (
        "💰 Estas son nuestras tarifas por noche:\n"
        "• 🛏️ **Standard** — 70€\n"
        "• 🌟 **Deluxe** — 140€\n"
        "• 🏨 **Suite** — 250€\n"
        "• 👑 **VIP** — 500€\n\n"
        "Todas incluyen desayuno y acceso a nuestras instalaciones. "
        "¿Te interesa algún tipo en concreto? 🛎️"
    ),
    "habitaciones": (
        "🏷️ Puedes ver todas las habitaciones disponibles con el comando "
        "**/habitaciones**. Te mostraré las que están libres ahora mismo "
        "con sus precios y amenidades. ¿Quieres verlas? 🏨"
    ),
    "estado": (
        "🔍 Para revisar el estado de tu reserva, usa el comando **/estado**. "
        "Buscaré tu reserva por tu usuario de Discord y te diré en qué "
        "punto está. ⏳"
    ),
    "saludo": (
        "🏨 ¡Hola! Bienvenido al **Von Stay Luxe Revo RP**. "
        "Soy Lucía, su recepcionista. ¿En qué puedo ayudarle hoy? 🛎️"
    ),
    "gracias": (
        "¡Ha sido un placer! Estoy aquí para lo que necesite. "
        "Que tenga una excelente estancia. 🛎️✨"
    ),
    "despedida": (
        "¡Hasta pronto! Esperamos verle de nuevo en el Von Stay Luxe. "
        "¡Que tenga un wonderful día! 🏨👋"
    ),
    "info_hotel": (
        "🏨 El **Von Stay Luxe Revo RP** ofrece:\n"
        "• 🍽️ Restaurante gourmet con desayuno incluido\n"
        "• 💆 Spa y zona de bienestar\n"
        "• 🏊 Piscina climatizada\n"
        "• 💪 Gimnasio 24h\n"
        "• 📶 WiFi premium en todas las habitaciones\n"
        "• 🛎️ Servicio de habitaciones 24/7\n\n"
        "¿Le interesa algo en particular? ✨"
    ),
    "checkin": (
        "🛎️ El **check-in** está disponible a partir de las **15:00 h**. "
        "Si llega antes, podemos guardar su equipaje en conserjería mientras "
        "preparamos su habitación. 🗝️"
    ),
    "checkout": (
        "🗝️ El **check-out** es hasta las **12:00 h** del mediodía. "
        "Si necesita más tiempo, podemos ofrecerle un late check-out "
        "sujeto a disponibilidad. 🛏️"
    ),
    "general": (
        "Entiendo. Como recepcionista del Von Stay Luxe Revo RP, puedo "
        "ayudarle con:\n"
        "• 🏨 **Reservar** una habitación → `/reservar`\n"
        "• 📋 **Verificar** su reserva → `/estado`\n"
        "• 🚪 **Cancelar** una reserva → `/cancelar`\n"
        "• 🗝️ **Habitaciones** disponibles → `/habitaciones`\n"
        "• 🩺 **Diagnóstico** de una habitación → `/diagnostico`\n\n"
        "¿Qué le gustaría hacer? 🛎️"
    ),
}


# ── Generador de respuestas ───────────────────────────────────
async def generate_response(
    message: str,
    user_name: str,
    api: Optional[Any] = None,
) -> Tuple[str, str]:
    """
    Genera una respuesta conversacional.
    Devuelve (respuesta_texto, intent_detectado).

    Usa OpenAI si hay API key; si no, usa respuestas predefinidas.
    """
    intent = detect_intent(message)

    # ── Intentar OpenAI ──
    if OPENAI_API_KEY:
        try:
            response_text = await _openai_response(message, user_name)
            return response_text, intent
        except Exception as exc:
            logger.warning("OpenAI fallback: %s", exc)

    # ── Fallback: respuestas predefinidas ──
    response = PREDEFINED_RESPONSES.get(intent, PREDEFINED_RESPONSES["general"])

    # Personalización ligera
    if intent == "saludo":
        response = response.replace("¡Hola!", f"¡Hola, {user_name}!")

    return response, intent


async def _openai_response(message: str, user_name: str) -> str:
    """Llama a la API de OpenAI (Chat Completions) con aiohttp."""
    import aiohttp

    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"[Usuario: {user_name}] {message}",
            },
        ],
        "max_tokens": 300,
        "temperature": 0.7,
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(
            url, json=payload, headers=headers,
            timeout=aiohttp.ClientTimeout(total=20),
        ) as resp:
            if resp.status != 200:
                raise Exception(f"OpenAI {resp.status}: {await resp.text()}")
            data = await resp.json()
            return data["choices"][0]["message"]["content"].strip()


def intent_to_embed(text: str, intent: str) -> discord.Embed:
    """Convierte una respuesta de texto en un embed de Discord coloreado."""
    color_map = {
        "reservar": discord.Color.blue(),
        "cancelar": discord.Color.red(),
        "precio": discord.Color.gold(),
        "habitaciones": discord.Color.blue(),
        "estado": discord.Color.gold(),
        "saludo": discord.Color.green(),
        "gracias": discord.Color.green(),
        "despedida": discord.Color.green(),
        "info_hotel": discord.Color.blue(),
        "checkin": discord.Color.blue(),
        "checkout": discord.Color.blue(),
    }
    color = color_map.get(intent, discord.Color.blue())

    title_map = {
        "reservar": "🏨 Reserva",
        "cancelar": "❌ Cancelar",
        "precio": "💰 Tarifas",
        "habitaciones": "🚪 Habitaciones",
        "estado": "📋 Estado de Reserva",
        "saludo": "🛎️ Recepción",
        "gracias": "✨ De nada",
        "despedida": "👋 Hasta pronto",
        "info_hotel": "🏨 Von Stay Luxe",
        "checkin": "🛎️ Check-in",
        "checkout": "🗝️ Check-out",
        "general": "🏨 Recepción",
    }
    title = title_map.get(intent, "🏨 Recepción")

    embed = discord.Embed(title=title, description=text, color=color)
    embed.set_footer(text="Von Stay Luxe Revo RP · Recepción")
    return embed
