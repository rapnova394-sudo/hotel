"""
Von Stay Luxe Revo RP - Bot de Discord
======================================
Recepcionista IA para el hotel de roleplay "Von Crastenburg Hotel".
Bot completo con todos los slash commands de moderacion, hotel, huespedes,
IA / asistente y entretenimiento.

Despliegue: Railway (worker: python bot.py)
"""

from __future__ import annotations

import logging
import os
import random
import re
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from hotel_api import HotelAPI, HotelAPIError
from flows import (
    ReservationFlow,
    get_state, set_state, clear_state, has_active_flow,
)

# --- LOGGING ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("bot.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("bot")

# --- CONFIG ---
TOKEN = os.environ.get("DISCORD_BOT_TOKEN_FULL") or os.environ.get("DISCORD_BOT_TOKEN")
if not TOKEN:
    log.error("Token de Discord no encontrado (DISCORD_BOT_TOKEN_FULL)")
    sys.exit(1)

GUILD_ID = 1506350276582572224

# Canales del servidor
CH_TICKETS = 1524002883765538886
CH_RESERVAS = 1506357445176459395
CH_GENERAL = 1524363027271647292
CH_CONFIRMADAS = 1506357585186394163
CH_RECHAZADAS = 1506357615494692914
CH_ESTADO_HABITACIONES = 1506357655772463275
CH_STAFF = 1506357770171973722
CH_INCIDENCIAS = 1506357920084918312
CH_TURNOS = 1506357812203360517
CH_LIMPIEZA = 1506357885163147344
CH_SOLICITUDES_TRABAJO = 1506357953978961961
CH_PAGOS = 1506358113006129325

CH_RESERVAS_PENDIENTES = CH_RESERVAS
CH_RESERVAS_CONFIRMADAS = CH_CONFIRMADAS
CH_RESERVAS_RECHAZADAS = CH_RECHAZADAS

# Canales donde el bot responde automaticamente
AUTO_CHANNEL_IDS = {
    CH_TICKETS,
    CH_RESERVAS,
    CH_GENERAL,
    1524721092726624346,
    1524828073780969533,
}

AUTO_CHANNEL_NAMES = [
    "ticket", "reservas", "general", "recepcion",
    "recepcionista", "concierge", "bot",
]

# Roles de staff
STAFF_ROLE_IDS = {
    1507036303428944053,
    1507036433410429028,
    1507036502083764295,
    1524366734381940809,
    1524367737798004736,
}

# Roles MOD con permisos de kick/ban
MOD_ROLE_IDS = {
    1507036433410429028,
    1507036502083764295,
    1524367737798004736,
}

# --- INTENCIONES (chat natural) ---
INTENT_KEYWORDS = {
    "reservation": [
        "reservar", "reserva", "quiero reservar", "necesito habitacion",
        "habitacion", "room", "check in", "hospedarme",
        "alojamiento", "cuarto", "noche"
    ],
    "cancel": ["cancelar", "cancel", "anular", "eliminar reserva"],
    "status": ["mi reserva", "estado", "estado reserva", "ver reserva", "confirmada", "pendiente"],
    "rooms": ["habitaciones disponibles", "ver habitaciones", "disponibilidad",
              "precio", "tarifas", "cuanto cuesta"],
    "greeting": ["hola", "buenas", "buenos dias", "buenas tardes",
                 "buenas noches", "saludos", "hello", "bienvenido"],
}


def detect_intent(text: str) -> str:
    t = text.lower()
    for intent, keywords in INTENT_KEYWORDS.items():
        if any(k in t for k in keywords):
            return intent
    return "general"


# --- HELPERS ---
api = HotelAPI()

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True
intents.moderation = True

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree


def _is_staff(member) -> bool:
    if not hasattr(member, "roles"):
        return False
    if hasattr(member, "guild_permissions") and member.guild_permissions.administrator:
        return True
    return any(r.id in STAFF_ROLE_IDS for r in member.roles)


def _is_mod(member) -> bool:
    if not hasattr(member, "roles"):
        return False
    if hasattr(member, "guild_permissions") and member.guild_permissions.administrator:
        return True
    return any(r.id in MOD_ROLE_IDS for r in member.roles)


def _is_auto_channel(channel) -> bool:
    if isinstance(channel, discord.DMChannel):
        return True
    if channel.id in AUTO_CHANNEL_IDS:
        return True
    name = getattr(channel, "name", "").lower()
    return any(k in name for k in AUTO_CHANNEL_NAMES)


def _embed(title: str, desc: str, color: discord.Color) -> discord.Embed:
    e = discord.Embed(title=title, description=desc, color=color, timestamp=datetime.utcnow())
    e.set_footer(text="Von Stay Luxe RP - Recepcion")
    return e


def _info(desc: str) -> discord.Embed:
    return _embed("", desc, discord.Color.blue())


def _ok(title: str, desc: str) -> discord.Embed:
    return _embed(title, desc, discord.Color.green())


def _warn(title: str, desc: str) -> discord.Embed:
    return _embed(title, desc, discord.Color.yellow())


def _err(desc: str) -> discord.Embed:
    return _embed("Error", desc, discord.Color.red())


# --- DATOS DE HABITACIONES ---
ROOM_TYPES = {
    "standard": {"emoji": "\U0001F6CF\U0000FE0F", "name": "Estandar", "price": 70, "capacity": 2},
    "deluxe": {"emoji": "\U0001F6CE\U0000FE0F", "name": "Deluxe", "price": 140, "capacity": 3},
    "suite": {"emoji": "\U0001F3E8", "name": "Suite", "price": 250, "capacity": 4},
    "vip": {"emoji": "\U0001F451", "name": "VIP", "price": 500, "capacity": 2},
}

STATUS_ICONS = {
    "pending": "\u23F3", "confirmed": "\u2705", "cancelled": "\u274C",
    "checked_in": "\U0001F3E8", "checked_out": "\U0001F6AA",
}
STATUS_NAMES = {
    "pending": "Pendiente", "confirmed": "Confirmada", "cancelled": "Cancelada",
    "checked_in": "En hotel", "checked_out": "Completada",
}

# Infracciones en memoria
_warnings: dict = {}
_ai_sessions: dict = {}


# ==================================================================
#  EVENTOS DEL BOT
# ==================================================================

@bot.event
async def on_ready():
    log.info("=" * 50)
    log.info(f"Bot conectado: {bot.user} (ID: {bot.user.id})")
    log.info(f"   Servidores: {len(bot.guilds)}")
    log.info("=" * 50)

    guild = discord.Object(id=GUILD_ID)
    tree.copy_global_to(guild=guild)
    try:
        synced = await tree.sync(guild=guild)
        log.info(f"Slash commands sincronizados: {len(synced)}")
    except Exception as exc:
        log.error(f"Error al sincronizar slash commands: {exc}")

    await bot.change_presence(
        activity=discord.Activity(type=discord.ActivityType.watching, name="la recepcion | /ayuda")
    )


@bot.event
async def on_message(message: discord.Message):
    if message.author == bot.user or message.author.bot:
        return
    await bot.process_commands(message)
    if not _is_auto_channel(message.channel):
        return

    text = message.content.strip()
    if not text or text.startswith("/"):
        return

    uid = message.author.id
    username = message.author.name

    # Flujo activo
    if has_active_flow(uid):
        state = get_state(uid)
        if state and state.get("flow") == "reservation":
            async with message.channel.typing():
                embed, done = await ReservationFlow.process(uid, text, api, username)
                if done:
                    st = get_state(uid) or state
                    data = st.get("data", {})
                    clear_state(uid)
                    await message.channel.send(embed=embed)
                    ch = bot.get_channel(CH_RESERVAS_PENDIENTES)
                    if ch and ch.id != message.channel.id:
                        notif = _warn(
                            "Nueva Solicitud de Reserva",
                            f"**{data.get('rp_name','?')}** (@{username}) ha solicitado una reserva.\n\n"
                            f"Tipo: {data.get('room_type','?')}\n"
                            f"Fecha: {data.get('check_in','?')} -> {data.get('check_out','?')}\n\n"
                            f"Usa /verreservas para gestionar."
                        )
                        await ch.send(embed=notif)
                else:
                    await message.channel.send(embed=embed)
        return

    # Detectar intencion
    intent = detect_intent(text)
    async with message.channel.typing():
        if intent == "greeting":
            await message.channel.send(embed=_greeting(username))
        elif intent == "reservation":
            await _start_flow(message, uid, username)
        elif intent == "status":
            await _show_status(message, username)
        elif intent == "rooms":
            await _show_rooms(message)
        elif intent == "cancel":
            await _show_cancel_info(message, username)
        else:
            await _general_reply(message, text, username)


# ==================================================================
#  MANEJADORES DE INTENCION (chat natural)
# ==================================================================

def _greeting(username: str) -> discord.Embed:
    return _embed(
        "Bienvenido al Von Stay Luxe",
        f"Buenas, **{username}**. Soy el asistente de recepcion.\n\n"
        f"En que le puedo ayudar?\n\n"
        f"Reservar -> escriba \"quiero reservar\" o use /reservar\n"
        f"Mi reserva -> \"mi reserva\" o /perfil\n"
        f"Habitaciones -> \"ver habitaciones\" o /disponibilidad\n"
        f"Ayuda -> /ayuda",
        discord.Color.gold()
    )


async def _start_flow(message: discord.Message, uid: int, username: str):
    if has_active_flow(uid):
        await message.channel.send(embed=_info(
            "Ya tiene un proceso en curso. Responda a las preguntas o escriba cancelar."
        ))
        return
    embed = ReservationFlow.start(uid)
    await message.channel.send(embed=embed)


async def _show_status(message: discord.Message, username: str):
    try:
        reservations = await api.get_reservations(discord_user=username)
    except HotelAPIError:
        await message.channel.send(embed=_err("No se pudo conectar con el sistema."))
        return

    if not reservations:
        await message.channel.send(embed=_info("No tiene reservas registradas a su nombre."))
        return

    embed = discord.Embed(title=f"Reservas de {username}", color=discord.Color.blue(), timestamp=datetime.utcnow())
    for res in reservations[:5]:
        st = res.get("status", "pending")
        embed.add_field(
            name=f"{STATUS_ICONS.get(st,'')} {STATUS_NAMES.get(st,st)} - {res.get('rp_name','?')}",
            value=(
                f"\U0001F6CF {ROOM_TYPES.get(res.get('room_type',''), {}).get('name', res.get('room_type','?'))}\n"
                f"{res.get('check_in','?')} -> {res.get('check_out','?')}\n"
                f"EUR {res.get('total_price', 0):,.0f}\n"
                f"ID: `{res.get('id','')}`"
            ),
            inline=True
        )
    embed.set_footer(text="Von Stay Luxe RP - /cancelar [ID] para cancelar")
    await message.channel.send(embed=embed)


async def _show_rooms(message: discord.Message):
    try:
        rooms = await api.get_rooms(status="available")
    except HotelAPIError:
        await message.channel.send(embed=_err("No se pudo obtener la disponibilidad."))
        return

    if not rooms:
        await message.channel.send(embed=_info("No hay habitaciones disponibles."))
        return

    embed = _build_rooms_embed(rooms)
    await message.channel.send(embed=embed)


async def _show_cancel_info(message: discord.Message, username: str):
    try:
        pending = await api.get_reservations(discord_user=username, status="pending")
        confirmed = await api.get_reservations(discord_user=username, status="confirmed")
        reservations = pending + confirmed
    except HotelAPIError:
        await message.channel.send(embed=_err("Error al consultar reservas."))
        return

    if not reservations:
        await message.channel.send(embed=_info("No tiene reservas activas que cancelar."))
        return

    embed = _warn("Cancelar Reserva", f"Tiene **{len(reservations)}** reserva(s) activa(s). Use /cancelar [ID]:")
    for res in reservations[:3]:
        st = "Pendiente" if res.get("status") == "pending" else "Confirmada"
        embed.add_field(
            name=f"{st} - {res.get('rp_name','?')}",
            value=f"ID: `{res.get('id','')}`\n{res.get('check_in','?')} -> {res.get('check_out','?')}",
            inline=False
        )
    await message.channel.send(embed=embed)


async def _general_reply(message: discord.Message, text: str, username: str):
    t = text.lower()
    if any(w in t for w in ["tarifa", "precio", "cuesta", "vale", "costar"]):
        embed = discord.Embed(title="Tarifas Von Stay Luxe", color=discord.Color.gold())
        embed.add_field(name="\U0001F6CF Estandar", value="EUR 70/noche\nHasta 2 personas", inline=True)
        embed.add_field(name="\U0001F6CE Deluxe", value="EUR 140/noche\nHasta 3 personas", inline=True)
        embed.add_field(name="\U0001F3E8 Suite", value="EUR 250/noche\nHasta 4 personas", inline=True)
        embed.add_field(name="\U0001F451 VIP", value="EUR 500/noche\nExclusiva", inline=True)
        embed.set_footer(text="Sujeto a disponibilidad - Von Stay Luxe RP")
        await message.channel.send(embed=embed)
    elif any(w in t for w in ["wifi", "internet"]):
        await message.channel.send(embed=_info("WiFi gratuito en todas las habitaciones."))
    elif any(w in t for w in ["desayuno", "comida", "restaurante"]):
        await message.channel.send(embed=_info("Restaurante disponible. Desayuno de 7:00 a 11:00h."))
    elif any(w in t for w in ["gracias", "thank"]):
        await message.channel.send(embed=_info(f"Con mucho gusto, {username}!"))
    elif any(w in t for w in ["horario", "abierto", "cierra"]):
        await message.channel.send(embed=_info("Recepcion disponible las 24 horas."))
    else:
        await message.channel.send(embed=_info(
            f"Entendido, {username}. En que puedo ayudarle?\n\n"
            f"/reservar - Hacer una reserva\n"
            f"/disponibilidad - Ver habitaciones\n"
            f"/perfil - Ver su perfil\n"
            f"/ayuda - Todos los comandos"
        ))


def _build_rooms_embed(rooms) -> discord.Embed:
    by_type: dict = {}
    for r in rooms:
        t = r.get("type", "standard")
        by_type.setdefault(t, []).append(r)

    embed = discord.Embed(
        title=f"\U0001F3E8 Habitaciones Disponibles ({len(rooms)})",
        color=discord.Color.blue(),
        timestamp=datetime.utcnow(),
    )
    for t in ["standard", "deluxe", "suite", "vip"]:
        if t in by_type:
            rs = by_type[t]
            nums = ", ".join([f"#{int(r.get('room_number',0))}" for r in rs])
            price = rs[0].get("price", 0)
            info = ROOM_TYPES.get(t, {})
            embed.add_field(
                name=f"{info.get('emoji','')} {info.get('name',t)} - EUR {price}/noche",
                value=f"Disponibles: {nums}",
                inline=False,
            )
    embed.set_footer(text="Von Stay Luxe RP - /reservar para hacer una reserva")
    return embed
