"""
flows.py
=========
Flujos de conversación multi-turno para el bot del hotel.
Mantiene estado en memoria por usuario (dict).

ReservationFlow:
  step 0 → nombre RP
  step 1 → tipo de habitación
  step 2 → fecha check-in
  step 3 → fecha check-out
  step 4 → número de guests
  step 5 → confirmación
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from typing import Any, Dict, Optional, Tuple

import discord

from hotel_api import HotelAPI, HotelAPIError

logger = logging.getLogger("flows")

# ── Estado de conversaciones en memoria ───────────────────────
# user_id → { "flow": "reservation", "step": N, "data": {...} }
_conversation_state: Dict[int, Dict[str, Any]] = {}

VALID_ROOM_TYPES = {
    "standard": "🛏️ Standard — 70€/noche",
    "deluxe": "🌟 Deluxe — 140€/noche",
    "suite": "🏨 Suite — 250€/noche",
    "vip": "👑 VIP — 500€/noche",
}

TYPE_ALIASES = {
    "estandar": "standard",
    "standard": "standard",
    "basica": "standard",
    "básica": "standard",
    "deluxe": "deluxe",
    "delux": "deluxe",
    "lujo": "deluxe",
    "suite": "suite",
    "vip": "vip",
    "vvip": "vip",
}


def get_state(user_id: int) -> Optional[Dict[str, Any]]:
    return _conversation_state.get(user_id)


def set_state(user_id: int, state: Dict[str, Any]) -> None:
    _conversation_state[user_id] = state


def clear_state(user_id: int) -> None:
    _conversation_state.pop(user_id, None)


def has_active_flow(user_id: int) -> bool:
    state = _conversation_state.get(user_id)
    return state is not None and state.get("flow") is not None


# ── Utilidades de validación ──────────────────────────────────
def _parse_date(text: str) -> Optional[str]:
    """Acepta dd/mm/yyyy, dd-mm-yyyy, yyyy-mm-dd."""
    text = text.strip()
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(text, fmt)
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def _normalize_room_type(text: str) -> Optional[str]:
    key = text.strip().lower()
    return TYPE_ALIASES.get(key)


# ── Embeds auxiliares ─────────────────────────────────────────
def _info_embed(title: str, description: str) -> discord.Embed:
    return discord.Embed(title=title, description=description, color=discord.Color.blue())


def _success_embed(title: str, description: str) -> discord.Embed:
    return discord.Embed(title=title, description=description, color=discord.Color.green())


def _warn_embed(title: str, description: str) -> discord.Embed:
    return discord.Embed(title=title, description=description, color=discord.Color.gold())


def _error_embed(msg: str) -> discord.Embed:
    return discord.Embed(title="❌ Error", description=msg, color=discord.Color.red())


# ── Flujo principal ───────────────────────────────────────────
class ReservationFlow:
    """Flujo de reserva paso a paso."""

    STEP_RP_NAME = 0
    STEP_ROOM_TYPE = 1
    STEP_CHECK_IN = 2
    STEP_CHECK_OUT = 3
    STEP_GUESTS = 4
    STEP_CONFIRM = 5

    TOTAL_STEPS = 6

    @classmethod
    def start(cls, user_id: int) -> discord.Embed:
        """Inicia el flujo y devuelve el primer embed."""
        set_state(
            user_id,
            {"flow": "reservation", "step": cls.STEP_RP_NAME, "data": {}},
        )
        return _info_embed(
            "🏨 Nueva Reserva — Von Stay Luxe Revo RP",
            "¡Bienvenido! Voy a tomarle los datos para su reserva.\n\n"
            "**Paso 1/5** — ¿Cuál es su **nombre de rol (RP)**?",
        )

    @classmethod
    async def process(
        cls,
        user_id: int,
        message: str,
        api: HotelAPI,
        discord_user: str,
    ) -> Tuple[discord.Embed, bool]:
        """
        Procesa un mensaje del usuario dentro del flujo.
        Devuelve (embed, completed).
        """
        state = get_state(user_id)
        if not state or state.get("flow") != "reservation":
            return _warn_embed("⏳ Sin reserva activa", "No tienes ninguna reserva en curso."), False

        step = state["step"]
        data = state["data"]
        text = message.strip()

        # Cancelar
        if text.lower() in ("cancelar", "cancel", "salir", "exit", "abortar"):
            clear_state(user_id)
            return _warn_embed("❌ Reserva cancelada", "Has cancelado el proceso de reserva. Puedes empezar de nuevo con `/reservar`."), False

        # ── STEP 0: nombre RP ──
        if step == cls.STEP_RP_NAME:
            if len(text) < 2:
                return _warn_embed("⚠️ Nombre inválido", "Por favor, dime un nombre válido (mínimo 2 caracteres)."), False
            data["rp_name"] = text
            state["step"] = cls.STEP_ROOM_TYPE
            types_text = "\n".join(f"• **{k}** — {v}" for k, v in VALID_ROOM_TYPES.items())
            return _info_embed(
                "🏨 Reserva — Paso 2/5",
                f"Perfecto, **{text}**.\n\n¿Qué **tipo de habitación** desea?\n\n{types_text}\n\n"
                "_(Escribe: standard, deluxe, suite o vip)_",
            ), False

        # ── STEP 1: tipo habitación ──
        if step == cls.STEP_ROOM_TYPE:
            rtype = _normalize_room_type(text)
            if not rtype:
                return _warn_embed("⚠️ Tipo inválido", "Por favor elige: standard, deluxe, suite o vip."), False
            data["room_type"] = rtype
            state["step"] = cls.STEP_CHECK_IN
            return _info_embed(
                "🏨 Reserva — Paso 3/5",
                f"Excelente, habitación **{VALID_ROOM_TYPES[rtype].split(' — ')[0]}**.\n\n"
                "¿Qué **fecha de entrada** (check-in)?\n_(Formato: dd/mm/aaa)_",
            ), False

        # ── STEP 2: check-in ──
        if step == cls.STEP_CHECK_IN:
            date = _parse_date(text)
            if not date:
                return _warn_embed("⚠️ Fecha inválida", "Usa el formato dd/mm/aaa (ej: 15/08/2026)."), False
            data["check_in"] = date
            state["step"] = cls.STEP_CHECK_OUT
            return _info_embed(
                "🏨 Reserva — Paso 4/5",
                f"Check-in: **{date}**.\n\n¿Qué **fecha de salida** (check-out)?\n_(Formato: dd/mm/aaa)_",
            ), False

        # ── STEP 3: check-out ──
        if step == cls.STEP_CHECK_OUT:
            date = _parse_date(text)
            if not date:
                return _warn_embed("⚠️ Fecha inválida", "Usa el formato dd/mm/aaa (ej: 20/08/2026)."), False
            check_in = data.get("check_in")
            if check_in and date <= check_in:
                return _warn_embed("⚠️ Fecha inválida", "La fecha de salida debe ser **posterior** a la de entrada."), False
            data["check_out"] = date
            state["step"] = cls.STEP_GUESTS
            return _info_embed(
                "🏨 Reserva — Paso 5/5",
                f"Check-out: **{date}**.\n\n¿Cuántos **huéspedes** serán?",
            ), False

        # ── STEP 4: guests ──
        if step == cls.STEP_GUESTS:
            try:
                guests = int(re.sub(r"[^\d]", "", text))
                if guests < 1 or guests > 10:
                    raise ValueError
            except (ValueError, TypeError):
                return _warn_embed("⚠️ Número inválido", "Dime un número entre 1 y 10."), False
            data["guests"] = guests
            state["step"] = cls.STEP_CONFIRM
            return _confirm_embed(data), False

        # ── STEP 5: confirmación ──
        if step == cls.STEP_CONFIRM:
            lower = text.lower().strip()
            if lower in ("si", "sí", "confirmar", "ok", "yes", "confirmo", "aceptar"):
                # Crear reserva en la API
                data["discord_user"] = discord_user
                try:
                    result = await api.create_reservation(data)
                    clear_state(user_id)
                    res_id = ""
                    if isinstance(result, dict):
                        res_id = result.get("id", result.get("_id", ""))
                    embed = _success_embed(
                        "✅ Reserva Creada",
                        f"¡Reserva confirmada con éxito, **{data['rp_name']}**! 🎉\n\n"
                        f"🔑 **ID de reserva:** `{res_id or 'N/A'}`\n"
                        f"🏨 **Habitación:** {VALID_ROOM_TYPES.get(data['room_type'], data['room_type']).split(' — ')[0]}\n"
                        f"📅 **Entrada:** {data['check_in']} — **Salida:** {data['check_out']}\n"
                        f"👥 **Huéspedes:** {data['guests']}\n\n"
                        f"⏳ Tu reserva está **pendiente de aprobación** por el staff del hotel.\n"
                        f"Te notificaré cuando sea confirmada.",
                    )
                    # Notificar al sistema
                    try:
                        await api.send_notification(
                            title="Nueva reserva pendiente",
                            message=f"{data['rp_name']} ({discord_user}) ha reservado habitación {data['room_type']} "
                                    f"del {data['check_in']} al {data['check_out']} ({data['guests']} huéspedes).",
                            type="reservation",
                        )
                    except HotelAPIError:
                        logger.warning("No se pudo enviar notificación de nueva reserva")
                    return embed, True
                except HotelAPIError as exc:
                    clear_state(user_id)
                    return _error_embed(f"No pude crear la reserva: {exc.message}"), False

            elif lower in ("no", "cancelar", "rechazar", "modificar"):
                clear_state(user_id)
                return _warn_embed("❌ Reserva descartada", "No se ha creado ninguna reserva. Usa `/reservar` para empezar de nuevo."), False
            else:
                return _warn_embed("⚠️ Confirmación", "Por favor responde **sí** para confirmar o **no** para cancelar."), False

        # Fallback
        clear_state(user_id)
        return _warn_embed("⚠️ Error de flujo", "El flujo se reinició. Usa `/reservar` para empezar."), False


def _confirm_embed(data: Dict[str, Any]) -> discord.Embed:
    embed = discord.Embed(
        title="📋 Confirma tu reserva",
        description="Revisa los datos antes de confirmar:",
        color=discord.Color.gold(),
    )
    embed.add_field(name="🧑 Nombre RP", value=data.get("rp_name", "—"), inline=True)
    embed.add_field(
        name="🏨 Habitación",
        value=VALID_ROOM_TYPES.get(data.get("room_type", ""), data.get("room_type", "—")),
        inline=True,
    )
    embed.add_field(name="📅 Check-in", value=data.get("check_in", "—"), inline=True)
    embed.add_field(name="📅 Check-out", value=data.get("check_out", "—"), inline=True)
    embed.add_field(name="👥 Huéspedes", value=str(data.get("guests", "—")), inline=True)
    embed.add_field(
        name="✅ Confirmar",
        value="Escribe **sí** para confirmar\no **no** para cancelar",
        inline=False,
    )
    embed.set_footer(text="Von Stay Luxe Revo RP · Confirmación de Reserva")
    return embed
