"""
diagnostics.py
===============
Genera reportes de diagnóstico de habitaciones formateados para Discord,
con emojis, embeds y alertas visuales.
"""

from __future__ import annotations

import logging
from typing import Any, Dict

import discord

from hotel_api import HotelAPI, HotelAPIError

logger = logging.getLogger("diagnostics")

# ── Traducciones ─────────────────────────────────────────────
STATUS_LABELS = {
    "available": "🟢 Disponible",
    "occupied": "🔴 Ocupada",
    "maintenance": "🔧 Mantenimiento",
    "unknown": "⚪ Desconocido",
}

TYPE_LABELS = {
    "standard": "🛏️ Standard",
    "deluxe": "🌟 Deluxe",
    "suite": "🏨 Suite",
    "vip": "👑 VIP",
}

PRICE_GUIDE = {
    "standard": "70€",
    "deluxe": "140€",
    "suite": "250€",
    "vip": "500€",
}

VIP_ICONS = {
    "normal": "🧑",
    "vip": "⭐",
    "vvip": "👑",
}


async def generate_diagnostics_embed(
    api: HotelAPI, room_identifier: str
) -> discord.Embed:
    """
    Busca una habitación por ID o por número/nombre y genera
    un embed de Discord con el diagnóstico completo.
    """
    room = None
    diag = None

    # 1) Intentar por ID directo
    try:
        diag = await api.room_diagnostics(room_identifier)
        if "error" not in diag:
            room = diag.get("room")
    except HotelAPIError:
        room = None

    # 2) Si no se encontró, buscar por número/nombre en la lista
    if not room:
        try:
            rooms = await api.get_rooms()
            for r in rooms:
                rn = str(r.get("room_number", "")).lower()
                nm = str(r.get("name", "")).lower()
                rid = str(r.get("id", "")).lower()
                if (
                    room_identifier.lower() == rn
                    or room_identifier.lower() == nm
                    or room_identifier.lower() == rid
                ):
                    diag = await api.room_diagnostics(r["id"])
                    room = diag.get("room")
                    break
        except HotelAPIError as exc:
            return _error_embed(f"No se pudo acceder a la API: {exc.message}")

    if not room:
        return _error_embed(
            f"No encontré ninguna habitación con el identificador '{room_identifier}'."
        )

    return _build_diagnostic_embed(diag)


def _build_diagnostic_embed(diag: Dict[str, Any]) -> discord.Embed:
    room = diag["room"]
    status = diag.get("status", "unknown")
    rtype = diag.get("type", "unknown")
    alerts = diag.get("alerts", [])

    # Color según estado
    color_map = {
        "available": discord.Color.green(),
        "occupied": discord.Color.red(),
        "maintenance": discord.Color.orange(),
    }
    color = color_map.get(status, discord.Color.blue())

    room_label = (
        f"Habitación {room.get('room_number', '?')}"
        if room.get("room_number")
        else room.get("name", "Habitación")
    )

    embed = discord.Embed(
        title=f"🛎️ Diagnóstico — {room_label}",
        description=f"**Tipo:** {TYPE_LABELS.get(rtype, rtype)}\n"
        f"**Estado:** {STATUS_LABELS.get(status, status)}",
        color=color,
    )

    # ── Datos principales ──
    price = room.get("price")
    price_text = f"{price}€/noche" if price else PRICE_GUIDE.get(rtype, "—")
    embed.add_field(
        name="💰 Precio",
        value=price_text,
        inline=True,
    )

    capacity = room.get("capacity", "—")
    embed.add_field(
        name="👥 Capacidad",
        value=f"{capacity} persona(s)",
        inline=True,
    )

    floor = room.get("floor", "—")
    embed.add_field(
        name="🏢 Planta",
        value=str(floor),
        inline=True,
    )

    # ── Amenidades ──
    amenities = room.get("amenities")
    if isinstance(amenities, list) and amenities:
        amenities_text = ", ".join(f"`{a}`" for a in amenities)
    elif isinstance(amenities, str) and amenities:
        amenities_text = amenities
    else:
        amenities_text = "Sin amenidades registradas"
    embed.add_field(
        name="🧰 Amenidades",
        value=amenities_text,
        inline=False,
    )

    # ── Huésped asignado ──
    assigned = diag.get("assigned_guest")
    embed.add_field(
        name="🔑 Huésped asignado",
        value=str(assigned) if assigned else "—",
        inline=True,
    )

    # ── Historial ──
    res_count = diag.get("reservation_count", 0)
    embed.add_field(
        name="📊 Reservas totales",
        value=str(res_count),
        inline=True,
    )

    # ── Descripción ──
    desc = room.get("description")
    if desc:
        embed.add_field(
            name="📝 Descripción",
            value=str(desc)[:300],
            inline=False,
        )

    # ── Alertas ──
    if alerts:
        alerts_text = "\n".join(alerts)
        embed.add_field(
            name="🚨 Alertas",
            value=alerts_text,
            inline=False,
        )

    embed.set_footer(text="Von Stay Luxe Revo RP · Sistema de Diagnóstico")
    return embed


def _error_embed(message: str) -> discord.Embed:
    return discord.Embed(
        title="❌ Error de Diagnóstico",
        description=message,
        color=discord.Color.red(),
    )
