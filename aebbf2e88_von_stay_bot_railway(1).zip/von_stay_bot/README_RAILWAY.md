# 🏨 Von Stay Luxe — Bot de Discord
## Deploy en Railway (24/7 gratis)

---

## ✅ Requisitos previos
- Cuenta en [railway.app](https://railway.app) (gratuita)
- Cuenta en [GitHub](https://github.com) (gratuita)
- Token del bot de Discord (ya lo tienes)

---

## 🚀 Pasos para el deploy

### 1. Subir el código a GitHub

1. Ve a [github.com](https://github.com) → **New repository**
2. Nómbralo `von-stay-bot` (privado recomendado)
3. Descarga esta carpeta `discord_bot/` a tu ordenador
4. Sube todos los archivos al repositorio

**O con Git desde terminal:**
```bash
git init
git add .
git commit -m "Von Stay Luxe Bot v3.0"
git remote add origin https://github.com/TU_USUARIO/von-stay-bot.git
git push -u origin main
```

---

### 2. Crear proyecto en Railway

1. Ve a [railway.app](https://railway.app) e inicia sesión
2. Haz clic en **"New Project"**
3. Selecciona **"Deploy from GitHub repo"**
4. Conecta tu cuenta de GitHub y selecciona `von-stay-bot`
5. Railway detectará automáticamente el `Procfile` y `requirements.txt`

---

### 3. Configurar variables de entorno

En Railway, ve a tu proyecto → **Variables** → añade estas:

| Variable | Valor |
|---|---|
| `DISCORD_BOT_TOKEN_FULL` | Tu token de Discord |
| `BASE44_API_URL` | `https://von-stay-luxe-revo-rp.base44.app/api` |
| `BASE44_API_KEY` | `6610a6a2ffe14ef29500c004c81cc63c` |
| `BASE44_APP_ID` | `6a0dfa64e37bba86acbfb7ee` |

---

### 4. Iniciar el servicio

1. Ve a **Deployments** en Railway
2. Haz clic en **"Deploy"** (o es automático si tienes CI/CD activado)
3. Ve a **Logs** para ver el bot arrancando

Deberías ver:
```
🏨  Bot conectado: VON CRASTENHBURG HOTEL#3827
✅ Slash commands sincronizados: 44
```

---

## 🆓 Plan gratuito de Railway

Railway ofrece **$5 USD de créditos mensuales gratis**. Un bot pequeño consume aproximadamente **$0.50–1.00/mes**, así que deberías tener cobertura sin coste.

Para estar seguro, en Railway activa **"Sleep on inactivity"** = OFF (así el bot nunca se duerme).

---

## 📋 Comandos del bot (44 comandos)

### 🏨 Huéspedes
- `/reservar` — Iniciar proceso de reserva paso a paso
- `/cancelar [id]` — Cancelar una reserva
- `/checkin [codigo]` — Realizar check-in
- `/checkout` — Realizar check-out
- `/estado` — Ver mis reservas
- `/disponibilidad [tipo]` — Ver habitaciones disponibles
- `/servicio [tipo]` — Solicitar servicio de habitación
- `/perfil [usuario]` — Ver perfil
- `/registro` — Registrarse en el hotel
- `/tienda` — Canjear VonCoins
- `/solicitar_empleo` — Solicitud de trabajo
- `/periodico` — Leer el Von Crastenburg Gazette
- `/infohotel` — Información del hotel
- `/ranking_huespedes` — Ranking de estancias

### 🤖 IA
- `/asistente [consulta]` — Consultar al asistente virtual
- `/resetear_ia` — Borrar historial de IA

### 🎭 Entretenimiento
- `/evento` — Evento aleatorio de roleplay
- `/idea` — Idea creativa para el hotel

### 👔 Staff
- `/pendientes` — Ver reservas pendientes
- `/aceptar [id]` — Confirmar reserva
- `/rechazar [id] [motivo]` — Rechazar reserva
- `/verreservas` — Todas las reservas activas
- `/confirmarreserva [usuario] [id]` — Enviar DM de confirmación
- `/diagnostico [num]` — Diagnóstico de habitación
- `/stats` — Dashboard estadísticas
- `/anunciar [canal] [mensaje]` — Anuncio oficial
- `/panelhabitaciones` — Panel estado habitaciones
- `/paneltickets` — Panel de tickets
- `/panelturnos` — Panel de turnos
- `/panelficar` — Panel de fichaje
- `/fichas [usuario]` — Fichas de empleado
- `/mis_fichas [dia/mes]` — Mis fichas
- `/rangoset [usuario] [rango]` — Asignar rol
- `/publicar_periodico [titular]` — Publicar periódico

### 🛡️ Moderación
- `/advertencia [usuario] [motivo]` — Registrar advertencia
- `/infracciones [usuario]` — Ver advertencias
- `/borrar_advertencias [usuario]` — Borrar advertencias
- `/silenciar [usuario] [min] [motivo]` — Timeout
- `/quitar_silencio [usuario]` — Levantar timeout
- `/expulsar [usuario] [motivo]` — Kick
- `/banear [usuario] [motivo]` — Ban permanente
- `/desbanear [id]` — Unban
- `/limpiar [cantidad]` — Purge de mensajes

### 📖
- `/ayuda` — Ver todos los comandos

---

## 🔧 Solución de problemas

**El bot no arranca:**
- Verifica que `DISCORD_BOT_TOKEN_FULL` está correctamente configurado
- Revisa los logs en Railway → Deployments → ver logs

**Los slash commands no aparecen:**
- Pueden tardar hasta 1 hora en propagarse globalmente en Discord
- En el servidor específico aparecen instantáneamente

**Error de permisos:**
- Asegúrate de que el bot tiene los permisos: `Send Messages`, `Manage Messages`, `Kick Members`, `Ban Members`, `Moderate Members`

---

*Von Stay Luxe Revo RP — Bot v3.0 | Desarrollado con discord.py*
