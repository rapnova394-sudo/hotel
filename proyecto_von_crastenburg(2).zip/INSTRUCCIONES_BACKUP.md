# Instrucciones para respaldar este proyecto en GitHub

1. Clona tu repositorio vacío (o uno existente):
   ```bash
   git clone <tu-repo-url>
   cd <tu-repo>
   ```

2. Copia dentro de esa carpeta todos los archivos que vienen dentro de este zip
   (extráelo y mueve el contenido, sin incluir el propio zip):
   ```bash
   unzip proyecto_von_crastenburg.zip -d .
   ```

3. Sube los cambios:
   ```bash
   git add .
   git commit -m "Respaldo del proyecto Von Crastenburg"
   git push origin main
   ```

## Notas importantes

- No subas los archivos `.env`, tokens, ni ninguna clave/API key: nunca están
  incluidos en este zip a propósito.
- El bot corre con `python3 main.py`. Requiere las variables de entorno
  `DISCORD_TOKEN_BOT`, `SESSION_SECRET`, `BASE44_API_KEY`, `BASE44_AGENT_API_KEY`,
  y `BASE44_APP_ID` configuradas donde despliegues el proyecto.
- Las dependencias están en `pyproject.toml` / `uv.lock` (gestor `uv`).
