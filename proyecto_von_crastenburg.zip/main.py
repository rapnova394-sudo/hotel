import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import random
import aiohttp
import asyncio
from collections import OrderedDict
from datetime import datetime, timedelta
from keep_alive import keep_alive
import base44_api as b44
import hotel_ai
import reservas_ai

# ==========================================
# CONFIGURACIÓN
# ==========================================

TOKEN = os.getenv("DISCORD_TOKEN_BOT")
if TOKEN is None:
    raise ValueError("DISCORD_TOKEN_BOT environment variable is not set")

# ==========================================
# CANDADO DE PROCESO ÚNICO
# ==========================================
# Evita que dos instancias del bot corran a la vez (p.ej. si un reinicio del
# workflow no mata a tiempo el proceso anterior), lo que provocaría mensajes,
# tickets y respuestas de la IA duplicados.
# Usa un lock de archivo real (fcntl.flock) para evitar condiciones de carrera,
# y solo mata al proceso anterior si su línea de comandos confirma que es
# efectivamente otra instancia de este bot (evita matar un PID reutilizado
# por un proceso distinto).

_LOCK_FILE   = "bot.lock"
_lock_handle = None  # se mantiene abierto durante toda la vida del proceso

def _es_otra_instancia_del_bot(pid: int) -> bool:
    if pid == os.getpid():
        return False
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmdline = f.read().decode(errors="ignore")
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        return False
    return "main.py" in cmdline and "python" in cmdline


def _asegurar_instancia_unica():
    import fcntl
    import signal
    import time

    global _lock_handle
    _lock_handle = open(_LOCK_FILE, "a+")

    for intento in range(10):
        try:
            fcntl.flock(_lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            _lock_handle.seek(0)
            contenido = _lock_handle.read().strip()
            pid_anterior = int(contenido) if contenido.isdigit() else 0

            if pid_anterior and _es_otra_instancia_del_bot(pid_anterior):
                print(f"[Lock] Proceso anterior del bot (PID {pid_anterior}) sigue activo, terminándolo...")
                try:
                    os.kill(pid_anterior, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            time.sleep(0.5)
    else:
        raise RuntimeError("No se pudo obtener el candado de instancia única del bot (bot.lock).")

    _lock_handle.seek(0)
    _lock_handle.truncate()
    _lock_handle.write(str(os.getpid()))
    _lock_handle.flush()

_asegurar_instancia_unica()

HOTEL_DB_FILE  = "hotel_db.json"
RESERVAS_DB    = "reservas_db.json"
FICHAS_DB      = "fichas_db.json"
WARNS_DB       = "warns_db.json"

COLOR_DORADO = 0xD4AF37
COLOR_NEGRO  = 0x1C1C1C
COLOR_ROJO   = 0xC0392B
WEB_API_BASE = "https://von-stay-luxe-revo-rp.base44.app"

ID_MANAGER   = 1392922625369444494   # Usuario que acepta/rechaza solicitudes de empleo

TICKETS_IA_DB      = "tickets_ia_activos.json"   # Canales de ticket con respuesta automática de IA activada
TICKETS_RESERVA_DB = "tickets_reserva_activos.json"  # Canales de ticket de reservas (Agente Reservas IA)
MOD_IA_DB         = "mod_ia_db.json"            # Nivel de infracciones detectadas por la IA por usuario
CANALES_PAUSA_DB  = "canales_ia_pausada.json"   # Canales donde se ha escrito "/parar" (chat general de IA desactivado)

ID_ROL_SUPERIOR    = 1524366734381940809   # Rol al que se escala si la IA no puede resolver algo en un ticket
ID_CANAL_DUDAS     = 1524363027271647292   # Canal donde la IA ofrece abrir ticket si detecta una duda
ID_ROL_MODERACION  = 1524367737798004736   # Rol de moderadores que decide sobre infracciones graves/reincidentes
ID_ROL_ANUNCIO     = 1507036116887539712   # Rol que se otorga automáticamente a quien recibe un /anunciar
ID_CANAL_PERIODICO = 1524458698137800784   # Canal donde se publican las ediciones del periódico
ID_ROL_PERIODICO   = 1524458967533748278   # Rol con permiso para publicar nuevas ediciones
PERIODICO_DB       = "periodico_db.json"

# ── Nuevas constantes v2 ──────────────────────────────────
VALORACIONES_DB    = "valoraciones_db.json"
TIENDA_COMPRAS_DB  = "tienda_compras_db.json"
PANEL_TURNOS_FILE  = "panel_turnos_msg.json"
ALERTA_MANT_DB     = "alerta_mant_db.json"
ROL_EN_SERVICIO    = "En servicio"
ROL_FUERA_SERVICIO = "Fuera de servicio"
HORAS_ALERTA_MANT  = 2.0   # Horas en cleaning/maintenance antes de alertar

TIENDA_ITEMS = [
    {"id": "desayuno", "emoji": "🍳", "nombre": "Desayuno en habitación", "precio": 50},
    {"id": "kit",      "emoji": "🛁", "nombre": "Kit de bienvenida",       "precio": 30},
    {"id": "upgrade",  "emoji": "⬆️", "nombre": "Upgrade de habitación",   "precio": 200},
    {"id": "late",     "emoji": "🌙", "nombre": "Late checkout (+2h)",      "precio": 75},
    {"id": "champan",  "emoji": "🍾", "nombre": "Botella de champán",       "precio": 40},
]

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)
_views_registrados = False
_tareas_fondo_iniciadas = False
_lock_mod_ia = asyncio.Lock()

# Rolling buffer de mensajes por canal para detección de escalada grupal
# { channel_id: ["Nombre: mensaje", ...] }
_buffer_escalada: dict[int, list[str]] = {}
_locks_escalada: dict[int, asyncio.Lock] = {}   # un Lock por canal para evitar race conditions
_BUFFER_ESCALADA_MAX   = 12   # mensajes que se acumulan por canal
_ESCALADA_CADA_N_MSG   = 5    # cada cuántos mensajes nuevos se lanza el análisis

# ==========================================
# BASE DE DATOS GENÉRICA
# ==========================================

def cargar_db(path):
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump({}, f)
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, ValueError):
        print(f"[DB] {path} corrupto o vacío, se reinicia a {{}}")
        return {}

def guardar_db(path, db):
    tmp = f"{path}.tmp"
    with open(tmp, "w") as f:
        json.dump(db, f, indent=2)
    os.replace(tmp, path)


# ==========================================
# SISTEMA HOTEL RP
# ==========================================

RANGOS = ["Visitante","Huésped","Miembro","VIP","Staff","Gerente","Director"]

IDEAS_HOTEL = [
    "Crear una sala de eventos con capacidad para torneos.",
    "Añadir un casino con minijuegos de rol.",
    "Sistema de reputación para usuarios frecuentes.",
    "Crear habitaciones temáticas: playa, montaña, espacio...",
    "Un empleo de recepcionista para ayudar a nuevos usuarios.",
    "Sistema de logros desbloqueables por actividad.",
    "Organizar un concurso de decoración de habitaciones.",
    "Añadir una cafetería con menú del día roleplay.",
    "Crear un periódico mensual del hotel.",
    "Sistema de reservas de habitaciones por comandos.",
]

EVENTOS_HOTEL = [
    "🌃 ¡Noche de gala en el salón principal! Código de vestimenta: elegante.",
    "♟️ ¡Torneo de ajedrez en la sala de juegos! Premio: rango VIP temporal.",
    "🍽️ ¡Buffet libre en el restaurante hasta medianoche!",
    "🔍 ¡Llegada de huésped misterioso! Descubre su identidad.",
    "👨‍🍳 ¡Concurso de cocina en los fogones del hotel!",
    "🎤 ¡Noche de karaoke en el bar del hotel!",
    "🔧 ¡Fuga de agua en el piso 3! El equipo de mantenimiento necesita ayuda.",
    "🏆 ¡Subasta de objetos exclusivos en el vestíbulo!",
    "🎂 ¡Celebración del aniversario del hotel! Entrada libre para todos.",
    "🕵️ ¡Inspección sorpresa del gerente! Todos los empleados a sus puestos.",
]

# ==========================================
# VONSTAAY — SISTEMA DE RESERVAS
# ==========================================

HABITACIONES = {
    "suite": {"nombre": "Suite Royal",      "precio": 500, "total": 5,  "emoji": "👑"},
    "doble": {"nombre": "Habitación Doble", "precio": 200, "total": 10, "emoji": "🛏️"},
    "lujo":  {"nombre": "Suite de Lujo",    "precio": 350, "total": 8,  "emoji": "💎"},
}

def generar_codigo_reserva():
    return "VC" + str(random.randint(10000, 99999))

def contar_ocupadas(db, tipo):
    return sum(1 for r in db.values() if r.get("tipo") == tipo and r.get("estado") in ("confirmada","checkin"))

def embed_von(titulo, descripcion, color=COLOR_DORADO):
    e = discord.Embed(title=titulo, description=descripcion, color=color)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    return e

LOGO_PATH = "assets/logo_vc.png"

def _logo_file() -> discord.File:
    """Un discord.File nuevo con el logo (cada File solo se puede usar en un send)."""
    return discord.File(LOGO_PATH, filename="logo_vc.png")

def _con_logo(embed: discord.Embed) -> discord.Embed:
    """Añade el logo del hotel como miniatura del embed. Usar junto con _logo_file() en el send."""
    embed.set_thumbnail(url="attachment://logo_vc.png")
    return embed

async def intentar_api(method, endpoint, payload=None):
    try:
        async with aiohttp.ClientSession() as s:
            url = f"{WEB_API_BASE}{endpoint}"
            kwargs = {"timeout": aiohttp.ClientTimeout(total=5)}
            if method == "GET":
                async with s.get(url, **kwargs) as r:
                    return await r.json() if r.status == 200 else None
            elif method == "POST":
                async with s.post(url, json=payload, **kwargs) as r:
                    return await r.json() if r.status in (200,201) else None
            elif method == "PUT":
                async with s.put(url, json=payload, **kwargs) as r:
                    return await r.json() if r.status == 200 else None
    except Exception:
        return None

async def log_staff(guild, embed):
    canal = discord.utils.get(guild.text_channels, name="logs-reservas")
    if canal:
        await canal.send(embed=embed)

# ==========================================
# HELPERS COMPARTIDOS  (usados por comandos Y botones)
# ==========================================

async def _send(interaction: discord.Interaction, embed, view=None, ephemeral=False):
    """Envía un mensaje sea o no la primera respuesta."""
    kw = {"embed": embed, "ephemeral": ephemeral}
    if view:
        kw["view"] = view
    if interaction.response.is_done():
        await interaction.followup.send(**kw)
    else:
        await interaction.response.send_message(**kw)

async def _responder_anonimo(interaction: discord.Interaction, embed=None, view=None, ack: str = "✅ Hecho."):
    """Confirma en privado (solo lo ve quien usó el comando) y publica el resultado como un
    mensaje normal del bot en el canal, para que Discord no muestre 'fulano usó /comando'.
    Se usa en todos los comandos salvo tickets y sanciones/moderación, donde sí debe quedar
    constancia de quién actuó."""
    kw = {}
    if embed is not None:
        kw["embed"] = embed
    if view is not None:
        kw["view"] = view
    if interaction.response.is_done():
        await interaction.followup.send(ack, ephemeral=True)
    else:
        await interaction.response.send_message(ack, ephemeral=True)
    return await interaction.channel.send(**kw)

async def _cmd_disponibilidad(interaction: discord.Interaction, anonimo: bool = False):
    db = cargar_db(RESERVAS_DB)
    e  = discord.Embed(title="🏨 Disponibilidad — Von Crastenburg Hotel",
                       description="Habitaciones disponibles en tiempo real.", color=COLOR_DORADO)
    for key, hab in HABITACIONES.items():
        ocup   = contar_ocupadas(db, key)
        libres = hab["total"] - ocup
        barra  = "🟩" * libres + "🟥" * ocup
        e.add_field(name=f"{hab['emoji']} {hab['nombre']}",
                    value=f"**{libres}/{hab['total']}** libres  |  {hab['precio']} €/noche\n{barra}",
                    inline=False)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    if anonimo:
        await _responder_anonimo(interaction, embed=e, view=ViewDisponibilidad())
        return
    await _send(interaction, e, ViewDisponibilidad(), ephemeral=False)

async def _cmd_infohotel(interaction: discord.Interaction, anonimo: bool = False):
    e = discord.Embed(title="🏨 Von Crastenburg Hotel RP",
                      description="*Bienvenido al Von Crastenburg, su descanso es nuestro lujo.*",
                      color=COLOR_DORADO)
    e.add_field(name="📍 Ubicación",    value="Pixelopolis, Distrito Central", inline=False)
    e.add_field(name="⭐ Categoría",    value="5 estrellas de lujo",           inline=True)
    e.add_field(name="🕐 Recepción",   value="24h / 7 días",                  inline=True)
    e.add_field(name="🛎️ Servicios",
                value="• Spa 💆  • Restaurante gourmet 🍽️\n• Piscina 🏊  • Bar de cócteles 🍸\n• Sala de eventos 🎭  • Aparcamiento 🚗",
                inline=False)
    e.add_field(name="🌐 Reservas online",
                value=f"[Reservar en la web]({WEB_API_BASE}/reservations)", inline=False)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    if anonimo:
        await _responder_anonimo(interaction, embed=e, view=ViewInfoHotel())
        return
    await _send(interaction, e, ViewInfoHotel())

async def _mostrar_mis_reservas(interaction: discord.Interaction):
    db    = cargar_db(RESERVAS_DB)
    uid   = str(interaction.user.id)
    mis_r = sorted(
        [r for r in db.values() if r.get("usuario_id") == uid and r.get("estado") not in ("cancelada","completada")],
        key=lambda r: r.get("creada","")
    )
    if not mis_r:
        await _send(interaction, embed_von("📋 Sin reservas activas",
                    "No tienes reservas activas.\nUsa `/reservar` para hacer una.", COLOR_NEGRO),
                    ViewPostCheckout(), ephemeral=True)
        return
    e = discord.Embed(title="📋 Mis reservas activas — Von Crastenburg", color=COLOR_DORADO)
    for r in mis_r[:8]:
        hab      = HABITACIONES.get(r.get("tipo","doble"), {})
        room_txt = f"Hab. #{r['room_numero']}" if r.get("room_numero") else hab.get("nombre", r.get("tipo","?"))
        estado   = {"confirmada": "✅ Confirmada", "checkin": "🟢 En estancia"}.get(r["estado"], r["estado"])
        e.add_field(name=f"`{r['codigo']}` — {room_txt}",
                    value=f"📅 {r.get('fecha','—')}  |  {estado}", inline=False)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    # Usar botones de la primera reserva activa
    first = mis_r[0]
    if first["estado"] == "confirmada":
        view = ViewPostReserva(first["codigo"])
    elif first["estado"] == "checkin":
        view = ViewPostCheckin(first["codigo"])
    else:
        view = ViewPostCheckout()
    await _send(interaction, e, view, ephemeral=True)

async def _ejecutar_checkin_logic(interaction: discord.Interaction, codigo: str):
    await interaction.response.defer(ephemeral=True)
    db     = cargar_db(RESERVAS_DB)
    codigo = codigo.upper()
    if codigo not in db:
        await interaction.followup.send(embed=embed_von("❌ Código no encontrado", f"No existe `{codigo}`.", COLOR_NEGRO), ephemeral=True); return
    r = db[codigo]
    if r["usuario_id"] != str(interaction.user.id):
        await interaction.followup.send(embed=embed_von("❌ Sin permiso", "Esta reserva no te pertenece.", COLOR_NEGRO), ephemeral=True); return
    if r["estado"] != "confirmada":
        await interaction.followup.send(embed=embed_von("❌ Estado inválido", f"Estado actual: **{r['estado']}**.", COLOR_NEGRO), ephemeral=True); return
    r["estado"] = "checkin"
    guardar_db(RESERVAS_DB, db)
    if r.get("room_b44_id"):
        await b44.update_room_status(r["room_b44_id"], "occupied", r.get("usuario_nombre",""))
    if r.get("reserva_b44_id"):
        await b44.update_reservation(r["reserva_b44_id"], {"status": "active"})
    if interaction.guild:
        rol = discord.utils.get(interaction.guild.roles, name="Huésped")
        if rol:
            try: await interaction.user.add_roles(rol)
            except Exception: pass
    hab      = HABITACIONES[r["tipo"]]
    room_txt = f"Hab. #{r['room_numero']}" if r.get("room_numero") else hab["nombre"]
    e = discord.Embed(title="🔑 Check-In Completado",
                      description=f"¡Bienvenido, {interaction.user.mention}! Su habitación está lista.",
                      color=COLOR_DORADO)
    e.add_field(name="🏷️ Código",              value=f"`{codigo}`", inline=True)
    e.add_field(name=f"{hab['emoji']} Habitación", value=f"{hab['nombre']} — {room_txt}", inline=True)
    e.add_field(name="📋 Estado",              value="🟢 En estancia", inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.followup.send(embed=e, view=ViewPostCheckin(codigo))
    await b44.botlog("checkin", r.get("usuario_nombre","—"), str(interaction.user), f"Check-in {codigo}", "sent", room_txt)
    if interaction.guild:
        await log_staff(interaction.guild, embed_von("🔑 Check-in",
            f"**{interaction.user.display_name}** — `{codigo}` — {room_txt}", COLOR_NEGRO))

async def _ejecutar_checkout_logic(interaction: discord.Interaction, codigo: str):
    await interaction.response.defer(ephemeral=True)
    db     = cargar_db(RESERVAS_DB)
    codigo = codigo.upper()
    if codigo not in db:
        await interaction.followup.send(embed=embed_von("❌ Código no encontrado", f"No existe `{codigo}`.", COLOR_NEGRO), ephemeral=True); return
    r = db[codigo]
    if r["usuario_id"] != str(interaction.user.id):
        await interaction.followup.send(embed=embed_von("❌ Sin permiso", "Esta reserva no te pertenece.", COLOR_NEGRO), ephemeral=True); return
    if r["estado"] != "checkin":
        await interaction.followup.send(embed=embed_von("❌ Estado inválido", "Debes hacer check-in primero.", COLOR_NEGRO), ephemeral=True); return
    r["estado"] = "completada"
    guardar_db(RESERVAS_DB, db)
    if r.get("room_b44_id"):
        await b44.update_room_status(r["room_b44_id"], "cleaning")
    if r.get("reserva_b44_id"):
        await b44.update_reservation(r["reserva_b44_id"], {"status": "completed"})
    if interaction.guild:
        rol = discord.utils.get(interaction.guild.roles, name="Huésped")
        if rol and rol in interaction.user.roles:
            try: await interaction.user.remove_roles(rol)
            except Exception: pass
    hab      = HABITACIONES.get(r.get("tipo","doble"), HABITACIONES["doble"])
    room_txt = f"Hab. #{r['room_numero']}" if r.get("room_numero") else hab["nombre"]
    e = discord.Embed(title="🚪 Check-Out Completado",
                      description=f"Gracias por su visita, {interaction.user.mention}. ¡Le esperamos de nuevo!",
                      color=COLOR_DORADO)
    e.add_field(name="🏷️ Código",    value=f"`{codigo}`",          inline=True)
    e.add_field(name="🛏️ Habitación", value=room_txt,               inline=True)
    e.add_field(name="📋 Estado",    value="✅ Estancia completada", inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.followup.send(embed=e, view=ViewPostCheckout(), ephemeral=True)
    await b44.botlog("checkout", r.get("usuario_nombre","—"), str(interaction.user), f"Check-out {codigo}", "sent", room_txt)
    if interaction.guild:
        await log_staff(interaction.guild, embed_von("🚪 Check-out",
            f"**{interaction.user.display_name}** — `{codigo}` — {room_txt}", COLOR_NEGRO))
    # Enviar encuesta de valoración por DM
    ref = r.get("reserva_b44_id") or codigo
    await _enviar_valoracion_dm(interaction.user, ref)

async def _ejecutar_cancelar_logic(interaction: discord.Interaction, codigo: str):
    db     = cargar_db(RESERVAS_DB)
    codigo = codigo.upper()
    if codigo not in db:
        await _send(interaction, embed_von("❌ No encontrada", f"No existe `{codigo}`.", COLOR_NEGRO), ephemeral=True); return
    r = db[codigo]
    if r["usuario_id"] != str(interaction.user.id):
        await _send(interaction, embed_von("❌ Sin permiso", "Esta reserva no te pertenece.", COLOR_NEGRO), ephemeral=True); return
    if r["estado"] in ("completada","cancelada"):
        await _send(interaction, embed_von("❌ No cancelable", f"Estado: **{r['estado']}**.", COLOR_NEGRO), ephemeral=True); return
    r["estado"] = "cancelada"
    guardar_db(RESERVAS_DB, db)
    if r.get("room_b44_id"):
        await b44.update_room_status(r["room_b44_id"], "available")
    if r.get("reserva_b44_id"):
        await b44.update_reservation(r["reserva_b44_id"], {"status": "rejected"})
    room_txt = f"Hab. #{r['room_numero']}" if r.get("room_numero") else ""
    label    = f"`{codigo}`" + (f" — {room_txt}" if room_txt else "")
    await _send(interaction,
                embed_von("✅ Reserva cancelada", f"La reserva {label} ha sido cancelada.", COLOR_DORADO),
                ViewPostCancelar(), ephemeral=True)
    if interaction.guild:
        await log_staff(interaction.guild, embed_von("❌ Cancelación",
            f"**{interaction.user.display_name}** — `{codigo}`" + (f" — {room_txt}" if room_txt else ""), COLOR_NEGRO))

# ==========================================
# VIEWS — NAVEGACIÓN INTERACTIVA
# ==========================================

class ModalFechaReserva(discord.ui.Modal, title="¿Cuándo llega?"):
    fecha = discord.ui.TextInput(
        label="Fecha de llegada",
        placeholder="DD/MM/AAAA  (ej: 25/07/2026)",
        min_length=8, max_length=10,
    )
    def __init__(self, tipo: str):
        super().__init__()
        self.tipo = tipo

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        db  = cargar_db(RESERVAS_DB)
        hab = HABITACIONES[self.tipo]
        if contar_ocupadas(db, self.tipo) >= hab["total"]:
            await interaction.followup.send(
                embed=embed_von("❌ Sin disponibilidad", f"No quedan **{hab['nombre']}** libres.", COLOR_NEGRO),
                ephemeral=True)
            return
        codigo = generar_codigo_reserva()
        while codigo in db:
            codigo = generar_codigo_reserva()
        room          = await b44.get_available_room(self.tipo)
        room_b44_id   = room["id"] if room else None
        room_numero   = int(room.get("room_number", 0)) if room else 0
        reserva_b44   = await b44.create_reservation({
            "rp_name":    interaction.user.display_name,
            "discord_user": str(interaction.user),
            "check_in":   self.fecha.value,
            "check_out":  self.fecha.value,
            "guests":     1,
            "room_type":  b44.BOT_TO_B44.get(self.tipo, self.tipo),
            "room_id":    room_b44_id or "",
            "status":     "approved",
        })
        reserva_b44_id = reserva_b44["id"] if reserva_b44 else None
        if room_b44_id:
            await b44.update_room_status(room_b44_id, "reserved", interaction.user.display_name)
        reserva = {
            "codigo": codigo, "usuario_id": str(interaction.user.id),
            "usuario_nombre": interaction.user.display_name, "tipo": self.tipo,
            "fecha": self.fecha.value, "estado": "confirmada",
            "creada": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "room_b44_id": room_b44_id or "", "reserva_b44_id": reserva_b44_id or "",
            "room_numero": room_numero,
        }
        db[codigo] = reserva
        guardar_db(RESERVAS_DB, db)
        room_txt = f"Hab. #{room_numero}" if room_numero else hab["nombre"]
        e = discord.Embed(title="✨ Reserva Confirmada",
                          description=f"Bienvenido al **Von Crastenburg**, {interaction.user.mention}.\n*Su descanso es nuestro lujo.*",
                          color=COLOR_DORADO)
        e.add_field(name="🏷️ Código",                   value=f"`{codigo}`",                       inline=True)
        e.add_field(name=f"{hab['emoji']} Habitación",  value=f"{hab['nombre']} — {room_txt}",     inline=True)
        e.add_field(name="📅 Fecha",                    value=self.fecha.value,                    inline=True)
        e.add_field(name="💰 Precio",                   value=f"{hab['precio']} €/noche",          inline=True)
        e.add_field(name="📋 Estado",                   value="✅ Confirmada",                     inline=True)
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await interaction.followup.send(embed=e, view=ViewPostReserva(codigo), ephemeral=True)
        if interaction.guild:
            await log_staff(interaction.guild, embed_von("📋 Nueva reserva (web-modal)",
                f"**{interaction.user.display_name}** — `{codigo}` — {room_txt} — {self.fecha.value}", COLOR_NEGRO))


class ViewDisponibilidad(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label="Reservar Doble", emoji="🛏️", style=discord.ButtonStyle.secondary)
    async def btn_doble(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ModalFechaReserva("doble"))

    @discord.ui.button(label="Reservar Lujo", emoji="💎", style=discord.ButtonStyle.primary)
    async def btn_lujo(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ModalFechaReserva("lujo"))

    @discord.ui.button(label="Reservar Suite", emoji="👑", style=discord.ButtonStyle.success)
    async def btn_suite(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ModalFechaReserva("suite"))

    @discord.ui.button(label="Info del hotel", emoji="ℹ️", style=discord.ButtonStyle.secondary, row=1)
    async def btn_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _cmd_infohotel(interaction)


class ViewPostReserva(discord.ui.View):
    def __init__(self, codigo: str):
        super().__init__(timeout=600)
        self.codigo = codigo

    @discord.ui.button(label="Hacer check-in", emoji="🔑", style=discord.ButtonStyle.success)
    async def btn_checkin(self, interaction: discord.Interaction, button: discord.ui.Button):
        button.disabled = True
        await interaction.response.edit_message(view=self)
        await _ejecutar_checkin_logic(interaction, self.codigo)

    @discord.ui.button(label="Mis reservas", emoji="📋", style=discord.ButtonStyle.secondary)
    async def btn_mis_reservas(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _mostrar_mis_reservas(interaction)

    @discord.ui.button(label="Cancelar reserva", emoji="❌", style=discord.ButtonStyle.danger)
    async def btn_cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        button.disabled = True
        await interaction.response.edit_message(view=self)
        await _ejecutar_cancelar_logic(interaction, self.codigo)


class ViewPostCheckin(discord.ui.View):
    def __init__(self, codigo: str):
        super().__init__(timeout=None)
        self.codigo = codigo

    @discord.ui.button(label="Hacer checkout", emoji="🚪", style=discord.ButtonStyle.danger)
    async def btn_checkout(self, interaction: discord.Interaction, button: discord.ui.Button):
        button.disabled = True
        await interaction.response.edit_message(view=self)
        await _ejecutar_checkout_logic(interaction, self.codigo)

    @discord.ui.button(label="Mis reservas", emoji="📋", style=discord.ButtonStyle.secondary)
    async def btn_mis_reservas(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _mostrar_mis_reservas(interaction)


_URL_RESERVAS_WEB = "https://von-stay-luxe-revo-rp.base44.app/reservations"


class ViewPostCheckout(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(discord.ui.Button(
            label="Reservar en web", emoji="🌐",
            style=discord.ButtonStyle.link, url=_URL_RESERVAS_WEB))

    @discord.ui.button(label="Ver disponibilidad", emoji="🏨", style=discord.ButtonStyle.primary)
    async def btn_disp(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _cmd_disponibilidad(interaction)


class ViewPostCancelar(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(discord.ui.Button(
            label="Reservar en web", emoji="🌐",
            style=discord.ButtonStyle.link, url=_URL_RESERVAS_WEB))

    @discord.ui.button(label="Ver disponibilidad", emoji="🏨", style=discord.ButtonStyle.primary)
    async def btn_disp(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _cmd_disponibilidad(interaction)


class ViewInfoHotel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(discord.ui.Button(
            label="Reservar en web", emoji="🌐",
            style=discord.ButtonStyle.link, url=_URL_RESERVAS_WEB))

    @discord.ui.button(label="Ver disponibilidad", emoji="📋", style=discord.ButtonStyle.primary)
    async def btn_disp(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _cmd_disponibilidad(interaction)

    @discord.ui.button(label="Reservar ahora", emoji="🏨", style=discord.ButtonStyle.success)
    async def btn_reservar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            embed=embed_von("🏨 Reservar", "Elige tipo de habitación con `/reservar` o usa el botón desde `/disponibilidad`.", COLOR_DORADO),
            view=ViewDisponibilidad(), ephemeral=True)


class ViewPostRegistro(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label="Ver mi perfil", emoji="👤", style=discord.ButtonStyle.primary)
    async def btn_perfil(self, interaction: discord.Interaction, button: discord.ui.Button):
        db     = cargar_db(HOTEL_DB_FILE)
        uid    = str(interaction.user.id)
        if uid not in db:
            await interaction.response.send_message("No se encontró tu perfil.", ephemeral=True); return
        d = db[uid]
        e = discord.Embed(title=f"🏨 Ficha de {d['nombre']}", color=COLOR_DORADO)
        e.add_field(name="Rango",     value=d["rango"],              inline=True)
        e.add_field(name="Puntos",    value=str(d.get("puntos",0)),  inline=True)
        e.add_field(name="Registrado",value=d.get("registro","—"),   inline=True)
        e.set_thumbnail(url=interaction.user.display_avatar.url)
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await interaction.response.send_message(embed=e, view=ViewPerfil(), ephemeral=True)

    @discord.ui.button(label="Ver disponibilidad", emoji="🏨", style=discord.ButtonStyle.secondary)
    async def btn_disp(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _cmd_disponibilidad(interaction)

    @discord.ui.button(label="Solicitar empleo", emoji="💼", style=discord.ButtonStyle.secondary)
    async def btn_empleo(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            embed=embed_von("💼 Solicitar empleo", "Usa el comando `/solicitar_empleo` para enviar tu solicitud al equipo.", COLOR_DORADO),
            ephemeral=True)


class ViewPerfil(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label="Mis reservas", emoji="🏨", style=discord.ButtonStyle.primary)
    async def btn_reservas(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _mostrar_mis_reservas(interaction)

    @discord.ui.button(label="Ver disponibilidad", emoji="📋", style=discord.ButtonStyle.secondary)
    async def btn_disp(self, interaction: discord.Interaction, button: discord.ui.Button):
        await _cmd_disponibilidad(interaction)


class ViewIdea(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label="Otra idea", emoji="🎲", style=discord.ButtonStyle.primary)
    async def btn_otra(self, interaction: discord.Interaction, button: discord.ui.Button):
        e = discord.Embed(title="💡 Idea para el hotel", description=random.choice(IDEAS_HOTEL), color=COLOR_DORADO)
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await interaction.response.send_message(embed=e, view=ViewIdea(), ephemeral=True)

    @discord.ui.button(label="Ver evento", emoji="🎉", style=discord.ButtonStyle.secondary)
    async def btn_evento(self, interaction: discord.Interaction, button: discord.ui.Button):
        e = discord.Embed(title="🎉 Evento del Hotel", description=random.choice(EVENTOS_HOTEL), color=COLOR_DORADO)
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await interaction.response.send_message(embed=e, view=ViewEvento(), ephemeral=True)


class ViewEvento(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label="Otro evento", emoji="🎲", style=discord.ButtonStyle.primary)
    async def btn_otro(self, interaction: discord.Interaction, button: discord.ui.Button):
        e = discord.Embed(title="🎉 Evento del Hotel", description=random.choice(EVENTOS_HOTEL), color=COLOR_DORADO)
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await interaction.response.send_message(embed=e, view=ViewEvento(), ephemeral=True)

    @discord.ui.button(label="Ver ideas", emoji="💡", style=discord.ButtonStyle.secondary)
    async def btn_idea(self, interaction: discord.Interaction, button: discord.ui.Button):
        e = discord.Embed(title="💡 Idea para el hotel", description=random.choice(IDEAS_HOTEL), color=COLOR_DORADO)
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await interaction.response.send_message(embed=e, view=ViewIdea(), ephemeral=True)

# ==========================================
# EVENTO READY
# ==========================================

NOTIFIED_FILE = "notified_reservas.json"
NOTIFIED_JOBS_FILE = "notified_jobs.json"

def cargar_notified(path):
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump([], f)
    with open(path, "r") as f:
        return set(json.load(f))

def guardar_notified(path, s: set):
    with open(path, "w") as f:
        json.dump(list(s), f)

async def buscar_usuario_discord(discord_user: str, discord_id: str | None = None):
    if discord_id:
        try:
            return await bot.fetch_user(int(discord_id))
        except Exception:
            pass
    base_name = discord_user.split("#")[0].lower().strip()
    for guild in bot.guilds:
        for m in guild.members:
            if m.name.lower() == base_name or m.display_name.lower() == base_name:
                return m
    return None

async def _dm_reserva_base44(res: dict):
    COLOR_DORADO = 0xD4AF37
    ROOM_MAP = {
        "standard":     ("🛏️", "Habitación Estándar", 150),
        "deluxe":       ("💎", "Deluxe",              300),
        "vip_suite":    ("👑", "Suite VIP",           500),
        "presidential": ("🌟", "Suite Presidencial",  800),
    }
    discord_user = res.get("discord_user", "")
    rp_name      = res.get("rp_name", discord_user)

    guest = await b44.get_guest_by_discord_user(discord_user) or await b44.get_guest_by_rp_name(rp_name)
    discord_id = guest.get("discord_id") if guest else None

    user = await buscar_usuario_discord(discord_user, discord_id)
    if not user:
        print(f"[Polling] ⚠️ No se encontró usuario Discord: {discord_user}")
        await b44.botlog("reservation", rp_name, discord_user, "Usuario no encontrado en Discord", "failed")
        return

    room_type = res.get("room_type", "standard")
    emoji, nombre_hab, precio = ROOM_MAP.get(room_type, ("🏨", room_type.capitalize(), 0))
    rid = res.get("id", "N/A")

    personas_raw = res.get("guests", "1")
    try:
        personas = str(int(float(personas_raw)))
    except (ValueError, TypeError):
        personas = str(personas_raw)

    e = discord.Embed(
        title="✨ Reserva Recibida — Von Crastenburg",
        description=(
            f"Estimado/a **{rp_name}**,\n"
            "su reserva ha sido recibida y está siendo procesada por nuestro equipo.\n"
            "*Su descanso es nuestro lujo.*"
        ),
        color=COLOR_DORADO,
    )
    # Fila 1: Habitación · Personas · Precio (3 columnas)
    e.add_field(name=f"{emoji} Habitación",  value=nombre_hab,           inline=True)
    e.add_field(name="👥 Personas",          value=personas,             inline=True)
    e.add_field(name="💰 Precio",            value=f"{precio} €/noche" if precio else "—", inline=True)
    # Fila 2: Entrada · Salida · (espacio) (3 columnas)
    e.add_field(name="📅 Entrada",           value=res.get("check_in",  "—"), inline=True)
    e.add_field(name="📅 Salida",            value=res.get("check_out", "—"), inline=True)
    e.add_field(name="\u200b",               value="\u200b",             inline=True)
    # Fila 3: campos anchos
    e.add_field(name="🏷️ ID de reserva",    value=f"`{rid}`",           inline=False)
    e.add_field(name="📋 Estado",            value="⏳ Pendiente de aprobación", inline=False)
    e.add_field(name="🌐 Gestionar reserva", value="[Portal VonStay](https://von-stay-luxe-revo-rp.base44.app/reservations)", inline=False)
    if res.get("comments"):
        e.add_field(name="💬 Comentarios",         value=res["comments"][:200],            inline=False)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    _con_logo(e)

    try:
        await user.send(embed=e, file=_logo_file(), view=_view_checkinout_dm(rid))
        preview = f"{nombre_hab} | {res.get('check_in','?')} → {res.get('check_out','?')}"
        await b44.botlog("reservation", rp_name, discord_user, preview, "sent", f"ID:{rid}")
        print(f"[Polling] ✅ DM enviado a {user} — reserva {rid}")
    except discord.Forbidden:
        await b44.botlog("reservation", rp_name, discord_user, "DMs cerrados", "failed", f"ID:{rid}")
        print(f"[Polling] ⚠️ DMs cerrados para {user}")

async def _dm_trabajo_base44(job: dict, accepted: bool):
    COLOR_DORADO = 0xD4AF37
    COLOR_NEGRO  = 0x1C1C1C
    discord_user = job.get("discord", "")
    rp_name      = job.get("rp_name", discord_user)
    position     = job.get("position", "puesto")
    jid          = job.get("id", "N/A")

    user = await buscar_usuario_discord(discord_user)
    if not user:
        print(f"[JobPoll] ⚠️ No se encontró: {discord_user}")
        return

    if accepted:
        e = discord.Embed(
            title="✅ Solicitud de Empleo Aceptada",
            description=f"**{rp_name}**, ¡felicidades! Has sido aceptado/a como **{position}** en el Von Crastenburg Hotel.\nEl staff se pondrá en contacto contigo pronto.",
            color=COLOR_DORADO,
        )
        e.add_field(name="👤 Usuario", value=job.get("generated_username", "Se asignará pronto"), inline=True)
        e.add_field(name="🔑 Contraseña", value=job.get("generated_password", "Se asignará pronto"), inline=True)
    else:
        e = discord.Embed(
            title="❌ Solicitud de Empleo No Aceptada",
            description=f"**{rp_name}**, lamentablemente tu solicitud para **{position}** no ha sido seleccionada en esta ocasión.\nPuedes volver a intentarlo más adelante.",
            color=COLOR_NEGRO,
        )
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    _con_logo(e)

    try:
        await user.send(embed=e, file=_logo_file())
        tipo = "job_accepted" if accepted else "job_rejected"
        await b44.botlog(tipo, rp_name, discord_user, f"Solicitud {position}", "sent", f"ID:{jid}")
        print(f"[JobPoll] ✅ DM enviado a {user} — trabajo {jid}")
    except discord.Forbidden:
        print(f"[JobPoll] ⚠️ DMs cerrados para {user}")

async def polling_reservas():
    await bot.wait_until_ready()
    await asyncio.sleep(15)
    print("[Polling] Iniciado — revisando reservas y solicitudes cada 60s")
    notified     = cargar_notified(NOTIFIED_FILE)
    notified_jobs = cargar_notified(NOTIFIED_JOBS_FILE)
    while not bot.is_closed():
        try:
            reservas = await b44.get_reservations(status="pending", limit=30)
            for res in reservas:
                rid = res.get("id")
                if rid and rid not in notified:
                    await _dm_reserva_base44(res)
                    notified.add(rid)
                    guardar_notified(NOTIFIED_FILE, notified)
                    await asyncio.sleep(1)

            for status in ("accepted", "rejected"):
                jobs = await b44.get_job_applications(status=status, limit=20)
                for job in jobs:
                    jid = job.get("id")
                    if jid and jid not in notified_jobs:
                        await _dm_trabajo_base44(job, accepted=(status == "accepted"))
                        notified_jobs.add(jid)
                        guardar_notified(NOTIFIED_JOBS_FILE, notified_jobs)
                        await asyncio.sleep(1)
        except Exception as ex:
            print(f"[Polling] Error: {ex}")
        await asyncio.sleep(60)

@bot.event
async def on_ready():
    global _views_registrados
    print(f"Conectado como {bot.user}")
    if not _views_registrados:
        bot.add_view(TicketView())
        bot.add_view(CerrarTicketView())
        bot.add_view(TicketReservaView())
        bot.add_view(ReservaTicketControlView())
        bot.add_view(PanelFicharView())
        _views_registrados = True
        print("Vistas persistentes (tickets) registradas")
    try:
        synced = await bot.tree.sync()
        print(f"Slash commands sincronizados: {len(synced)}")
        for guild in bot.guilds:
            await bot.tree.sync(guild=guild)
            print(f"  → {guild.name}")
    except Exception as e:
        print(f"Error sync: {e}")
    global _tareas_fondo_iniciadas
    if not _tareas_fondo_iniciadas:
        bot.loop.create_task(polling_reservas())
        bot.loop.create_task(tarea_panel_habitaciones())
        bot.loop.create_task(tarea_panel_turnos())
        bot.loop.create_task(tarea_resumen_semanal())
        bot.loop.create_task(tarea_alertas_mantenimiento())
        bot.loop.create_task(tarea_log_diario())
        _tareas_fondo_iniciadas = True

_mensajes_procesados: "OrderedDict[int, None]" = OrderedDict()
_MAX_MENSAJES_PROCESADOS = 2000

_DEDUP_FILE = "mensajes_procesados.lock"

def _ya_procesado(message_id: int) -> bool:
    """Evita procesar dos veces el mismo mensaje.

    Motivos posibles de duplicado: el gateway de Discord reenvía el evento
    tras una reconexión/resume, o (más frecuente en este entorno) durante un
    restart del workflow hay una breve ventana en la que el proceso anterior
    todavía está vivo/conectado mientras el nuevo ya arrancó, y ambos reciben
    y responden al mismo mensaje. El chequeo en memoria (_mensajes_procesados)
    no sirve entre procesos distintos, así que además se usa un fichero con
    flock para que sea una comprobación atómica entre procesos."""
    if message_id in _mensajes_procesados:
        return True
    _mensajes_procesados[message_id] = None
    if len(_mensajes_procesados) > _MAX_MENSAJES_PROCESADOS:
        _mensajes_procesados.popitem(last=False)

    import fcntl
    try:
        with open(_DEDUP_FILE, "a+") as f:
            fcntl.flock(f, fcntl.LOCK_EX)
            try:
                f.seek(0)
                vistos = f.read().split()
                if str(message_id) in vistos:
                    return True
                f.write(f"{message_id}\n")
                f.flush()
                if len(vistos) + 1 > _MAX_MENSAJES_PROCESADOS:
                    f.seek(0)
                    f.truncate()
                    f.write("\n".join(vistos[-(_MAX_MENSAJES_PROCESADOS // 2):] + [str(message_id)]) + "\n")
                    f.flush()
            finally:
                fcntl.flock(f, fcntl.LOCK_UN)
    except OSError as ex:
        print(f"[Dedup] No se pudo verificar el fichero de dedup: {ex}")

    return False

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return
    if _ya_procesado(message.id):
        return

    contenido = (message.content or "").strip()

    # 0) "/parar" y "/hablar": pausan/reanudan el chat automático de IA en este canal
    #    (solo staff/moderación, para que no cualquiera pueda silenciar al bot)
    minuscula = contenido.lower()
    if minuscula in ("/parar", "/hablar"):
        if not (isinstance(message.author, discord.Member) and _es_staff_member(message.author)):
            await message.channel.send("Solo el staff puede activar o desactivar mi chat automático en este canal.", delete_after=8)
            return
        if minuscula == "/parar":
            _pausar_canal_ia(message.channel.id)
            await message.channel.send("🔇 He dejado de responder automáticamente en este canal. Escribe `/hablar` para reactivarme.")
        else:
            _reanudar_canal_ia(message.channel.id)
            await message.channel.send("🗣️ Ya vuelvo a responder automáticamente en este canal.")
        return

    # 1) Moderación automática por IA en todos los canales — se evalúa primero y,
    #    si el mensaje se marca como infracción, corta el resto de flujos de IA
    #    (ticket, detección de duda, chat general) para no enviar dos mensajes
    #    distintos de la IA como respuesta a un único mensaje del usuario.
    fue_moderado = False
    if contenido:
        try:
            fue_moderado = await _moderar_mensaje_ia(message, contenido)
        except Exception as ex:
            print(f"[Moderación IA] Error analizando mensaje de {message.author}: {ex}")

    # 1.5) Detección de escalada grupal — solo en canales públicos no gestionados por IA
    _canal_id_str = str(message.channel.id)
    _es_canal_ticket = (
        _canal_id_str in _tickets_ia_activos()
        or _canal_id_str in _tickets_reserva_activos()
    )
    if contenido and not fue_moderado and not _es_canal_ticket:
        try:
            await _verificar_escalada_grupal(message, contenido)
        except Exception as ex:
            print(f"[Escalada grupal] Error en {message.channel.id}: {ex}")

    # 1.7) Tickets de RESERVAS — Agente de Reservas IA dedicado (siempre activo)
    en_ticket_reserva = bool(contenido) and _canal_id_str in _tickets_reserva_activos()
    if en_ticket_reserva and not fue_moderado:
        try:
            await _responder_ia_reserva(message, contenido)
        except Exception as ex:
            print(f"[IA Reservas] Error respondiendo en {message.channel.id}: {ex}")

    # 2) Tickets de soporte con IA general activada (excluye canales de reservas)
    en_ticket_ia = (
        bool(contenido)
        and not en_ticket_reserva
        and _canal_id_str in _tickets_ia_activos()
    )
    if en_ticket_ia and not fue_moderado:
        try:
            await _responder_ia_ticket(message, contenido)
        except Exception as ex:
            print(f"[IA Ticket] Error respondiendo en {message.channel.id}: {ex}")

    # 3) Detección de dudas: solo en el canal configurado, ofrece abrir ticket
    #    (si se detecta duda, NO se responde también con el chat general para
    #    evitar que el usuario reciba dos mensajes de la IA por el mismo mensaje)
    fue_duda = False
    if (contenido and not en_ticket_ia and not en_ticket_reserva
            and not fue_moderado and message.channel.id == ID_CANAL_DUDAS):
        try:
            fue_duda = await _detectar_y_ofrecer_ticket(message, contenido)
        except Exception as ex:
            print(f"[Detección duda] Error analizando mensaje de {message.author}: {ex}")

    # 4) Chat automático en canales generales (excluye tickets, moderados, comandos "!")
    if (
        contenido
        and not en_ticket_ia
        and not en_ticket_reserva
        and not fue_moderado
        and not fue_duda
        and not contenido.startswith("!")
        and not _canal_ia_pausada(message.channel.id)
    ):
        try:
            await _responder_ia_general(message, contenido)
        except Exception as ex:
            print(f"[Chat IA] Error respondiendo en {message.channel.id}: {ex}")

    await bot.process_commands(message)


@bot.event
async def on_member_join(member):
    # Auto-registro con el nombre de Discord del usuario
    db  = cargar_db(HOTEL_DB_FILE)
    uid = str(member.id)
    if uid not in db:
        db[uid] = {
            "nombre":    member.display_name,
            "rango":     "Visitante",
            "registro":  datetime.now().strftime("%d/%m/%Y"),
            "puntos":    0,
        }
        guardar_db(HOTEL_DB_FILE, db)

    canal = discord.utils.get(member.guild.text_channels, name="bienvenida") or member.guild.system_channel
    if canal:
        e = discord.Embed(
            title=f"🏨 ¡Bienvenido/a a {member.guild.name}!",
            description=(
                f"¡Hola {member.mention}! 👋\n\n"
                f"Has sido registrado/a automáticamente como **{member.display_name}**.\n\n"
                "**¿Qué puedes hacer aquí?**\n"
                "• `/perfil` — Consulta tu ficha de empleado/huésped\n"
                "• `/reservar` — Reserva una habitación del hotel\n"
                "• `/saldo` — Consulta tu saldo de VonCoins (€)\n\n"
                "**🌐 Portal web del hotel:**\n"
                "Gestiona tus reservas y mucho más desde nuestra web:\n"
                "🔗 **https://von-stay-luxe-revo-rp.base44.app**\n\n"
                "¡Esperamos que disfrutes tu estancia en **Von Crastenburg Hotel**! 🥂"
            ),
            color=COLOR_DORADO,
        )
        e.set_thumbnail(url=member.display_avatar.url)
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await canal.send(embed=e)


# ==========================================
# COMANDOS HOTEL
# ==========================================

@bot.tree.command(name="registro", description="Regístrate en el Hotel RP")
@app_commands.describe(nombre="Tu nombre de personaje")
async def registro(interaction: discord.Interaction, nombre: str):
    db  = cargar_db(HOTEL_DB_FILE)
    uid = str(interaction.user.id)
    if uid in db:
        await interaction.response.send_message("Ya estás registrado. Usa `/perfil`.", ephemeral=True); return
    db[uid] = {"nombre": nombre, "rango": "Visitante", "registro": interaction.created_at.strftime("%d/%m/%Y"), "puntos": 0}
    guardar_db(HOTEL_DB_FILE, db)
    e = discord.Embed(title="✅ Registro completado", description=f"¡Bienvenido/a, **{nombre}**! Tu rango: **Visitante**.", color=COLOR_DORADO)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await _responder_anonimo(interaction, embed=e, view=ViewPostRegistro())

@bot.tree.command(name="perfil", description="Ver tu perfil o el de otro usuario")
@app_commands.describe(usuario="Usuario (opcional)")
async def perfil(interaction: discord.Interaction, usuario: discord.User | None = None):
    db     = cargar_db(HOTEL_DB_FILE)
    target = usuario or interaction.user
    uid    = str(target.id)
    if uid not in db:
        await interaction.response.send_message("Ese usuario no está registrado.", ephemeral=True); return
    d = db[uid]
    e = discord.Embed(title=f"🏨 Ficha de {d['nombre']}", color=COLOR_DORADO)
    e.add_field(name="Rango", value=d["rango"], inline=True)
    e.add_field(name="Puntos", value=str(d.get("puntos",0)), inline=True)
    e.add_field(name="Registrado", value=d.get("registro","—"), inline=True)
    e.set_thumbnail(url=target.display_avatar.url)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    es_propio = (target.id == interaction.user.id)
    view = ViewPerfil() if es_propio else None
    await _responder_anonimo(interaction, embed=e, view=view)

@bot.tree.command(name="rangoset", description="[Staff] Cambiar el rango de un usuario")
@app_commands.describe(usuario="Usuario", rango="Nuevo rango")
@app_commands.choices(rango=[app_commands.Choice(name=r, value=r) for r in RANGOS])
async def rangoset(interaction: discord.Interaction, usuario: discord.User, rango: str):
    if not interaction.user.guild_permissions.manage_roles:
        await interaction.response.send_message("Sin permisos.", ephemeral=True); return
    db  = cargar_db(HOTEL_DB_FILE)
    uid = str(usuario.id)
    if uid not in db:
        await interaction.response.send_message("Ese usuario no está registrado.", ephemeral=True); return
    db[uid]["rango"] = rango
    guardar_db(HOTEL_DB_FILE, db)
    await _responder_anonimo(interaction, embed=discord.Embed(description=f"✅ Rango de **{db[uid]['nombre']}** → **{rango}**", color=COLOR_DORADO))

@bot.tree.command(name="idea", description="Obtén una idea creativa para el hotel RP")
async def idea(interaction: discord.Interaction):
    e = discord.Embed(title="💡 Idea para el hotel", description=random.choice(IDEAS_HOTEL), color=COLOR_DORADO)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await _responder_anonimo(interaction, embed=e, view=ViewIdea())

@bot.tree.command(name="evento", description="Genera un evento aleatorio para el hotel RP")
async def evento(interaction: discord.Interaction):
    e = discord.Embed(title="🎉 Evento del Hotel", description=random.choice(EVENTOS_HOTEL), color=COLOR_DORADO)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await _responder_anonimo(interaction, embed=e, view=ViewEvento())

# ==========================================
# COMANDOS VONSTAAY — RESERVAS
# ==========================================

@bot.tree.command(name="reservar", description="🏨 Reserva una habitación en el Von Crastenburg")
@app_commands.describe(tipo="Tipo de habitación", fecha="Fecha de llegada (ej: 25/07/2026)")
@app_commands.choices(tipo=[
    app_commands.Choice(name="👑 Suite Royal (500 €/noche)",      value="suite"),
    app_commands.Choice(name="🛏️ Habitación Doble (200 €/noche)", value="doble"),
    app_commands.Choice(name="💎 Suite de Lujo (350 €/noche)",    value="lujo"),
])
async def reservar(interaction: discord.Interaction, tipo: str, fecha: str):
    await interaction.response.defer(ephemeral=True)
    db  = cargar_db(RESERVAS_DB)
    hab = HABITACIONES[tipo]

    if contar_ocupadas(db, tipo) >= hab["total"]:
        await interaction.followup.send(embed=embed_von("❌ Sin disponibilidad", f"No quedan **{hab['nombre']}** libres.", COLOR_NEGRO), ephemeral=True)
        return

    codigo = generar_codigo_reserva()
    while codigo in db:
        codigo = generar_codigo_reserva()

    # Buscar habitación libre en Base44 y marcarla como reservada
    room = await b44.get_available_room(tipo)
    room_b44_id  = room["id"]   if room else None
    room_numero  = int(room.get("room_number", 0)) if room else 0
    reserva_b44  = await b44.create_reservation({
        "rp_name":    interaction.user.display_name,
        "discord_user": str(interaction.user),
        "check_in":   fecha,
        "check_out":  fecha,
        "guests":     1,
        "room_type":  b44.BOT_TO_B44.get(tipo, tipo),
        "room_id":    room_b44_id or "",
        "status":     "approved",
    })
    reserva_b44_id = reserva_b44["id"] if reserva_b44 else None

    if room_b44_id:
        await b44.update_room_status(room_b44_id, "reserved", interaction.user.display_name)

    reserva = {
        "codigo":          codigo,
        "usuario_id":      str(interaction.user.id),
        "usuario_nombre":  interaction.user.display_name,
        "tipo":            tipo,
        "fecha":           fecha,
        "estado":          "confirmada",
        "creada":          datetime.now().strftime("%d/%m/%Y %H:%M"),
        "room_b44_id":     room_b44_id or "",
        "reserva_b44_id":  reserva_b44_id or "",
        "room_numero":     room_numero,
    }
    db[codigo] = reserva
    guardar_db(RESERVAS_DB, db)

    room_txt = f"Hab. #{room_numero}" if room_numero else hab["nombre"]
    e = discord.Embed(title="✨ Reserva Confirmada", description=f"Bienvenido al **Von Crastenburg**, {interaction.user.mention}.\n*Su descanso es nuestro lujo.*", color=COLOR_DORADO)
    e.add_field(name="🏷️ Código",                    value=f"`{codigo}`",               inline=True)
    e.add_field(name=f"{hab['emoji']} Habitación",   value=f"{hab['nombre']} — {room_txt}", inline=True)
    e.add_field(name="📅 Fecha",                     value=fecha,                       inline=True)
    e.add_field(name="💰 Precio",                    value=f"{hab['precio']} €/noche",  inline=True)
    e.add_field(name="📋 Estado",                    value="✅ Confirmada",             inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.followup.send("✅ Reserva confirmada.", ephemeral=True)
    await interaction.channel.send(embed=e, view=ViewPostReserva(codigo))

    if interaction.guild:
        await log_staff(interaction.guild, embed_von("📋 Nueva reserva", f"**{interaction.user.display_name}** — `{codigo}` — {room_txt} — {fecha}", COLOR_NEGRO))

@bot.tree.command(name="checkin", description="🔑 Realiza el check-in con tu código de reserva")
@app_commands.describe(codigo="Código de reserva (ej: VC12345)")
async def checkin(interaction: discord.Interaction, codigo: str):
    await interaction.response.defer(ephemeral=True)
    db     = cargar_db(RESERVAS_DB)
    codigo = codigo.upper()

    if codigo not in db:
        await interaction.followup.send(embed=embed_von("❌ Código no encontrado", f"No existe la reserva `{codigo}`.", COLOR_NEGRO), ephemeral=True); return
    r = db[codigo]
    if r["usuario_id"] != str(interaction.user.id):
        await interaction.followup.send(embed=embed_von("❌ Sin permiso", "Esta reserva no te pertenece.", COLOR_NEGRO), ephemeral=True); return
    if r["estado"] != "confirmada":
        await interaction.followup.send(embed=embed_von("❌ Estado inválido", f"Estado actual: **{r['estado']}**.", COLOR_NEGRO), ephemeral=True); return

    r["estado"] = "checkin"
    guardar_db(RESERVAS_DB, db)

    # Base44: habitación → occupied, reserva → active
    if r.get("room_b44_id"):
        await b44.update_room_status(r["room_b44_id"], "occupied", r.get("usuario_nombre", ""))
    if r.get("reserva_b44_id"):
        await b44.update_reservation(r["reserva_b44_id"], {"status": "active"})

    if interaction.guild:
        rol = discord.utils.get(interaction.guild.roles, name="Huésped")
        if rol:
            try: await interaction.user.add_roles(rol)
            except Exception: pass

    hab      = HABITACIONES[r["tipo"]]
    room_txt = f"Hab. #{r['room_numero']}" if r.get("room_numero") else hab["nombre"]
    e   = discord.Embed(title="🔑 Check-In Completado", description=f"¡Bienvenido, {interaction.user.mention}! Su habitación está lista.", color=COLOR_DORADO)
    e.add_field(name="🏷️ Código",              value=f"`{codigo}`", inline=True)
    e.add_field(name=f"{hab['emoji']} Habitación", value=f"{hab['nombre']} — {room_txt}", inline=True)
    e.add_field(name="📋 Estado",              value="🟢 En estancia", inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.followup.send("✅ Check-in completado.", ephemeral=True)
    await interaction.channel.send(embed=e, view=ViewPostCheckin(codigo))

    await b44.botlog("checkin", r.get("usuario_nombre", "—"), str(interaction.user), f"Check-in {codigo}", "sent", room_txt)
    if interaction.guild:
        await log_staff(interaction.guild, embed_von("🔑 Check-in", f"**{interaction.user.display_name}** — `{codigo}` — {room_txt}", COLOR_NEGRO))

@bot.tree.command(name="checkout", description="🚪 Realiza el check-out de tu estancia")
@app_commands.describe(codigo="Código de reserva (ej: VC12345)")
async def checkout(interaction: discord.Interaction, codigo: str):
    await interaction.response.defer(ephemeral=True)
    db     = cargar_db(RESERVAS_DB)
    codigo = codigo.upper()

    if codigo not in db:
        await interaction.followup.send(embed=embed_von("❌ Código no encontrado", f"No existe la reserva `{codigo}`.", COLOR_NEGRO), ephemeral=True); return
    r = db[codigo]
    if r["usuario_id"] != str(interaction.user.id):
        await interaction.followup.send(embed=embed_von("❌ Sin permiso", "Esta reserva no te pertenece.", COLOR_NEGRO), ephemeral=True); return
    if r["estado"] != "checkin":
        await interaction.followup.send(embed=embed_von("❌ Estado inválido", "Debes hacer check-in primero.", COLOR_NEGRO), ephemeral=True); return

    r["estado"] = "completada"
    guardar_db(RESERVAS_DB, db)

    # Base44: habitación → available (limpieza), reserva → completed
    if r.get("room_b44_id"):
        await b44.update_room_status(r["room_b44_id"], "cleaning")
    if r.get("reserva_b44_id"):
        await b44.update_reservation(r["reserva_b44_id"], {"status": "completed"})

    if interaction.guild:
        rol = discord.utils.get(interaction.guild.roles, name="Huésped")
        if rol and rol in interaction.user.roles:
            try: await interaction.user.remove_roles(rol)
            except Exception: pass

    hab      = HABITACIONES.get(r.get("tipo", "doble"), HABITACIONES["doble"])
    room_txt = f"Hab. #{r['room_numero']}" if r.get("room_numero") else hab["nombre"]
    e = discord.Embed(title="🚪 Check-Out Completado", description=f"Gracias por su visita, {interaction.user.mention}. ¡Le esperamos de nuevo!", color=COLOR_DORADO)
    e.add_field(name="🏷️ Código",    value=f"`{codigo}`",          inline=True)
    e.add_field(name="🛏️ Habitación", value=room_txt,               inline=True)
    e.add_field(name="📋 Estado",    value="✅ Estancia completada", inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.followup.send("✅ Check-out completado.", ephemeral=True)
    await interaction.channel.send(embed=e, view=ViewPostCheckout())

    await b44.botlog("checkout", r.get("usuario_nombre", "—"), str(interaction.user), f"Check-out {codigo}", "sent", room_txt)
    if interaction.guild:
        await log_staff(interaction.guild, embed_von("🚪 Check-out", f"**{interaction.user.display_name}** — `{codigo}` — {room_txt}", COLOR_NEGRO))

@bot.tree.command(name="disponibilidad", description="📋 Ver habitaciones disponibles y precios")
async def disponibilidad(interaction: discord.Interaction):
    await _cmd_disponibilidad(interaction, anonimo=True)

@bot.tree.command(name="cancelar", description="❌ Cancela tu reserva")
@app_commands.describe(codigo="Código de reserva (ej: VC12345)")
async def cancelar(interaction: discord.Interaction, codigo: str):
    db     = cargar_db(RESERVAS_DB)
    codigo = codigo.upper()
    if codigo not in db:
        await interaction.response.send_message(embed=embed_von("❌ Código no encontrado", f"No existe `{codigo}`.", COLOR_NEGRO), ephemeral=True); return
    r = db[codigo]
    if r["usuario_id"] != str(interaction.user.id):
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Esta reserva no te pertenece.", COLOR_NEGRO), ephemeral=True); return
    if r["estado"] in ("completada","cancelada"):
        await interaction.response.send_message(embed=embed_von("❌ No cancelable", f"Estado: **{r['estado']}**.", COLOR_NEGRO), ephemeral=True); return
    r["estado"] = "cancelada"
    guardar_db(RESERVAS_DB, db)

    # Base44: habitación → available, reserva → rejected
    if r.get("room_b44_id"):
        await b44.update_room_status(r["room_b44_id"], "available")
    if r.get("reserva_b44_id"):
        await b44.update_reservation(r["reserva_b44_id"], {"status": "rejected"})

    room_txt = f"Hab. #{r['room_numero']}" if r.get("room_numero") else ""
    label    = f"`{codigo}`" + (f" — {room_txt}" if room_txt else "")
    await interaction.response.send_message(embed=embed_von("✅ Reserva cancelada", f"La reserva {label} ha sido cancelada.", COLOR_DORADO), view=ViewPostCancelar(), ephemeral=True)
    if interaction.guild:
        await log_staff(interaction.guild, embed_von("❌ Cancelación", f"**{interaction.user.display_name}** — `{codigo}`" + (f" — {room_txt}" if room_txt else ""), COLOR_NEGRO))

@bot.tree.command(name="infohotel", description="ℹ️ Información y servicios del Von Crastenburg Hotel")
async def infohotel(interaction: discord.Interaction):
    await _cmd_infohotel(interaction, anonimo=True)

@bot.tree.command(name="verreservas", description="[Staff] Ver todas las reservas activas")
async def verreservas(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso","Solo el staff puede usar este comando.", COLOR_NEGRO), ephemeral=True); return
    db      = cargar_db(RESERVAS_DB)
    activas = [r for r in db.values() if r.get("estado") in ("confirmada","checkin")]
    if not activas:
        await interaction.response.send_message(embed=embed_von("📋 Sin reservas activas","No hay reservas activas.", COLOR_DORADO), ephemeral=True); return
    e = discord.Embed(title="📋 Reservas Activas — Von Crastenburg", color=COLOR_DORADO)
    for r in activas[:15]:
        hab = HABITACIONES.get(r["tipo"], {})
        e.add_field(
            name=f"{hab.get('emoji','🏨')} `{r['codigo']}` — {r['usuario_nombre']}",
            value=f"{hab.get('nombre', r['tipo'])} | {r['fecha']} | **{r['estado']}**",
            inline=False
        )
    e.set_footer(text=f"Total: {len(activas)} activas • VonStay")
    await interaction.response.send_message(embed=e, ephemeral=True)

@bot.tree.command(name="anunciar", description="[Staff] Publicar un anuncio oficial del hotel por canal y DM")
@app_commands.describe(titulo="Título del anuncio", mensaje="Contenido")
async def anunciar(interaction: discord.Interaction, titulo: str, mensaje: str):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso","Solo el staff puede usar este comando.", COLOR_NEGRO), ephemeral=True); return

    await interaction.response.defer(ephemeral=True, thinking=True)

    e = discord.Embed(title=f"📢 {titulo}", description=mensaje, color=COLOR_DORADO)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    _con_logo(e)

    # Publicar en el canal donde se ha escrito el comando, sin revelar quién lo envió
    await interaction.channel.send(embed=e, file=_logo_file())

    # Enviar por DM a todos los miembros del servidor y darles el rol automáticamente
    rol = interaction.guild.get_role(ID_ROL_ANUNCIO)
    enviados, fallidos, con_rol = 0, 0, 0

    for miembro in interaction.guild.members:
        if miembro.bot:
            continue
        try:
            await miembro.send(embed=e, file=_logo_file())
            enviados += 1
        except (discord.Forbidden, discord.HTTPException):
            fallidos += 1
            continue

        if rol and rol not in miembro.roles:
            try:
                await miembro.add_roles(rol)
                con_rol += 1
            except (discord.Forbidden, discord.HTTPException):
                pass

    await interaction.followup.send(
        embed=embed_von(
            "✅ Anuncio enviado",
            f"Publicado en el canal y enviado por DM a **{enviados}** miembro(s).\n"
            + (f"⚠️ No se pudo enviar DM a {fallidos} miembro(s) (DMs cerrados).\n" if fallidos else "")
            + (f"🏷️ Rol asignado a {con_rol} miembro(s)." if rol else "⚠️ No se encontró el rol configurado para asignar."),
            COLOR_DORADO,
        ),
        ephemeral=True,
    )

# ==========================================
# SISTEMA DE TICKETS
# ==========================================

def _tickets_ia_activos() -> set:
    return set(cargar_db(TICKETS_IA_DB).get("canales", []))

def _activar_ia_ticket(channel_id: int):
    db = cargar_db(TICKETS_IA_DB)
    canales = set(db.get("canales", []))
    canales.add(str(channel_id))
    db["canales"] = list(canales)
    guardar_db(TICKETS_IA_DB, db)

def _desactivar_ia_ticket(channel_id: int):
    db = cargar_db(TICKETS_IA_DB)
    canales = set(db.get("canales", []))
    canales.discard(str(channel_id))
    db["canales"] = list(canales)
    guardar_db(TICKETS_IA_DB, db)


# ── Tickets de Reservas (Agente Reservas IA) ───────────────────────────────

def _tickets_reserva_activos() -> set:
    return set(cargar_db(TICKETS_RESERVA_DB).get("canales", []))

def _activar_ticket_reserva(channel_id: int):
    db = cargar_db(TICKETS_RESERVA_DB)
    canales = set(db.get("canales", []))
    canales.add(str(channel_id))
    db["canales"] = list(canales)
    guardar_db(TICKETS_RESERVA_DB, db)

def _desactivar_ticket_reserva(channel_id: int):
    db = cargar_db(TICKETS_RESERVA_DB)
    canales = set(db.get("canales", []))
    canales.discard(str(channel_id))
    db["canales"] = list(canales)
    guardar_db(TICKETS_RESERVA_DB, db)


# ==========================================
# CHAT AUTOMÁTICO DE IA EN TODOS LOS CANALES
# ==========================================

def _canal_ia_pausada(channel_id: int) -> bool:
    db = cargar_db(CANALES_PAUSA_DB)
    return str(channel_id) in set(db.get("canales", []))

def _pausar_canal_ia(channel_id: int):
    db = cargar_db(CANALES_PAUSA_DB)
    canales = set(db.get("canales", []))
    canales.add(str(channel_id))
    db["canales"] = list(canales)
    guardar_db(CANALES_PAUSA_DB, db)

def _reanudar_canal_ia(channel_id: int):
    db = cargar_db(CANALES_PAUSA_DB)
    canales = set(db.get("canales", []))
    canales.discard(str(channel_id))
    db["canales"] = list(canales)
    guardar_db(CANALES_PAUSA_DB, db)


async def _responder_ia_general(message: discord.Message, contenido: str):
    """Responde de forma natural, como una persona más, a cualquier mensaje del canal.
    Si la IA no puede resolver la duda, ofrece abrir un ticket en vez de dejar la conversación colgada."""
    async with message.channel.typing():
        db_hotel    = cargar_db(HOTEL_DB_FILE)
        db_reservas = cargar_db(RESERVAS_DB)
        uid         = str(message.author.id)
        perfil      = db_hotel.get(uid)
        reservas    = [r for r in db_reservas.values() if str(r.get("usuario_id")) == uid]
        contexto    = hotel_ai.construir_contexto(perfil, reservas)
        contexto   += f"\n[Estás chateando de forma natural, como una persona más, en el canal #{message.channel.name}. No es un ticket de soporte formal.]"

        respuesta = await hotel_ai.consultar_ia(
            user_id          = uid,
            display_name     = message.author.display_name,
            mensaje          = contenido,
            contexto_hotel   = contexto,
            permitir_escalar = True,
            scope            = f"general:{message.channel.id}",
        )

    escalar          = "[ESCALAR]" in respuesta
    respuesta_limpia = respuesta.replace("[ESCALAR]", "").strip()

    if not respuesta_limpia and not escalar:
        respuesta_limpia = "Disculpa, no he podido generar una respuesta. ¿Puedes reformular tu mensaje?"

    for i in range(0, len(respuesta_limpia), 2000):
        await message.channel.send(respuesta_limpia[i:i + 2000])

    if escalar:
        e = discord.Embed(
            title="🤔 ¿Necesitas ayuda?",
            description=f"{message.author.mention}, no he podido resolver esto por chat. ¿Quieres abrir un ticket para que el staff te ayude?",
            color=COLOR_DORADO,
        )
        await message.channel.send(embed=e, view=OfrecerTicketView(message.author.id))


async def _crear_ticket(guild: discord.Guild, user: discord.Member) -> discord.TextChannel:
    """Crea (o devuelve, si ya existe) el canal de ticket de un usuario."""
    nombre_canal = f"ticket-{user.name.lower().replace(' ','-')}"
    existente = discord.utils.get(guild.text_channels, name=nombre_canal)
    if existente:
        return existente
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(read_messages=False),
        user:               discord.PermissionOverwrite(read_messages=True, send_messages=True),
        guild.me:           discord.PermissionOverwrite(read_messages=True, send_messages=True),
    }
    for role in guild.roles:
        if role.permissions.manage_messages:
            overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
    canal = await guild.create_text_channel(nombre_canal, overwrites=overwrites)
    e = discord.Embed(title="🎫 Ticket abierto", description=f"Hola {user.mention}, el staff te atenderá en breve.", color=COLOR_DORADO)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await canal.send(embed=e, view=CerrarTicketView())
    asyncio.create_task(b44.notify_agent(
        f"🎫 Se abrió un ticket de soporte en Discord.\nUsuario: {user.display_name} ({user})\nCanal: #{canal.name}"
    ))
    return canal


async def _buscar_reservas_web(member: discord.Member) -> list:
    """Busca reservas del usuario en Base44 (portal web VonStay).
    Prioridad: discord_id (único y seguro) → discord_user (fallback exacto).
    Nunca usa nombre de rol/perfil para evitar colisiones entre usuarios."""
    try:
        todas = await b44.get_reservations(limit=100)
        uid   = str(member.id)

        # 1) Coincidencia por discord_id — identificador único, máxima confianza
        por_id = [r for r in todas if str(r.get("discord_id", "")) == uid]
        if por_id:
            return por_id

        # 2) Fallback: discord_user exacto (solo el username de Discord, sin display_name)
        nombre = member.name.lower()
        return [
            r for r in todas
            if str(r.get("discord_user", "")).lower() == nombre
        ]
    except Exception as ex:
        print(f"[Reservas Web] Error buscando reservas de {member}: {ex}")
        return []


async def _crear_ticket_reserva(guild: discord.Guild, user: discord.Member) -> discord.TextChannel:
    """Crea (o devuelve si ya existe) el canal de ticket de reservas del usuario.
    Carga historial de reservas (bot + Base44) y activa el Agente de Reservas IA al instante."""
    nombre_canal = f"reserva-{user.name.lower().replace(' ', '-')[:30]}"
    existente = discord.utils.get(guild.text_channels, name=nombre_canal)
    if existente:
        # Re-activar en DB por si el bot reinició mientras el canal seguía en Discord
        _activar_ticket_reserva(existente.id)
        return existente

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(read_messages=False),
        user:               discord.PermissionOverwrite(read_messages=True, send_messages=True),
        guild.me:           discord.PermissionOverwrite(read_messages=True, send_messages=True),
    }
    for role in guild.roles:
        if role.permissions.manage_messages:
            overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

    canal = await guild.create_text_channel(
        nombre_canal,
        overwrites=overwrites,
        topic="🏨 Ticket de Reservas — Atendido por Agente Reservas IA • VonStay",
    )

    # Activar el Agente de Reservas IA inmediatamente
    _activar_ticket_reserva(canal.id)

    # Recopilar reservas en paralelo (bot DB + Base44 web)
    db_hotel    = cargar_db(HOTEL_DB_FILE)
    db_reservas = cargar_db(RESERVAS_DB)
    uid         = str(user.id)
    perfil      = db_hotel.get(uid)

    reservas_bot = sorted(
        [r for r in db_reservas.values() if str(r.get("usuario_id")) == uid],
        key=lambda r: r.get("fecha", ""),
        reverse=True,
    )
    reservas_web = await _buscar_reservas_web(user)

    # ── Embed de bienvenida con historial completo ──────────────────────────
    e = discord.Embed(
        title="🏨 Agente de Reservas IA — Von Crastenburg Hotel",
        description=(
            f"Hola {user.mention}, soy el **Agente de Reservas IA**.\n"
            "Escribe tu consulta directamente y te responderé al instante con acceso completo a tu historial."
        ),
        color=COLOR_DORADO,
    )

    # Reservas del bot
    _estado_emoji = {"confirmada": "✅", "pendiente": "⏳", "activa": "🔑",
                     "cancelada": "❌", "finalizada": "🏁"}
    _tipo_emoji   = {"doble": "🛏️", "lujo": "💎", "suite": "👑",
                     "standard": "🛏️", "deluxe": "💎", "vip_suite": "👑"}

    if reservas_bot:
        val_bot = ""
        for r in reservas_bot[:5]:
            ee = _estado_emoji.get(r.get("estado", ""), "•")
            te = _tipo_emoji.get(str(r.get("tipo", "")).lower(), "🛏️")
            val_bot += (
                f"{ee} `{r.get('codigo', '?')}` — {te} **{str(r.get('tipo', '?')).capitalize()}**\n"
                f"　📅 {r.get('fecha', '?')} → {r.get('fecha_salida', '?')} | *{r.get('estado', '?')}*\n"
            )
        e.add_field(name="📋 Tus reservas (bot Discord)", value=val_bot.strip(), inline=False)
    else:
        e.add_field(name="📋 Tus reservas (bot Discord)", value="*No hay reservas registradas en el bot.*", inline=False)

    # Reservas web (Base44)
    if reservas_web:
        val_web = ""
        for r in reservas_web[:5]:
            estado   = r.get("status", r.get("estado", "?"))
            tipo_hab = r.get("room_type", r.get("tipo", "?"))
            entrada  = r.get("check_in_date", r.get("fecha_entrada", r.get("fecha", "?")))
            salida   = r.get("check_out_date", r.get("fecha_salida", "?"))
            rid      = str(r.get("id", r.get("codigo", "?")))
            rid_s    = rid[:10] + "…" if len(rid) > 10 else rid
            ee       = _estado_emoji.get(estado, "•")
            te       = _tipo_emoji.get(str(tipo_hab).lower(), "🛏️")
            val_web += f"{ee} `{rid_s}` — {te} **{tipo_hab}** | {entrada} → {salida} | *{estado}*\n"
        e.add_field(name="🌐 Reservas web (VonStay)", value=val_web.strip(), inline=False)
    else:
        e.add_field(name="🌐 Reservas web (VonStay)", value="*No se encontraron reservas en el portal web.*", inline=False)

    # Instrucciones de comandos
    e.add_field(
        name="💡 Comandos útiles",
        value=(
            "`/checkin [código]` — Hacer check-in\n"
            "`/checkout [código]` — Hacer check-out\n"
            "`/cancelar [código]` — Cancelar reserva\n"
            "`/verreservas` — Ver todas tus reservas\n"
            "`/disponibilidad` — Ver habitaciones disponibles\n"
            "🌐 **[Portal VonStay](https://von-stay-luxe-revo-rp.base44.app)**"
        ),
        inline=False,
    )
    e.set_footer(text="⚡ Agente de Reservas IA activo — Escribe tu consulta aquí debajo")

    await canal.send(embed=e, view=ReservaTicketControlView())
    asyncio.create_task(b44.notify_agent(
        f"🏨 Se abrió un ticket de reservas en Discord.\nUsuario: {user.display_name} ({user})\nCanal: #{canal.name}"
    ))
    return canal


class OfrecerTicketView(discord.ui.View):
    """Botones que la IA muestra en el canal de dudas para ofrecer abrir un ticket."""
    def __init__(self, usuario_id: int):
        super().__init__(timeout=300)
        self.usuario_id = usuario_id

    @discord.ui.button(label="✅ Sí, abrir ticket", style=discord.ButtonStyle.green, custom_id="duda_abrir_ticket")
    async def si_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.usuario_id:
            await interaction.response.send_message("Solo la persona que escribió el mensaje puede usar este botón.", ephemeral=True); return
        canal = await _crear_ticket(interaction.guild, interaction.user)
        await interaction.response.edit_message(content=f"🎫 Ticket creado: {canal.mention}", embed=None, view=None)

    @discord.ui.button(label="❌ No, gracias", style=discord.ButtonStyle.grey, custom_id="duda_no_ticket")
    async def no_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.usuario_id:
            await interaction.response.send_message("Solo la persona que escribió el mensaje puede usar este botón.", ephemeral=True); return
        await interaction.response.edit_message(content="De acuerdo, si necesitas algo más aquí estamos. 🙂", embed=None, view=None)


class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🎟️ Abrir Ticket", style=discord.ButtonStyle.green, custom_id="abrir_ticket")
    async def abrir_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        user  = interaction.user
        nombre_canal = f"ticket-{user.name.lower().replace(' ','-')}"
        existente = discord.utils.get(guild.text_channels, name=nombre_canal)
        if existente:
            await interaction.response.send_message(f"Ya tienes un ticket: {existente.mention}", ephemeral=True); return
        canal = await _crear_ticket(guild, user)
        await interaction.response.send_message(f"Ticket creado: {canal.mention}", ephemeral=True)

class ModalConsultaIA(discord.ui.Modal, title="🤖 Consultar al Asistente IA"):
    consulta = discord.ui.TextInput(
        label="¿En qué podemos ayudarte?",
        style=discord.TextStyle.paragraph,
        placeholder="Describe tu problema o pregunta con el mayor detalle posible...",
        min_length=5,
        max_length=1000,
        required=True,
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(thinking=True)

        # Construir contexto del usuario
        db_hotel    = cargar_db(HOTEL_DB_FILE)
        db_reservas = cargar_db(RESERVAS_DB)
        uid         = str(interaction.user.id)
        perfil      = db_hotel.get(uid)
        reservas    = [r for r in db_reservas.values() if str(r.get("usuario_id")) == uid]
        contexto    = hotel_ai.construir_contexto(perfil, reservas)
        contexto   += f"\n[El usuario está en un ticket de soporte del canal: {interaction.channel.name}]"

        respuesta = await hotel_ai.consultar_ia(
            user_id        = uid,
            display_name   = interaction.user.display_name,
            mensaje        = self.consulta.value,
            contexto_hotel = contexto,
            scope          = f"ticket:{interaction.channel.id}",
        )

        trozos = [respuesta[i:i+4000] for i in range(0, len(respuesta), 4000)]
        for idx, trozo in enumerate(trozos):
            e = discord.Embed(
                title       = "🤖 VON CRASTENHBURG HOTEL AI" if idx == 0 else "",
                description = trozo,
                color       = COLOR_DORADO,
            )
            if idx == 0:
                e.set_author(name=interaction.user.display_name, icon_url=interaction.user.display_avatar.url)
                e.set_footer(text="Respuesta automática del asistente IA • VonStay")
            if idx == 0:
                await interaction.followup.send(embed=e)
            else:
                await interaction.channel.send(embed=e)


class CerrarTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🤖 Consultar IA", style=discord.ButtonStyle.blurple, custom_id="consultar_ia_ticket")
    async def consultar_ia_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ModalConsultaIA())

    @discord.ui.button(label="🧠 Pasar IA", style=discord.ButtonStyle.green, custom_id="pasar_ia_ticket")
    async def pasar_ia_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.channel.id) in _tickets_ia_activos():
            await interaction.response.send_message("La IA ya está gestionando este ticket automáticamente.", ephemeral=True); return
        _activar_ia_ticket(interaction.channel.id)
        e = discord.Embed(
            title="🧠 IA activada en este ticket",
            description=(
                "A partir de ahora responderé automáticamente a cada mensaje que escribas aquí.\n"
                "Si no logro resolver tu caso, avisaré a un superior para que tome el relevo."
            ),
            color=COLOR_DORADO,
        )
        await interaction.response.send_message(embed=e)

    @discord.ui.button(label="🔒 Cerrar Ticket", style=discord.ButtonStyle.red, custom_id="cerrar_ticket")
    async def cerrar_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        _desactivar_ia_ticket(interaction.channel.id)
        await interaction.response.send_message("Cerrando ticket en 3 segundos...")
        await asyncio.sleep(3)
        await interaction.channel.delete()


# ══════════════════════════════════════════════════════════
# PANEL 2 — TICKET DE RESERVAS (Agente Reservas IA)
# ══════════════════════════════════════════════════════════

class TicketReservaView(discord.ui.View):
    """Panel 2 — botón del embed de gestión de reservas con IA especializada."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="🏨 Gestionar mi Reserva",
        style=discord.ButtonStyle.blurple,
        custom_id="abrir_ticket_reserva",
    )
    async def abrir_ticket_reserva(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        user  = interaction.user
        nombre_canal = f"reserva-{user.name.lower().replace(' ', '-')[:30]}"
        existente = discord.utils.get(guild.text_channels, name=nombre_canal)
        if existente:
            await interaction.response.send_message(
                f"Ya tienes un ticket de reservas activo: {existente.mention}", ephemeral=True
            )
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        canal = await _crear_ticket_reserva(guild, user)
        await interaction.followup.send(f"🏨 Ticket de reservas creado: {canal.mention}", ephemeral=True)


class ReservaTicketControlView(discord.ui.View):
    """Controles del ticket de reservas — IA siempre activa; solo solicitar staff o cerrar."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="👤 Solicitar Staff",
        style=discord.ButtonStyle.secondary,
        custom_id="reserva_solicitar_staff",
    )
    async def solicitar_staff(self, interaction: discord.Interaction, button: discord.ui.Button):
        _desactivar_ticket_reserva(interaction.channel.id)
        rol     = interaction.guild.get_role(ID_ROL_SUPERIOR)
        mencion = rol.mention if rol else f"<@&{ID_ROL_SUPERIOR}>"
        try:
            await interaction.channel.edit(topic="⏳ Esperando Staff — Ticket de Reservas escalado manualmente")
        except Exception:
            pass
        e = discord.Embed(
            title="👤 Staff solicitado",
            description=(
                f"{interaction.user.mention} ha solicitado atención humana para este ticket de reservas.\n"
                f"{mencion}, por favor revisad este caso."
            ),
            color=COLOR_DORADO,
        )
        e.set_footer(text="⏳ Estado: Esperando Staff • VonStay")
        await interaction.response.send_message(embed=e)

    @discord.ui.button(
        label="🔒 Cerrar Ticket",
        style=discord.ButtonStyle.red,
        custom_id="reserva_cerrar_ticket",
    )
    async def cerrar_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        _desactivar_ticket_reserva(interaction.channel.id)
        await interaction.response.send_message("🔒 Cerrando ticket de reservas en 3 segundos...")
        await asyncio.sleep(3)
        await interaction.channel.delete()


@bot.tree.command(name="confirmarreserva", description="[Staff] Enviar DM de confirmación de reserva a un usuario")
@app_commands.describe(
    usuario="Usuario de Discord que hizo la reserva",
    tipo="Tipo de habitación",
    fecha_entrada="Fecha de entrada",
    fecha_salida="Fecha de salida",
    codigo="Código de reserva (opcional)"
)
@app_commands.choices(tipo=[
    app_commands.Choice(name="👑 Suite Royal",      value="suite"),
    app_commands.Choice(name="🛏️ Habitación Doble", value="doble"),
    app_commands.Choice(name="💎 Suite de Lujo",    value="lujo"),
])
async def confirmarreserva(interaction: discord.Interaction, usuario: discord.User, tipo: str, fecha_entrada: str, fecha_salida: str, codigo: str | None = None):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Solo el staff puede usar este comando.", COLOR_NEGRO), ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)

    from keep_alive import enviar_dm_manual
    codigo_final = codigo or generar_codigo_reserva()

    await enviar_dm_manual(bot, usuario.id, {
        "nombre":        usuario.display_name,
        "tipo":          tipo,
        "fecha_entrada": fecha_entrada,
        "fecha_salida":  fecha_salida,
        "codigo":        codigo_final,
    })

    db = cargar_db(RESERVAS_DB)
    db[codigo_final] = {
        "codigo":         codigo_final,
        "usuario_id":     str(usuario.id),
        "usuario_nombre": usuario.display_name,
        "tipo":           tipo,
        "fecha":          fecha_entrada,
        "fecha_salida":   fecha_salida,
        "estado":         "confirmada",
        "creada":         datetime.now().strftime("%d/%m/%Y %H:%M"),
    }
    guardar_db(RESERVAS_DB, db)

    await interaction.followup.send(
        embed=embed_von("✅ DM enviado", f"Confirmación enviada a {usuario.mention} — código `{codigo_final}`.", COLOR_DORADO),
        ephemeral=True
    )

    if interaction.guild:
        await log_staff(interaction.guild, embed_von("📋 Reserva confirmada por staff", f"**{usuario.display_name}** — `{codigo_final}` — {fecha_entrada} → {fecha_salida} | Staff: {interaction.user.display_name}", COLOR_NEGRO))

PANEL_HAB_CANAL  = 1506357655772463275
PANEL_HAB_FILE   = "panel_hab_msg.json"

TIPO_LABEL = {
    "standard":     "Estándar",
    "deluxe":       "Deluxe",
    "vip_suite":    "Suite VIP",
    "presidential": "Presidencial",
}

def _cargar_panel_msg() -> int | None:
    if os.path.exists(PANEL_HAB_FILE):
        with open(PANEL_HAB_FILE) as f:
            return json.load(f).get("msg_id")
    return None

def _guardar_panel_msg(msg_id: int):
    with open(PANEL_HAB_FILE, "w") as f:
        json.dump({"msg_id": msg_id}, f)

async def _build_panel_embed() -> discord.Embed:
    results = await asyncio.gather(
        b44.get_all_rooms(limit=60),
        b44.get_reservations(status="pending", limit=30),
        return_exceptions=True,
    )
    rooms      = results[0] if isinstance(results[0], list) else []
    pendientes = results[1] if isinstance(results[1], list) else []

    libres  = [r for r in rooms if r.get("status") == "available"]
    limpias = [r for r in rooms if r.get("status") == "cleaning"]
    ocupadas= [r for r in rooms if r.get("status") == "occupied"]
    reserv  = [r for r in rooms if r.get("status") == "reserved"]
    otras   = [r for r in rooms if r.get("status") not in ("available","cleaning","occupied","reserved")]

    def fmt_room(r):
        num   = int(r.get("room_number") or 0)
        tipo  = TIPO_LABEL.get(r.get("type",""), r.get("type","?"))
        guest = r.get("assigned_guest","")
        base  = f"**#{num}** {tipo}"
        return f"{base} — {guest}" if guest else base

    def fmt_pendiente(r):
        nombre  = r.get("rp_name") or r.get("guest_name") or r.get("discord_user") or "—"
        tipo    = TIPO_LABEL.get(r.get("room_type",""), r.get("room_type","?"))
        entrada = r.get("check_in") or "—"
        salida  = r.get("check_out") or "—"
        return f"  **{nombre}** · {tipo} · {entrada} → {salida}"

    def secciones(lista, emoji, titulo):
        if not lista:
            return f"{emoji} **{titulo}** — ninguna\n"
        items = "\n".join(f"  {fmt_room(r)}" for r in sorted(lista, key=lambda r: r.get("room_number",0)))
        return f"{emoji} **{titulo}** ({len(lista)})\n{items}\n"

    def _safe_append(desc: str, block: str, limit: int = 3900) -> str:
        """Añade `block` a `desc` solo si no supera `limit` caracteres."""
        if len(desc) + len(block) <= limit:
            return desc + block
        return desc

    desc = ""

    # ── Solicitudes web pendientes ──────────────────────────
    if pendientes:
        MAX_MOSTRAR = 12
        mostrar   = pendientes[:MAX_MOSTRAR]
        resto     = len(pendientes) - len(mostrar)
        items_p   = "\n".join(fmt_pendiente(r) for r in mostrar)
        extra_txt = f"\n  _…y {resto} solicitud(es) más_" if resto > 0 else ""
        bloque_p  = f"🟠 **SOLICITUDES WEB PENDIENTES** ({len(pendientes)})\n{items_p}{extra_txt}\n\n"
        desc = _safe_append(desc, bloque_p)

    desc = _safe_append(desc, secciones(libres,   "🟢", "LIBRES") + "\n")
    desc = _safe_append(desc, secciones(reserv,   "🟡", "RESERVADAS") + "\n")
    desc = _safe_append(desc, secciones(limpias,  "🔵", "EN LIMPIEZA") + "\n")
    desc = _safe_append(desc, secciones(ocupadas, "🔴", "OCUPADAS"))
    if otras:
        desc = _safe_append(desc, "\n" + secciones(otras, "⚫", "MANTENIMIENTO / OTRO"))

    total = len(rooms)
    e = discord.Embed(
        title="🏨 Estado de Habitaciones — Von Crastenburg",
        description=desc.strip(),
        color=COLOR_DORADO,
    )
    e.set_footer(text=f"🔄 Actualizado: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  ·  Total: {total} habitaciones  ·  VonStay")
    return e

async def tarea_panel_habitaciones():
    await bot.wait_until_ready()
    await asyncio.sleep(20)
    print("[Panel HAB] Tarea de actualización iniciada")
    while not bot.is_closed():
        try:
            canal = bot.get_channel(PANEL_HAB_CANAL)
            if canal:
                embed   = await _build_panel_embed()
                msg_id  = _cargar_panel_msg()
                if msg_id:
                    try:
                        msg = await canal.fetch_message(msg_id)
                        await msg.edit(embed=embed)
                    except (discord.NotFound, discord.Forbidden):
                        msg = await canal.send(embed=embed)
                        _guardar_panel_msg(msg.id)
                # Si no hay msg_id guardado, esperamos a que /panelhabitaciones lo cree
        except Exception as ex:
            print(f"[Panel HAB] Error: {ex}")
        await asyncio.sleep(60)

@bot.tree.command(name="panelhabitaciones", description="[Staff] Publicar panel de estado de habitaciones en tiempo real")
async def panelhabitaciones(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(
            embed=embed_von("❌ Sin permiso", "Solo el staff puede usar este comando.", COLOR_NEGRO),
            ephemeral=True
        )
        return

    await interaction.response.defer(ephemeral=True)

    canal = bot.get_channel(PANEL_HAB_CANAL)
    if not canal:
        await interaction.followup.send(embed=embed_von("❌ Canal no encontrado", f"No se encontró el canal `{PANEL_HAB_CANAL}`.", COLOR_NEGRO), ephemeral=True)
        return

    embed  = await _build_panel_embed()

    # Borrar mensaje anterior si existe
    msg_id = _cargar_panel_msg()
    if msg_id:
        try:
            old = await canal.fetch_message(msg_id)
            await old.delete()
        except Exception:
            pass

    msg = await canal.send(embed=embed)
    _guardar_panel_msg(msg.id)

    await interaction.followup.send(
        embed=embed_von("✅ Panel publicado", f"Panel de habitaciones publicado en {canal.mention}.\nSe actualizará automáticamente cada 60 segundos.", COLOR_DORADO),
        ephemeral=True
    )

@bot.tree.command(name="paneltickets", description="[Staff] Publicar un panel de tickets en el canal indicado")
@app_commands.describe(
    canal="Canal donde publicar el panel (vacío = canal actual)",
    tipo="Tipo de panel: soporte general o gestión de reservas con IA dedicada",
)
@app_commands.choices(tipo=[
    app_commands.Choice(name="🎫 Panel 1 — Soporte General",              value="basico"),
    app_commands.Choice(name="🏨 Panel 2 — Reservas (IA Especializada)",  value="reservas"),
])
async def paneltickets(
    interaction: discord.Interaction,
    canal: discord.TextChannel | None = None,
    tipo: str = "basico",
):
    if not interaction.user.guild_permissions.manage_channels:
        await interaction.response.send_message("Sin permisos.", ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    destino = canal or interaction.channel

    if tipo == "reservas":
        # ── Panel 2 — Agente de Reservas IA ───────────────────────────────
        e = discord.Embed(
            title="🏨 Gestión de Reservas — Von Crastenburg Hotel",
            description=(
                "¿Tienes una consulta o problema con tu reserva?\n\n"
                "Pulsa el botón para abrir un **ticket privado**. El **Agente de Reservas IA** "
                "te atenderá al instante con acceso completo a tu historial de reservas del hotel."
            ),
            color=COLOR_DORADO,
        )
        e.add_field(
            name="🔑 ¿Qué puedes gestionar?",
            value=(
                "- Consultar el estado de tu reserva\n"
                "- Proceso de check-in y check-out\n"
                "- Modificaciones y cambio de habitación\n"
                "- Cancelaciones\n"
                "- Dudas sobre el sistema VonStay"
            ),
            inline=False,
        )
        e.add_field(
            name="⚡ Atención inmediata",
            value=(
                "Este ticket es atendido **exclusivamente por IA** las 24 h.\n"
                "Si tu caso requiere staff humano, la IA lo escalará automáticamente."
            ),
            inline=False,
        )
        e.set_footer(text="🏨 VonStay • Von Crastenburg Hotel RP — Agente de Reservas IA")
        await destino.send(embed=e, view=TicketReservaView())
        await interaction.followup.send(f"✅ Panel de reservas publicado en {destino.mention}.", ephemeral=True)

    else:
        # ── Panel 1 — Soporte General (el de siempre) ─────────────────────
        e = discord.Embed(
            title="🎫 Soporte — Von Crastenburg Hotel",
            description=(
                "¿Tienes algún problema, duda o solicitud especial?\n\n"
                "Pulsa el botón para abrir un **ticket privado** y el staff te atenderá en breve."
            ),
            color=COLOR_DORADO,
        )
        e.add_field(
            name="📋 Podemos ayudarte con:",
            value=(
                "- Problemas con tu cuenta o perfil\n"
                "- Solicitudes especiales\n"
                "- Incidencias y reclamaciones\n"
                "- Dudas generales del servidor\n"
                "- Cualquier otro asunto"
            ),
            inline=False,
        )
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await destino.send(embed=e, view=TicketView())
        await interaction.followup.send(f"✅ Panel de soporte publicado en {destino.mention}.", ephemeral=True)

# ==========================================
# SOLICITUD DE EMPLEO
# ==========================================

PUESTOS_EMPLEO = [
    "Recepcionista", "Botones", "Chef", "Camarero/a",
    "Limpieza", "Seguridad", "Mantenimiento", "Relaciones Públicas",
    "Gerente de Planta", "Concierge",
]

class ViewRespuestaSolicitud(discord.ui.View):
    """Vista que se envía al manager para aceptar o rechazar."""
    def __init__(self, solicitante_id: int, solicitante_nombre: str, puesto: str, mensaje: str):
        super().__init__(timeout=None)
        self.solicitante_id     = solicitante_id
        self.solicitante_nombre = solicitante_nombre
        self.puesto             = puesto
        self.mensaje            = mensaje
        self._respondido        = False

    async def _responder(self, interaction: discord.Interaction, aceptado: bool):
        if self._respondido:
            await interaction.response.send_message("Ya respondiste a esta solicitud.", ephemeral=True)
            return
        self._respondido = True

        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(view=self)

        solicitante = await interaction.client.fetch_user(self.solicitante_id)

        if aceptado:
            e_resultado = discord.Embed(
                title="✅ Solicitud de Empleo Aceptada",
                description=(
                    f"¡Enhorabuena, **{self.solicitante_nombre}**!\n\n"
                    f"Tu solicitud para el puesto de **{self.puesto}** en el **Von Crastenburg Hotel** ha sido **aceptada**.\n\n"
                    "Un miembro del equipo se pondrá en contacto contigo en breve para los próximos pasos.\n"
                    "*Bienvenido/a a la familia Von Crastenburg.* 🏨✨"
                ),
                color=COLOR_DORADO,
            )
        else:
            e_resultado = discord.Embed(
                title="❌ Solicitud de Empleo No Aceptada",
                description=(
                    f"Hola, **{self.solicitante_nombre}**.\n\n"
                    f"Lamentablemente tu solicitud para el puesto de **{self.puesto}** no ha sido seleccionada en esta ocasión.\n\n"
                    "Agradecemos tu interés en el Von Crastenburg Hotel. Puedes volver a intentarlo en el futuro.\n"
                    "*Gracias por tu tiempo.* 🙏"
                ),
                color=COLOR_ROJO,
            )
        e_resultado.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        _con_logo(e_resultado)

        try:
            await solicitante.send(embed=e_resultado, file=_logo_file())
        except discord.Forbidden:
            pass

        estado_txt = "✅ ACEPTADA" if aceptado else "❌ RECHAZADA"
        await interaction.followup.send(
            embed=embed_von(
                f"Solicitud {estado_txt}",
                f"**{self.solicitante_nombre}** ha sido notificado/a por DM.",
                COLOR_DORADO if aceptado else COLOR_ROJO,
            ),
            ephemeral=True,
        )

    @discord.ui.button(label="✅ Aceptar", style=discord.ButtonStyle.success)
    async def btn_aceptar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._responder(interaction, aceptado=True)

    @discord.ui.button(label="❌ Rechazar", style=discord.ButtonStyle.danger)
    async def btn_rechazar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._responder(interaction, aceptado=False)


@bot.tree.command(name="solicitar_empleo", description="💼 Envía tu solicitud de empleo al Von Crastenburg Hotel")
@app_commands.describe(
    puesto="Puesto al que deseas optar",
    presentacion="Preséntate brevemente (experiencia, motivación...)",
)
@app_commands.choices(puesto=[app_commands.Choice(name=p, value=p) for p in PUESTOS_EMPLEO])
async def solicitar_empleo(interaction: discord.Interaction, puesto: str, presentacion: str):
    await interaction.response.defer(ephemeral=True)

    # DM de confirmación al solicitante
    e_confirmacion = discord.Embed(
        title="📨 Solicitud enviada — Von Crastenburg Hotel",
        description=(
            f"Hola **{interaction.user.display_name}**,\n\n"
            f"Hemos recibido tu solicitud para el puesto de **{puesto}**.\n"
            "El equipo de RRHH la revisará y te notificaremos por aquí en breve.\n\n"
            "*Gracias por tu interés en unirte al Von Crastenburg.* 🏨"
        ),
        color=COLOR_DORADO,
    )
    e_confirmacion.add_field(name="📋 Puesto solicitado", value=puesto, inline=True)
    e_confirmacion.add_field(name="📅 Fecha",             value=datetime.now().strftime("%d/%m/%Y %H:%M"), inline=True)
    e_confirmacion.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    _con_logo(e_confirmacion)

    try:
        await interaction.user.send(embed=e_confirmacion, file=_logo_file())
    except discord.Forbidden:
        pass  # Si tiene DMs cerrados, continuamos

    # DM al manager con los botones de aceptar/rechazar
    manager = await interaction.client.fetch_user(ID_MANAGER)
    e_manager = discord.Embed(
        title="💼 Nueva Solicitud de Empleo",
        description=(
            f"**{interaction.user.display_name}** (`{interaction.user}`) solicita el puesto de **{puesto}**."
        ),
        color=COLOR_DORADO,
    )
    e_manager.add_field(name="👤 Nombre RP / Discord", value=f"{interaction.user.display_name} — {interaction.user.mention}", inline=False)
    e_manager.add_field(name="💼 Puesto",              value=puesto,                                                            inline=True)
    e_manager.add_field(name="📅 Fecha",               value=datetime.now().strftime("%d/%m/%Y %H:%M"),                         inline=True)
    e_manager.add_field(name="📝 Presentación",        value=presentacion[:1000] or "—",                                        inline=False)
    if interaction.guild:
        e_manager.add_field(name="🌐 Servidor",        value=interaction.guild.name, inline=True)
    e_manager.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP — Responde con los botones de abajo")
    _con_logo(e_manager)

    view_manager = ViewRespuestaSolicitud(
        solicitante_id     = interaction.user.id,
        solicitante_nombre = interaction.user.display_name,
        puesto             = puesto,
        mensaje            = presentacion,
    )

    try:
        await manager.send(embed=e_manager, view=view_manager, file=_logo_file())
        manager_txt = "✅ Solicitud enviada correctamente."
    except Exception:
        manager_txt = "⚠️ No se pudo enviar al responsable. Inténtalo de nuevo."

    await interaction.followup.send(
        embed=embed_von("📨 Solicitud enviada", manager_txt + "\nRecibirás una respuesta por DM.", COLOR_DORADO),
        ephemeral=True,
    )

# ==========================================
# SISTEMA DE FICHAS DE TRABAJO (FICHAR)
# ==========================================

def _ficha_hoy(db: dict, uid: str) -> dict | None:
    """Devuelve la ficha abierta del día de hoy para un usuario, o None."""
    hoy = datetime.now().strftime("%d/%m/%Y")
    for k, v in db.items():
        if v.get("uid") == uid and v.get("fecha") == hoy and v.get("salida") is None:
            return v
    return None

def _registrar_fichar_entrada(user: discord.abc.User) -> discord.Embed | None:
    """Registra la entrada de turno de un usuario. Devuelve None si ya tenía una entrada abierta."""
    db  = cargar_db(FICHAS_DB)
    uid = str(user.id)
    ahora = datetime.now()

    if _ficha_hoy(db, uid) is not None:
        return None

    clave = f"{uid}_{ahora.strftime('%Y%m%d_%H%M%S')}"
    db[clave] = {
        "uid":     uid,
        "nombre":  user.display_name,
        "fecha":   ahora.strftime("%d/%m/%Y"),
        "entrada": ahora.strftime("%H:%M:%S"),
        "salida":  None,
        "horas":   None,
    }
    guardar_db(FICHAS_DB, db)
    e = discord.Embed(
        title="✅ Entrada registrada",
        description=f"{user.mention} ha **fichado la entrada**.",
        color=COLOR_DORADO,
    )
    e.add_field(name="📅 Fecha", value=ahora.strftime("%d/%m/%Y"), inline=True)
    e.add_field(name="🕐 Hora",  value=ahora.strftime("%H:%M:%S"), inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    return e


def _registrar_fichar_salida(user: discord.abc.User) -> discord.Embed | None:
    """Registra la salida de turno de un usuario. Devuelve None si no tenía ninguna entrada abierta."""
    db  = cargar_db(FICHAS_DB)
    uid = str(user.id)
    ahora = datetime.now()

    ficha_abierta = _ficha_hoy(db, uid)
    if ficha_abierta is None:
        return None

    entrada_dt  = datetime.strptime(f"{ficha_abierta['fecha']} {ficha_abierta['entrada']}", "%d/%m/%Y %H:%M:%S")
    delta       = ahora - entrada_dt
    horas_total = delta.total_seconds() / 3600
    hh = int(delta.total_seconds() // 3600)
    mm = int((delta.total_seconds() % 3600) // 60)

    ficha_abierta["salida"] = ahora.strftime("%H:%M:%S")
    ficha_abierta["horas"]  = round(horas_total, 2)
    guardar_db(FICHAS_DB, db)

    e = discord.Embed(
        title="🔴 Fichaje detenido",
        description=f"{user.mention} ha **dejado de fichar**.",
        color=COLOR_ROJO,
    )
    e.add_field(name="📅 Fecha",   value=ficha_abierta["fecha"],    inline=True)
    e.add_field(name="🕐 Entrada", value=ficha_abierta["entrada"],  inline=True)
    e.add_field(name="🚪 Salida",  value=ahora.strftime("%H:%M:%S"), inline=True)
    e.add_field(name="⏱️ Tiempo", value=f"**{hh}h {mm}min**",      inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    return e


async def _log_fichaje(guild: discord.Guild | None, embed: discord.Embed):
    if not guild:
        return
    log_canal = discord.utils.get(guild.text_channels, name="logs-fichas") or \
                discord.utils.get(guild.text_channels, name="logs-reservas")
    if log_canal:
        await log_canal.send(embed=embed)


class PanelFicharView(discord.ui.View):
    """Panel fijo con dos botones para fichar entrada/salida, sin necesidad de comandos."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="FICHAR", style=discord.ButtonStyle.green, custom_id="panel_fichar_entrada")
    async def fichar_entrada(self, interaction: discord.Interaction, button: discord.ui.Button):
        e = _registrar_fichar_entrada(interaction.user)
        if e is None:
            await interaction.response.send_message("⚠️ Ya tienes una entrada fichada hoy. Pulsa **DEJAR DE FICHAR** para cerrarla.", ephemeral=True)
            return
        await interaction.response.send_message("✅ Entrada fichada correctamente.", ephemeral=True)
        await interaction.channel.send(embed=e, delete_after=30)
        await _log_fichaje(interaction.guild, e)
        await _gestionar_rol_turno(interaction.guild, interaction.user, en_servicio=True)

    @discord.ui.button(label="DEJAR DE FICHAR", style=discord.ButtonStyle.red, custom_id="panel_fichar_salida")
    async def fichar_salida(self, interaction: discord.Interaction, button: discord.ui.Button):
        e = _registrar_fichar_salida(interaction.user)
        if e is None:
            await interaction.response.send_message("⚠️ No tienes ninguna entrada fichada hoy que cerrar.", ephemeral=True)
            return
        await interaction.response.send_message("🔴 Fichaje detenido correctamente.", ephemeral=True)
        await interaction.channel.send(embed=e, delete_after=30)
        await _log_fichaje(interaction.guild, e)
        await _gestionar_rol_turno(interaction.guild, interaction.user, en_servicio=False)


@bot.tree.command(name="panelficar", description="[Staff] Publicar el panel de fichar/dejar de fichar en el canal actual")
async def panelficar(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.manage_channels:
        await interaction.response.send_message("Sin permisos.", ephemeral=True); return
    e = discord.Embed(
        title="⏱️ Control de turno — Von Crastenburg Hotel",
        description="Pulsa **FICHAR** al empezar tu turno y **DEJAR DE FICHAR** al terminarlo.",
        color=COLOR_DORADO,
    )
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.channel.send(embed=e, view=PanelFicharView())
    await interaction.response.send_message("Panel de fichar enviado.", ephemeral=True)


@bot.tree.command(name="mis_fichas", description="⏱️ Ver tus fichas de trabajo del día o del mes")
@app_commands.describe(periodo="Periodo a consultar")
@app_commands.choices(periodo=[
    app_commands.Choice(name="Hoy",       value="hoy"),
    app_commands.Choice(name="Esta semana", value="semana"),
    app_commands.Choice(name="Este mes",  value="mes"),
])
async def mis_fichas(interaction: discord.Interaction, periodo: str = "hoy"):
    db  = cargar_db(FICHAS_DB)
    uid = str(interaction.user.id)
    ahora = datetime.now()

    if periodo == "hoy":
        fecha_str = ahora.strftime("%d/%m/%Y")
        fichas = [v for v in db.values() if v.get("uid") == uid and v.get("fecha") == fecha_str]
    elif periodo == "semana":
        inicio = ahora - timedelta(days=ahora.weekday())
        fichas = [
            v for v in db.values()
            if v.get("uid") == uid and
            datetime.strptime(v["fecha"], "%d/%m/%Y") >= inicio.replace(hour=0, minute=0, second=0)
        ]
    else:  # mes
        fichas = [
            v for v in db.values()
            if v.get("uid") == uid and
            v.get("fecha", "").endswith(f"/{ahora.strftime('%m/%Y')}")
        ]

    if not fichas:
        await interaction.response.send_message(
            embed=embed_von("⏱️ Sin fichas", f"No tienes fichas registradas para **{periodo}**.", COLOR_NEGRO),
            ephemeral=True)
        return

    total_h = sum(f.get("horas") or 0 for f in fichas)
    hh_t = int(total_h)
    mm_t = int((total_h - hh_t) * 60)

    e = discord.Embed(title=f"⏱️ Mis fichas — {periodo.capitalize()}", color=COLOR_DORADO)
    for f in sorted(fichas, key=lambda x: x["fecha"])[:10]:
        salida  = f.get("salida") or "🔴 En turno"
        horas   = f"{f['horas']:.2f}h" if f.get("horas") else "—"
        e.add_field(
            name  = f"📅 {f['fecha']}",
            value = f"🕐 Entrada: `{f['entrada']}` | 🚪 Salida: `{salida}` | ⏱️ {horas}",
            inline = False,
        )
    e.add_field(name="📊 Total horas", value=f"**{hh_t}h {mm_t}min**", inline=False)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.response.send_message(embed=e, ephemeral=True)


@bot.tree.command(name="fichas_staff", description="[Staff] Ver fichas de un empleado")
@app_commands.describe(usuario="Empleado a consultar", periodo="Periodo")
@app_commands.choices(periodo=[
    app_commands.Choice(name="Hoy",       value="hoy"),
    app_commands.Choice(name="Este mes",  value="mes"),
])
async def fichas_staff(interaction: discord.Interaction, usuario: discord.User, periodo: str = "hoy"):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message("Sin permisos.", ephemeral=True); return

    db  = cargar_db(FICHAS_DB)
    uid = str(usuario.id)
    ahora = datetime.now()

    if periodo == "hoy":
        fecha_str = ahora.strftime("%d/%m/%Y")
        fichas = [v for v in db.values() if v.get("uid") == uid and v.get("fecha") == fecha_str]
    else:
        fichas = [
            v for v in db.values()
            if v.get("uid") == uid and v.get("fecha","").endswith(f"/{ahora.strftime('%m/%Y')}")
        ]

    if not fichas:
        await interaction.response.send_message(
            embed=embed_von("⏱️ Sin fichas", f"**{usuario.display_name}** no tiene fichas para **{periodo}**.", COLOR_NEGRO),
            ephemeral=True); return

    total_h = sum(f.get("horas") or 0 for f in fichas)
    hh_t = int(total_h); mm_t = int((total_h - hh_t) * 60)
    e = discord.Embed(title=f"⏱️ Fichas de {usuario.display_name} — {periodo}", color=COLOR_DORADO)
    for f in sorted(fichas, key=lambda x: x["fecha"])[:10]:
        salida = f.get("salida") or "🔴 En turno"
        horas  = f"{f['horas']:.2f}h" if f.get("horas") else "—"
        e.add_field(name=f"📅 {f['fecha']}",
                    value=f"🕐 `{f['entrada']}` → 🚪 `{salida}` | ⏱️ {horas}", inline=False)
    e.add_field(name="📊 Total", value=f"**{hh_t}h {mm_t}min**", inline=False)
    e.set_thumbnail(url=usuario.display_avatar.url)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.response.send_message(embed=e, ephemeral=True)

# ==========================================
# MODERACIÓN
# ==========================================

def _check_mod(interaction: discord.Interaction) -> bool:
    return interaction.user.guild_permissions.manage_messages or \
           interaction.user.guild_permissions.kick_members

async def _log_mod(interaction: discord.Interaction, embed: discord.Embed):
    """Envía log al canal de moderación."""
    canal = discord.utils.get(interaction.guild.text_channels, name="logs-moderacion") or \
            discord.utils.get(interaction.guild.text_channels, name="logs-reservas")
    if canal:
        await canal.send(embed=embed)


# ==========================================
# MODERACIÓN AUTOMÁTICA POR IA (todos los canales)
# ==========================================

def _es_staff_member(member: discord.Member) -> bool:
    return (
        member.guild_permissions.administrator
        or member.guild_permissions.manage_messages
        or member.guild_permissions.kick_members
        or any(r.id == ID_ROL_MODERACION for r in member.roles)
    )


def _cargar_mod_ia() -> dict:
    return cargar_db(MOD_IA_DB)


def _guardar_mod_ia(db: dict):
    guardar_db(MOD_IA_DB, db)


def _resetear_nivel_mod_ia(usuario_id: int):
    db  = _cargar_mod_ia()
    uid = str(usuario_id)
    if uid in db:
        db[uid]["nivel"] = 0
        _guardar_mod_ia(db)


class DecisionModeracionView(discord.ui.View):
    """Botones para que un moderador decida qué hacer con un usuario reincidente."""
    def __init__(self, usuario_id: int):
        super().__init__(timeout=3600)
        self.usuario_id = usuario_id

    def _es_moderador(self, interaction: discord.Interaction) -> bool:
        member = interaction.user
        if not isinstance(member, discord.Member):
            return False
        return (
            member.guild_permissions.ban_members
            or member.guild_permissions.moderate_members
            or any(r.id == ID_ROL_MODERACION for r in member.roles)
        )

    def _puede_banear(self, interaction: discord.Interaction) -> bool:
        member = interaction.user
        if not isinstance(member, discord.Member):
            return False
        return member.guild_permissions.ban_members

    @discord.ui.button(label="🔨 Banear", style=discord.ButtonStyle.danger, custom_id="mod_ia_banear")
    async def banear_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self._puede_banear(interaction):
            await interaction.response.send_message("Necesitas permiso de banear miembros para esta acción.", ephemeral=True); return
        guild  = interaction.guild
        member = guild.get_member(self.usuario_id)
        try:
            if member:
                await member.ban(reason=f"[IA→Moderación] Decisión de {interaction.user}")
            else:
                await guild.ban(discord.Object(id=self.usuario_id), reason=f"[IA→Moderación] Decisión de {interaction.user}")
            _resetear_nivel_mod_ia(self.usuario_id)
            await interaction.response.edit_message(content=f"🔨 Usuario baneado por {interaction.user.mention}.", embed=None, view=None)
        except Exception as ex:
            await interaction.response.send_message(f"Error al banear: {ex}", ephemeral=True)

    @discord.ui.button(label="🔇 Silenciar", style=discord.ButtonStyle.secondary, custom_id="mod_ia_silenciar")
    async def silenciar_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self._es_moderador(interaction):
            await interaction.response.send_message("Solo el equipo de moderación puede decidir.", ephemeral=True); return
        guild  = interaction.guild
        member = guild.get_member(self.usuario_id)
        try:
            if member:
                hasta = discord.utils.utcnow() + timedelta(hours=1)
                await member.timeout(hasta, reason=f"[IA→Moderación] Decisión de {interaction.user}")
            _resetear_nivel_mod_ia(self.usuario_id)
            await interaction.response.edit_message(content=f"🔇 Usuario silenciado 1 hora por {interaction.user.mention}.", embed=None, view=None)
        except Exception as ex:
            await interaction.response.send_message(f"Error al silenciar: {ex}", ephemeral=True)

    @discord.ui.button(label="✅ No hacer nada", style=discord.ButtonStyle.success, custom_id="mod_ia_nada")
    async def nada_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self._es_moderador(interaction):
            await interaction.response.send_message("Solo el equipo de moderación puede decidir.", ephemeral=True); return
        _resetear_nivel_mod_ia(self.usuario_id)
        await interaction.response.edit_message(content=f"✅ Sin acción, decidido por {interaction.user.mention}.", embed=None, view=None)


async def _moderar_mensaje_ia(message: discord.Message, contenido: str) -> bool:
    """AutoMod con routing por gravedad: Nivel 1 = aviso, Nivel 2 = borrar+timeout, Nivel 3 = alerta inmediata staff.
    Devuelve True si el mensaje fue marcado como infracción."""
    if isinstance(message.author, discord.Member) and _es_staff_member(message.author):
        return False

    resultado = await hotel_ai.analizar_moderacion(contenido)
    if not resultado.get("infraccion"):
        return False

    razon        = resultado.get("razon") or "Contenido inapropiado detectado por la IA"
    nivel_accion = int(resultado.get("nivel_accion", 1))  # AI-decided severity: 1, 2 or 3

    # Registrar reincidencia (independiente del nivel_accion de la IA)
    async with _lock_mod_ia:
        db       = _cargar_mod_ia()
        uid      = str(message.author.id)
        registro = db.get(uid, {"nivel": 0})
        registro["nivel"]  = registro.get("nivel", 0) + 1
        registro["nombre"] = message.author.display_name
        reincidencias = registro["nivel"]
        db[uid] = registro
        _guardar_mod_ia(db)

    # ── NIVEL 3: Grave — acción inmediata, sin esperar historial ──────────
    if nivel_accion >= 3:
        try:
            await message.delete()
        except Exception:
            pass
        rol     = message.guild.get_role(ID_ROL_MODERACION)
        mencion = rol.mention if rol else f"<@&{ID_ROL_MODERACION}>"
        e = discord.Embed(
            title="🚨 ALERTA GRAVE — Intervención inmediata requerida",
            description=(
                f"**Usuario:** {message.author.mention} (`{message.author.id}`)\n"
                f"**Canal:** {message.channel.mention}\n"
                f"**Motivo:** {razon}\n"
                f"**Infracciones totales:** {reincidencias}\n"
                f"-# El mensaje original ha sido eliminado del canal."
            ),
            color=COLOR_ROJO,
        )
        e.set_footer(text="⚠️ AutoMod IA — Acción grave detectada • Von Crastenburg Hotel")
        await message.channel.send(content=mencion, embed=e, view=DecisionModeracionView(message.author.id))
        return True

    # ── NIVEL 2: Moderado — borrar mensaje + timeout 15 min ───────────────
    if nivel_accion == 2 or reincidencias >= 2:
        try:
            await message.delete()
        except Exception:
            pass
        try:
            if isinstance(message.author, discord.Member):
                hasta = discord.utils.utcnow() + timedelta(minutes=15)
                await message.author.timeout(hasta, reason=f"[IA AutoMod] {razon}")
        except Exception as ex:
            print(f"[Moderación IA] No se pudo silenciar a {message.author}: {ex}")
        e = discord.Embed(
            title="🔇 Mensaje eliminado — Timeout aplicado",
            description=(
                f"{message.author.mention} ha sido silenciado **15 minutos** y su mensaje eliminado.\n"
                f"**Motivo:** {razon}"
            ),
            color=COLOR_ROJO,
        )
        e.set_footer(text="AutoMod IA • Von Crastenburg Hotel")
        await message.channel.send(embed=e)
        # Si hay 3+ reincidencias, notificar al staff además del mute automático
        if reincidencias >= 3:
            rol     = message.guild.get_role(ID_ROL_MODERACION)
            mencion = rol.mention if rol else f"<@&{ID_ROL_MODERACION}>"
            e2 = discord.Embed(
                title="⚠️ Reincidencia múltiple — Acción manual recomendada",
                description=(
                    f"**Usuario:** {message.author.mention} (`{message.author.id}`)\n"
                    f"**Infracciones acumuladas:** {reincidencias}\n"
                    f"**Último motivo:** {razon}"
                ),
                color=0xFF6B00,
            )
            e2.set_footer(text="AutoMod IA • Von Crastenburg Hotel")
            await message.channel.send(content=mencion, embed=e2, view=DecisionModeracionView(message.author.id))
        return True

    # ── NIVEL 1: Leve — advertencia directa, tono firme pero no autoritario ─
    e = discord.Embed(
        title="⚠️ Aviso del sistema",
        description=(
            f"{message.author.mention}, mantén el respeto en el chat.\n"
            f"**Motivo:** {razon}\n\n"
            f"-# Infracción #{reincidencias} — Las reincidencias derivan en silencio automático."
        ),
        color=0xF39C12,
    )
    e.set_footer(text="AutoMod IA • Von Crastenburg Hotel")
    await message.reply(embed=e, mention_author=False)
    return True


async def _verificar_escalada_grupal(message: discord.Message, contenido: str):
    """Acumula mensajes por canal y lanza análisis de escalada grupal cada N mensajes.
    Usa un lock por canal para evitar análisis concurrentes duplicados.
    Si detecta conflicto inminente, interviene con un mensaje pacificador."""
    cid = message.channel.id

    # Inicializar estructuras para el canal de forma segura
    if cid not in _locks_escalada:
        _locks_escalada[cid] = asyncio.Lock()
    if cid not in _buffer_escalada:
        _buffer_escalada[cid] = []

    # Acumular mensaje fuera del lock (operación no-crítica)
    _buffer_escalada[cid].append(f"{message.author.display_name}: {contenido[:200]}")
    if len(_buffer_escalada[cid]) > _BUFFER_ESCALADA_MAX:
        _buffer_escalada[cid].pop(0)

    # Solo analizar cada N mensajes para no saturar la API
    if len(_buffer_escalada[cid]) % _ESCALADA_CADA_N_MSG != 0:
        return

    # Adquirir lock antes del análisis — evita que dos corrutinas concurrentes
    # del mismo canal lancen dos peticiones IA y envíen dos pacificadores
    if _locks_escalada[cid].locked():
        return  # otro análisis ya en curso para este canal

    async with _locks_escalada[cid]:
        # Capturar snapshot del buffer dentro del lock para consistencia
        snapshot = list(_buffer_escalada[cid])

    resultado = await hotel_ai.detectar_escalada_grupal(snapshot)
    if not resultado.get("escalada"):
        return

    msg_pac = resultado.get("mensaje_pacificador", "").strip()
    if not msg_pac:
        msg_pac = "Recordad que el respeto es la base de esta comunidad. 🙏"

    e = discord.Embed(
        description=f"🕊️ {msg_pac}",
        color=COLOR_DORADO,
    )
    e.set_footer(text="Von Crastenburg Hotel • Moderación IA")
    await message.channel.send(embed=e)
    # Limpiar buffer tras intervención para no disparar doble
    _buffer_escalada[cid] = []


async def _detectar_y_ofrecer_ticket(message: discord.Message, contenido: str) -> bool:
    """Si la IA detecta que el mensaje expresa una duda, ofrece abrir un ticket.
    Devuelve True si se detectó la duda (y por tanto ya se respondió), para que
    el chat general no vuelva a responder al mismo mensaje."""
    es_duda = await hotel_ai.detectar_duda(contenido)
    if not es_duda:
        return False
    e = discord.Embed(
        title="🤔 ¿Necesitas ayuda?",
        description=f"{message.author.mention}, parece que tienes una duda. ¿Quieres abrir un ticket para que te ayudemos?",
        color=COLOR_DORADO,
    )
    await message.reply(embed=e, view=OfrecerTicketView(message.author.id), mention_author=False)
    return True


async def _responder_ia_ticket(message: discord.Message, contenido: str):
    """Responde automáticamente dentro de un ticket con IA:
    - Analiza el estado emocional del usuario para modular el tono
    - Resuelve autónomamente o escala con resumen ultra-conciso para el staff
    - Actualiza el topic del canal al escalar para señalizar el estado
    """
    async with message.channel.typing():
        db_hotel    = cargar_db(HOTEL_DB_FILE)
        db_reservas = cargar_db(RESERVAS_DB)
        uid         = str(message.author.id)
        perfil      = db_hotel.get(uid)
        reservas    = [r for r in db_reservas.values() if str(r.get("usuario_id")) == uid]

        # ── Analizar estado emocional para modular el tono ───────────────────
        emocion   = await hotel_ai.analizar_emocion(contenido)
        estado    = emocion.get("estado", "neutro")
        intensidad = emocion.get("intensidad", "baja")

        contexto  = hotel_ai.construir_contexto(perfil, reservas)
        contexto += f"\n[El usuario está en un ticket de soporte automático: #{message.channel.name}]"

        # Inyectar directiva de tono según el estado emocional detectado
        if estado in ("frustrado", "enojado") and intensidad in ("media", "alta"):
            contexto += (
                f"\n[TONO REQUERIDO — Estado: {estado.upper()} / Intensidad: {intensidad}] "
                "Reconoce su situación con empatía genuina ANTES de dar información o soluciones. "
                "Valida su frustración en una frase breve, luego ve al grano. "
                "Si necesitas más datos, haz SOLO UNA pregunta."
            )
        elif estado == "confuso":
            contexto += (
                "\n[TONO REQUERIDO — Estado: CONFUSO] "
                "El usuario no entiende el proceso. Explica con pasos numerados simples. "
                "No asumas conocimientos previos. Si necesitas aclaración, haz SOLO UNA pregunta."
            )
        elif estado == "urgente":
            contexto += (
                "\n[TONO REQUERIDO — Estado: URGENTE] "
                "Ve directo al grano. Sin introducción. Prioriza la solución inmediata. "
                "Solo pide datos si son absolutamente imprescindibles."
            )
        else:
            contexto += (
                "\n[TONO REQUERIDO] Profesional y directo. "
                "Si necesitas más datos, haz SOLO UNA pregunta, no varias a la vez."
            )

        respuesta = await hotel_ai.consultar_ia(
            user_id          = uid,
            display_name     = message.author.display_name,
            mensaje          = contenido,
            contexto_hotel   = contexto,
            permitir_escalar = True,
            scope            = f"ticket:{message.channel.id}",
        )

    escalar          = "[ESCALAR]" in respuesta
    respuesta_limpia = respuesta.replace("[ESCALAR]", "").strip()

    trozos = [respuesta_limpia[i:i+4000] for i in range(0, len(respuesta_limpia), 4000)] or [""]
    for idx, trozo in enumerate(trozos):
        e = discord.Embed(
            title       = "🤖 VON CRASTENHBURG HOTEL AI" if idx == 0 else "",
            description = trozo,
            color       = COLOR_DORADO,
        )
        if idx == 0:
            e.set_footer(text="Respuesta automática • VonStay")
        await message.channel.send(embed=e)

    if escalar:
        _desactivar_ia_ticket(message.channel.id)

        # Generar resumen del caso para el staff (en paralelo con el resto)
        historial_ticket = hotel_ai.get_historial(uid, scope=f"ticket:{message.channel.id}")
        resumen = await hotel_ai.generar_resumen_ticket(historial_ticket)

        # Marcar el canal como "Esperando Staff" en el topic
        try:
            await message.channel.edit(topic="⏳ Estado: Esperando Staff — La IA no pudo resolver este caso")
        except Exception:
            pass

        rol     = message.guild.get_role(ID_ROL_SUPERIOR)
        mencion = rol.mention if rol else f"<@&{ID_ROL_SUPERIOR}>"
        e_escalar = discord.Embed(
            title="🚨 Escalado a Staff — Intervención requerida",
            description=(
                f"**Canal:** {message.channel.mention}\n"
                f"**Usuario:** {message.author.mention}\n\n"
                f"**📋 Resumen del caso:**\n{resumen}"
            ),
            color=COLOR_ROJO,
        )
        e_escalar.set_footer(text="⏳ Estado: Esperando Staff • AutoMod IA • VonStay")
        await message.channel.send(content=mencion, embed=e_escalar)


async def _responder_ia_reserva(message: discord.Message, contenido: str):
    """Responde en tickets de reservas usando el Agente de Reservas IA dedicado.
    Reconstruye el contexto completo (bot DB + Base44) en cada mensaje para máxima precisión.
    Escala con resumen ultra-conciso si el caso supera las capacidades del agente."""
    async with message.channel.typing():
        db_hotel    = cargar_db(HOTEL_DB_FILE)
        db_reservas = cargar_db(RESERVAS_DB)
        uid         = str(message.author.id)
        perfil      = db_hotel.get(uid)

        # Reservas del bot + Base44 en paralelo
        reservas_bot = sorted(
            [r for r in db_reservas.values() if str(r.get("usuario_id")) == uid],
            key=lambda r: r.get("fecha", ""),
            reverse=True,
        )
        reservas_web = await _buscar_reservas_web(message.author)

        contexto = reservas_ai.construir_contexto_reservas(
            perfil       = perfil,
            reservas_bot = reservas_bot,
            reservas_web = reservas_web,
        )

        respuesta = await reservas_ai.consultar_reservas_ia(
            user_id           = uid,
            display_name      = message.author.display_name,
            mensaje           = contenido,
            contexto_reservas = contexto,
            permitir_escalar  = True,
            scope             = f"reserva:{message.channel.id}",
        )

    escalar          = "[ESCALAR]" in respuesta
    respuesta_limpia = respuesta.replace("[ESCALAR]", "").strip()

    trozos = [respuesta_limpia[i:i+4000] for i in range(0, len(respuesta_limpia), 4000)] or [""]
    for idx, trozo in enumerate(trozos):
        e = discord.Embed(
            title       = "🏨 Agente de Reservas IA" if idx == 0 else "",
            description = trozo,
            color       = COLOR_DORADO,
        )
        if idx == 0:
            e.set_footer(text="Agente de Reservas IA • VonStay • Von Crastenburg Hotel")
        await message.channel.send(embed=e)

    if escalar:
        _desactivar_ticket_reserva(message.channel.id)

        # Generar resumen del caso para el staff
        historial = reservas_ai.get_historial(uid, scope=f"reserva:{message.channel.id}")
        resumen   = await hotel_ai.generar_resumen_ticket(historial)

        # Actualizar topic del canal
        try:
            await message.channel.edit(topic="⏳ Estado: Esperando Staff — Ticket de Reservas escalado")
        except Exception:
            pass

        rol     = message.guild.get_role(ID_ROL_SUPERIOR)
        mencion = rol.mention if rol else f"<@&{ID_ROL_SUPERIOR}>"
        e_esc = discord.Embed(
            title="🚨 Ticket de Reservas — Escalado a Staff",
            description=(
                f"**Canal:** {message.channel.mention}\n"
                f"**Huésped:** {message.author.mention}\n\n"
                f"**📋 Resumen del caso:**\n{resumen}"
            ),
            color=COLOR_ROJO,
        )
        e_esc.set_footer(text="⏳ Estado: Esperando Staff • Agente Reservas IA • VonStay")
        await message.channel.send(content=mencion, embed=e_esc)


@bot.tree.command(name="expulsar", description="[MOD] Expulsa a un miembro del servidor")
@app_commands.describe(usuario="Miembro a expulsar", razon="Motivo de la expulsión")
async def expulsar(interaction: discord.Interaction, usuario: discord.Member, razon: str = "Sin motivo indicado"):
    if not interaction.user.guild_permissions.kick_members:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Necesitas permiso de expulsión.", COLOR_NEGRO), ephemeral=True); return
    if usuario.top_role >= interaction.user.top_role:
        await interaction.response.send_message(embed=embed_von("❌ No puedes", "No puedes expulsar a alguien con igual o mayor rango.", COLOR_NEGRO), ephemeral=True); return

    try:
        await usuario.send(embed=_con_logo(discord.Embed(
            title="🚷 Has sido expulsado/a",
            description=f"Has sido expulsado/a de **{interaction.guild.name}**.\n**Motivo:** {razon}",
            color=COLOR_ROJO,
        )), file=_logo_file())
    except Exception:
        pass

    await usuario.kick(reason=f"[{interaction.user}] {razon}")
    e = discord.Embed(title="🚷 Expulsión", color=COLOR_ROJO)
    e.add_field(name="👤 Usuario",     value=f"{usuario} (`{usuario.id}`)", inline=False)
    e.add_field(name="🛡️ Moderador",  value=str(interaction.user),         inline=True)
    e.add_field(name="📝 Motivo",      value=razon,                         inline=False)
    e.set_footer(text=f"{datetime.now().strftime('%d/%m/%Y %H:%M')} • VonStay")
    await interaction.response.send_message(embed=e)
    await _log_mod(interaction, e)


@bot.tree.command(name="banear", description="[MOD] Banea permanentemente a un usuario")
@app_commands.describe(usuario="Miembro a banear", razon="Motivo del baneo", borrar_dias="Días de mensajes a borrar (0-7)")
async def banear(interaction: discord.Interaction, usuario: discord.Member, razon: str = "Sin motivo indicado", borrar_dias: int = 1):
    if not interaction.user.guild_permissions.ban_members:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Necesitas permiso de baneo.", COLOR_NEGRO), ephemeral=True); return
    if usuario.top_role >= interaction.user.top_role:
        await interaction.response.send_message(embed=embed_von("❌ No puedes", "No puedes banear a alguien con igual o mayor rango.", COLOR_NEGRO), ephemeral=True); return

    borrar_dias = max(0, min(7, borrar_dias))
    try:
        await usuario.send(embed=_con_logo(discord.Embed(
            title="🔨 Has sido baneado/a",
            description=f"Has sido baneado/a permanentemente de **{interaction.guild.name}**.\n**Motivo:** {razon}",
            color=COLOR_ROJO,
        )), file=_logo_file())
    except Exception:
        pass

    await usuario.ban(reason=f"[{interaction.user}] {razon}", delete_message_days=borrar_dias)
    e = discord.Embed(title="🔨 Baneo Permanente", color=COLOR_ROJO)
    e.add_field(name="👤 Usuario",    value=f"{usuario} (`{usuario.id}`)", inline=False)
    e.add_field(name="🛡️ Moderador", value=str(interaction.user),         inline=True)
    e.add_field(name="📝 Motivo",     value=razon,                         inline=False)
    e.add_field(name="🗑️ Mensajes",  value=f"Últimos {borrar_dias} día(s) borrados", inline=True)
    e.set_footer(text=f"{datetime.now().strftime('%d/%m/%Y %H:%M')} • VonStay")
    await interaction.response.send_message(embed=e)
    await _log_mod(interaction, e)


@bot.tree.command(name="desbanear", description="[MOD] Desbanea a un usuario")
@app_commands.describe(usuario_id="ID del usuario a desbanear", razon="Motivo del desbaneo")
async def desbanear(interaction: discord.Interaction, usuario_id: str, razon: str = "Sin motivo indicado"):
    if not interaction.user.guild_permissions.ban_members:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Necesitas permiso de baneo.", COLOR_NEGRO), ephemeral=True); return
    try:
        uid = int(usuario_id)
        user = await bot.fetch_user(uid)
        await interaction.guild.unban(user, reason=f"[{interaction.user}] {razon}")
        e = discord.Embed(title="✅ Usuario Desbaneado", color=COLOR_DORADO)
        e.add_field(name="👤 Usuario",    value=f"{user} (`{uid}`)", inline=False)
        e.add_field(name="🛡️ Moderador", value=str(interaction.user), inline=True)
        e.add_field(name="📝 Motivo",     value=razon, inline=False)
        e.set_footer(text=f"{datetime.now().strftime('%d/%m/%Y %H:%M')} • VonStay")
        await interaction.response.send_message(embed=e)
        await _log_mod(interaction, e)
    except discord.NotFound:
        await interaction.response.send_message(embed=embed_von("❌ No encontrado", "Ese usuario no está baneado o el ID es incorrecto.", COLOR_NEGRO), ephemeral=True)
    except ValueError:
        await interaction.response.send_message(embed=embed_von("❌ ID inválido", "Introduce un ID de usuario válido.", COLOR_NEGRO), ephemeral=True)


@bot.tree.command(name="silenciar", description="[MOD] Silencia a un miembro temporalmente (timeout)")
@app_commands.describe(usuario="Miembro a silenciar", minutos="Duración en minutos (máx. 40320 = 4 semanas)", razon="Motivo")
async def silenciar(interaction: discord.Interaction, usuario: discord.Member, minutos: int, razon: str = "Sin motivo indicado"):
    if not interaction.user.guild_permissions.moderate_members:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Necesitas permiso de moderar miembros.", COLOR_NEGRO), ephemeral=True); return
    if usuario.top_role >= interaction.user.top_role:
        await interaction.response.send_message(embed=embed_von("❌ No puedes", "No puedes silenciar a alguien con igual o mayor rango.", COLOR_NEGRO), ephemeral=True); return

    minutos = max(1, min(40320, minutos))
    hasta = discord.utils.utcnow() + timedelta(minutes=minutos)
    await usuario.timeout(hasta, reason=f"[{interaction.user}] {razon}")

    hh = minutos // 60; mm = minutos % 60
    duracion_txt = f"{hh}h {mm}min" if hh else f"{mm}min"

    try:
        await usuario.send(embed=_con_logo(discord.Embed(
            title="🔇 Has sido silenciado/a",
            description=f"Has sido silenciado/a en **{interaction.guild.name}** por **{duracion_txt}**.\n**Motivo:** {razon}",
            color=COLOR_ROJO,
        )), file=_logo_file())
    except Exception:
        pass

    e = discord.Embed(title="🔇 Silencio (Timeout)", color=COLOR_ROJO)
    e.add_field(name="👤 Usuario",     value=f"{usuario} (`{usuario.id}`)", inline=False)
    e.add_field(name="🛡️ Moderador",  value=str(interaction.user),         inline=True)
    e.add_field(name="⏱️ Duración",   value=duracion_txt,                  inline=True)
    e.add_field(name="📝 Motivo",      value=razon,                         inline=False)
    e.set_footer(text=f"{datetime.now().strftime('%d/%m/%Y %H:%M')} • VonStay")
    await interaction.response.send_message(embed=e)
    await _log_mod(interaction, e)


@bot.tree.command(name="quitar_silencio", description="[MOD] Quita el silencio de un miembro")
@app_commands.describe(usuario="Miembro a liberar del silencio")
async def quitar_silencio(interaction: discord.Interaction, usuario: discord.Member):
    if not interaction.user.guild_permissions.moderate_members:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Necesitas permiso de moderar miembros.", COLOR_NEGRO), ephemeral=True); return
    await usuario.timeout(None)
    e = discord.Embed(title="🔊 Silencio eliminado", color=COLOR_DORADO)
    e.add_field(name="👤 Usuario",    value=f"{usuario}", inline=True)
    e.add_field(name="🛡️ Moderador", value=str(interaction.user), inline=True)
    e.set_footer(text=f"{datetime.now().strftime('%d/%m/%Y %H:%M')} • VonStay")
    await interaction.response.send_message(embed=e)
    await _log_mod(interaction, e)


@bot.tree.command(name="advertencia", description="[MOD] Registra una advertencia para un usuario")
@app_commands.describe(usuario="Usuario a advertir", motivo="Motivo de la advertencia")
async def advertencia(interaction: discord.Interaction, usuario: discord.Member, motivo: str):
    if not _check_mod(interaction):
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Solo moderadores.", COLOR_NEGRO), ephemeral=True); return

    db  = cargar_db(WARNS_DB)
    uid = str(usuario.id)
    if uid not in db:
        db[uid] = {"nombre": usuario.display_name, "advertencias": []}

    db[uid]["nombre"] = usuario.display_name
    db[uid]["advertencias"].append({
        "motivo":    motivo,
        "moderador": str(interaction.user),
        "fecha":     datetime.now().strftime("%d/%m/%Y %H:%M"),
    })
    guardar_db(WARNS_DB, db)
    total = len(db[uid]["advertencias"])

    try:
        await usuario.send(embed=_con_logo(discord.Embed(
            title="⚠️ Has recibido una advertencia",
            description=(
                f"Has recibido una advertencia en **{interaction.guild.name}**.\n"
                f"**Motivo:** {motivo}\n"
                f"**Total de advertencias:** {total}"
            ),
            color=COLOR_ROJO,
        )), file=_logo_file())
    except Exception:
        pass

    e = discord.Embed(title="⚠️ Advertencia registrada", color=COLOR_ROJO)
    e.add_field(name="👤 Usuario",         value=f"{usuario} (`{usuario.id}`)", inline=False)
    e.add_field(name="🛡️ Moderador",      value=str(interaction.user),         inline=True)
    e.add_field(name="📝 Motivo",          value=motivo,                        inline=False)
    e.add_field(name="🔢 Total advertencias", value=str(total),                 inline=True)
    e.set_footer(text=f"{datetime.now().strftime('%d/%m/%Y %H:%M')} • VonStay")
    await interaction.response.send_message(embed=e)
    await _log_mod(interaction, e)


@bot.tree.command(name="infracciones", description="Ver las advertencias de un usuario")
@app_commands.describe(usuario="Usuario a consultar (deja vacío para verte tú)")
async def infracciones(interaction: discord.Interaction, usuario: discord.Member | None = None):
    target = usuario or interaction.user
    # Si consultan a otro, requiere permisos
    if usuario and not _check_mod(interaction):
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Solo moderadores pueden ver infracciones de otros.", COLOR_NEGRO), ephemeral=True); return

    db   = cargar_db(WARNS_DB)
    uid  = str(target.id)
    data = db.get(uid)

    if not data or not data.get("advertencias"):
        await interaction.response.send_message(
            embed=embed_von("✅ Sin infracciones", f"**{target.display_name}** no tiene advertencias registradas.", COLOR_DORADO),
            ephemeral=True)
        return

    warns = data["advertencias"]
    e = discord.Embed(title=f"⚠️ Infracciones de {target.display_name}", color=COLOR_ROJO)
    for i, w in enumerate(warns[-10:], 1):
        e.add_field(
            name  = f"#{i} — {w['fecha']}",
            value = f"**Motivo:** {w['motivo']}\n**Por:** {w['moderador']}",
            inline = False,
        )
    e.set_footer(text=f"Total: {len(warns)} advertencia(s) • VonStay")
    e.set_thumbnail(url=target.display_avatar.url)
    await interaction.response.send_message(embed=e, ephemeral=True)


@bot.tree.command(name="borrar_advertencias", description="[MOD] Borra todas las advertencias de un usuario")
@app_commands.describe(usuario="Usuario a limpiar")
async def borrar_advertencias(interaction: discord.Interaction, usuario: discord.Member):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Solo moderadores.", COLOR_NEGRO), ephemeral=True); return
    db  = cargar_db(WARNS_DB)
    uid = str(usuario.id)
    if uid in db:
        db[uid]["advertencias"] = []
        guardar_db(WARNS_DB, db)
    await interaction.response.send_message(
        embed=embed_von("✅ Advertencias borradas", f"Se han eliminado todas las advertencias de **{usuario.display_name}**.", COLOR_DORADO))


@bot.tree.command(name="limpiar", description="[MOD] Elimina mensajes del canal actual")
@app_commands.describe(cantidad="Número de mensajes a eliminar (1-100)")
async def limpiar(interaction: discord.Interaction, cantidad: int):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso", "Necesitas permiso de gestionar mensajes.", COLOR_NEGRO), ephemeral=True); return
    cantidad = max(1, min(100, cantidad))
    await interaction.response.defer(ephemeral=True)
    borrados = await interaction.channel.purge(limit=cantidad)
    e = discord.Embed(title="🗑️ Mensajes eliminados", color=COLOR_DORADO)
    e.add_field(name="🔢 Cantidad",   value=str(len(borrados)), inline=True)
    e.add_field(name="📍 Canal",      value=interaction.channel.mention, inline=True)
    e.add_field(name="🛡️ Moderador", value=str(interaction.user), inline=True)
    e.set_footer(text=f"{datetime.now().strftime('%d/%m/%Y %H:%M')} • VonStay")
    await interaction.followup.send(embed=e, ephemeral=True)
    await _log_mod(interaction, e)

# ==========================================
# ASISTENTE IA — VON CRASTENHBURG HOTEL AI
# ==========================================

@bot.tree.command(name="asistente", description="Consulta al asistente de IA del hotel")
@app_commands.describe(consulta="Tu pregunta o solicitud al asistente del hotel")
async def asistente(interaction: discord.Interaction, consulta: str):
    await interaction.response.defer(thinking=True)

    # Construir contexto dinámico del usuario
    db_hotel    = cargar_db(HOTEL_DB_FILE)
    db_reservas = cargar_db(RESERVAS_DB)
    uid         = str(interaction.user.id)
    perfil      = db_hotel.get(uid)
    reservas    = [r for r in db_reservas.values() if str(r.get("usuario_id")) == uid]
    contexto    = hotel_ai.construir_contexto(perfil, reservas)

    respuesta = await hotel_ai.consultar_ia(
        user_id      = uid,
        display_name = interaction.user.display_name,
        mensaje      = consulta,
        contexto_hotel = contexto,
        scope        = "asistente",
    )

    # Discord tiene límite de 4096 en description de embed y 2000 en mensaje plano
    # Dividimos si la respuesta es muy larga
    trozos = [respuesta[i:i+4000] for i in range(0, len(respuesta), 4000)]

    for idx, trozo in enumerate(trozos):
        e = discord.Embed(
            title       = "🤖 VON CRASTENHBURG HOTEL AI" if idx == 0 else "",
            description = trozo,
            color       = COLOR_DORADO,
        )
        if idx == 0:
            e.set_footer(text="✨ VonStay • Escribe /asistente para continuar la conversación")
        if idx == 0:
            await interaction.followup.send(embed=e)
        else:
            await interaction.followup.send(embed=e)


@bot.tree.command(name="resetear_ia", description="Reinicia tu conversación con el asistente de IA")
async def resetear_ia(interaction: discord.Interaction):
    hotel_ai.limpiar_historial(str(interaction.user.id))
    await interaction.response.send_message(
        embed=embed_von(
            "🔄 Conversación reiniciada",
            "Tu historial de conversación con el asistente ha sido borrado.\nPuedes comenzar una nueva consulta con `/asistente`.",
            COLOR_DORADO,
        ),
        ephemeral=True,
    )


# ==========================================
# FUNCIONALIDADES v2 — TURNOS, TIENDA, STATS
# ==========================================

# ── Helpers panel de turnos ───────────────
def _cargar_panel_turnos_msg() -> int | None:
    d = cargar_db(PANEL_TURNOS_FILE)
    return d.get("msg_id")

def _guardar_panel_turnos_msg(msg_id: int):
    guardar_db(PANEL_TURNOS_FILE, {"msg_id": msg_id})

# ── Gestión de roles de turno ─────────────
async def _gestionar_rol_turno(guild: discord.Guild | None, member: discord.Member | None, en_servicio: bool):
    """Asigna/quita los roles 'En servicio' / 'Fuera de servicio'. Los crea si no existen."""
    if not guild or not member:
        return
    try:
        rol_en  = discord.utils.get(guild.roles, name=ROL_EN_SERVICIO)
        rol_fue = discord.utils.get(guild.roles, name=ROL_FUERA_SERVICIO)
        if rol_en is None:
            rol_en = await guild.create_role(name=ROL_EN_SERVICIO,  color=discord.Color.green(),   reason="VonStay — turno automático")
        if rol_fue is None:
            rol_fue = await guild.create_role(name=ROL_FUERA_SERVICIO, color=discord.Color.greyple(), reason="VonStay — turno automático")
        if en_servicio:
            await member.add_roles(rol_en)
            if rol_fue in member.roles:
                await member.remove_roles(rol_fue)
        else:
            await member.add_roles(rol_fue)
            if rol_en in member.roles:
                await member.remove_roles(rol_en)
    except Exception as ex:
        print(f"[Roles turno] {ex}")

# ── Panel de turnos ───────────────────────
async def _build_panel_turnos_embed() -> discord.Embed:
    db  = cargar_db(FICHAS_DB)
    hoy = datetime.now().strftime("%d/%m/%Y")
    activos = [v for v in db.values() if v.get("fecha") == hoy and v.get("salida") is None]
    activos.sort(key=lambda x: x.get("entrada",""))
    e = discord.Embed(title="👔 Turnos activos — Von Crastenburg", color=COLOR_DORADO)
    if activos:
        lineas = []
        for f in activos:
            nombre  = f.get("nombre","—")
            entrada = f.get("entrada","—")
            try:
                dt_ent = datetime.strptime(f"{hoy} {entrada}", "%d/%m/%Y %H:%M:%S")
                delta  = datetime.now() - dt_ent
                hh = int(delta.total_seconds() // 3600)
                mm = int((delta.total_seconds() % 3600) // 60)
                dur = f"{hh}h {mm}min"
            except Exception:
                dur = "—"
            lineas.append(f"🟢 **{nombre}** — desde {entrada[:5]} · {dur}")
        e.description = "\n".join(lineas)
    else:
        e.description = "*No hay empleados en turno ahora mismo.*"
    e.set_footer(text=f"🔄 Actualizado: {datetime.now().strftime('%H:%M:%S')}  ·  VonStay")
    return e

async def tarea_panel_turnos():
    await bot.wait_until_ready()
    await asyncio.sleep(25)
    print("[Panel Turnos] Tarea iniciada")
    while not bot.is_closed():
        try:
            for guild in bot.guilds:
                canal = discord.utils.get(guild.text_channels, name="panel-turnos")
                if canal:
                    embed  = await _build_panel_turnos_embed()
                    msg_id = _cargar_panel_turnos_msg()
                    if msg_id:
                        try:
                            msg = await canal.fetch_message(msg_id)
                            await msg.edit(embed=embed)
                        except (discord.NotFound, discord.Forbidden):
                            msg = await canal.send(embed=embed)
                            _guardar_panel_turnos_msg(msg.id)
                    break
        except Exception as ex:
            print(f"[Panel Turnos] {ex}")
        await asyncio.sleep(60)

# ── Resumen semanal (lunes 09:00 → manager) ─
async def tarea_resumen_semanal():
    await bot.wait_until_ready()
    await asyncio.sleep(30)
    print("[Resumen Semanal] Tarea iniciada")
    enviado_semana = ""
    while not bot.is_closed():
        try:
            ahora = datetime.now()
            semana_key = ahora.strftime("%Y-W%W")
            if ahora.weekday() == 0 and ahora.hour == 9 and ahora.minute < 5 and enviado_semana != semana_key:
                enviado_semana = semana_key
                # Semana anterior: lunes 00:00 → domingo 23:59 (comparación limpia por fecha)
                lunes_esta_semana = ahora.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=ahora.weekday())
                inicio = lunes_esta_semana - timedelta(days=7)   # lunes semana anterior
                fin    = lunes_esta_semana - timedelta(seconds=1) # domingo semana anterior 23:59:59
                db     = cargar_db(FICHAS_DB)
                horas_uid: dict[str,float] = {}
                nombre_uid: dict[str,str]  = {}
                for v in db.values():
                    if not v.get("horas"):
                        continue
                    try:
                        fd = datetime.strptime(v["fecha"], "%d/%m/%Y")
                    except Exception:
                        continue
                    if inicio <= fd <= fin:
                        uid = v.get("uid","?")
                        horas_uid[uid]  = horas_uid.get(uid,0.0) + float(v["horas"])
                        nombre_uid[uid] = v.get("nombre", uid)
                if horas_uid:
                    manager = await bot.fetch_user(ID_MANAGER)
                    if manager:
                        e = discord.Embed(
                            title="📋 Resumen semanal de turnos",
                            description=f"Semana del **{inicio.strftime('%d/%m/%Y')}** al **{ahora.strftime('%d/%m/%Y')}**",
                            color=COLOR_DORADO,
                        )
                        total_h = 0.0
                        for uid, h in sorted(horas_uid.items(), key=lambda x: x[1], reverse=True):
                            hh = int(h); mm = int((h-hh)*60)
                            e.add_field(name=nombre_uid.get(uid,uid), value=f"⏱️ {hh}h {mm}min", inline=True)
                            total_h += h
                        hh_t = int(total_h); mm_t = int((total_h-hh_t)*60)
                        e.set_footer(text=f"Total equipo: {hh_t}h {mm_t}min  ·  VonStay")
                        await manager.send(embed=e)
                        print("[Resumen Semanal] ✅ Enviado")
        except Exception as ex:
            print(f"[Resumen Semanal] {ex}")
        await asyncio.sleep(60)

# ── Alertas de mantenimiento (cada 10 min) ─
async def tarea_alertas_mantenimiento():
    await bot.wait_until_ready()
    await asyncio.sleep(35)
    print("[Alertas Mant.] Tarea iniciada")
    alertadas: set[str] = set()
    while not bot.is_closed():
        try:
            rooms = await b44.get_all_rooms(limit=60)
            ahora = datetime.now()
            for room in rooms:
                rid    = room.get("id","")
                status = room.get("status","")
                if status not in ("cleaning","maintenance"):
                    alertadas.discard(rid); continue
                if rid in alertadas:
                    continue
                upd_raw = room.get("updated_date") or room.get("updated_at") or ""
                if upd_raw:
                    try:
                        upd = datetime.fromisoformat(upd_raw.replace("Z","+00:00")).replace(tzinfo=None)
                        if (ahora - upd).total_seconds() / 3600 < HORAS_ALERTA_MANT:
                            continue
                    except Exception:
                        pass
                for guild in bot.guilds:
                    canal = (discord.utils.get(guild.text_channels, name="logs-fichas") or
                             discord.utils.get(guild.text_channels, name="logs-reservas"))
                    if canal:
                        num  = room.get("room_number","?")
                        tipo = TIPO_LABEL.get(room.get("type",""), room.get("type","?"))
                        est  = "🔵 En limpieza" if status == "cleaning" else "⚫ Mantenimiento"
                        ae   = discord.Embed(
                            title="🔧 Alerta de mantenimiento",
                            description=(f"La habitación **#{num} {tipo}** lleva más de **{HORAS_ALERTA_MANT:.0f}h** "
                                         f"en estado **{est}**.\nPor favor actualiza el estado cuando esté lista."),
                            color=COLOR_ROJO,
                        )
                        ae.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
                        await canal.send(embed=ae)
                        alertadas.add(rid)
                        break
        except Exception as ex:
            print(f"[Alertas Mant.] {ex}")
        await asyncio.sleep(600)

# ── Log diario (23:58) ────────────────────
async def tarea_log_diario():
    await bot.wait_until_ready()
    await asyncio.sleep(40)
    print("[Log Diario] Tarea iniciada")
    enviado_hoy = ""
    while not bot.is_closed():
        try:
            ahora = datetime.now()
            hoy   = ahora.strftime("%d/%m/%Y")
            if ahora.hour == 23 and ahora.minute >= 58 and enviado_hoy != hoy:
                enviado_hoy = hoy
                reservas = cargar_db(RESERVAS_DB)
                fichas   = cargar_db(FICHAS_DB)
                fichas_hoy   = [f for f in fichas.values() if f.get("fecha") == hoy]
                horas_hoy    = sum(float(f.get("horas",0) or 0) for f in fichas_hoy if f.get("salida"))
                en_turno_ahora = sum(1 for f in fichas_hoy if f.get("salida") is None)
                nuevas    = sum(1 for r in reservas.values() if r.get("creada","").startswith(hoy) and r.get("estado") not in ("cancelada",))
                checkouts = sum(1 for r in reservas.values() if r.get("estado") == "completada" and r.get("creada","").startswith(hoy))
                hh = int(horas_hoy); mm = int((horas_hoy-hh)*60)
                e = discord.Embed(title=f"📝 Resumen del día — {hoy}", color=COLOR_DORADO)
                e.add_field(name="📋 Nuevas reservas",  value=str(nuevas),           inline=True)
                e.add_field(name="🚪 Check-outs",       value=str(checkouts),         inline=True)
                e.add_field(name="👔 Fichajes hoy",     value=str(len(fichas_hoy)),   inline=True)
                e.add_field(name="⏱️ Horas trabajadas",value=f"{hh}h {mm}min",       inline=True)
                e.add_field(name="🟢 Turno abierto",    value=str(en_turno_ahora),    inline=True)
                e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
                for guild in bot.guilds:
                    canal = (discord.utils.get(guild.text_channels, name="logs-reservas") or
                             discord.utils.get(guild.text_channels, name="logs-fichas") or
                             guild.system_channel)
                    if canal:
                        await canal.send(embed=e); break
                print("[Log Diario] ✅ Enviado")
        except Exception as ex:
            print(f"[Log Diario] {ex}")
        await asyncio.sleep(60)

# ── Valoraciones ──────────────────────────
async def _enviar_valoracion_dm(user: discord.abc.User, reserva_ref: str):
    """Envía DM con 5 botones de estrella al huésped tras el checkout."""
    e = discord.Embed(
        title="⭐ ¿Cómo fue tu estancia?",
        description=(
            "Gracias por alojarte en el **Von Crastenburg Hotel**.\n"
            "Tu opinión nos ayuda a mejorar. Puntúa tu experiencia:"
        ),
        color=COLOR_DORADO,
    )
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    view = discord.ui.View(timeout=None)
    labels = ["⭐ 1", "⭐⭐ 2", "⭐⭐⭐ 3", "⭐⭐⭐⭐ 4", "⭐⭐⭐⭐⭐ 5"]
    styles = [discord.ButtonStyle.danger, discord.ButtonStyle.danger,
              discord.ButtonStyle.primary, discord.ButtonStyle.primary, discord.ButtonStyle.success]
    for i, (lbl, sty) in enumerate(zip(labels, styles), start=1):
        view.add_item(discord.ui.Button(label=lbl, style=sty, custom_id=f"valorar:{reserva_ref}:{i}"))
    try:
        await user.send(embed=e, view=view)
    except discord.Forbidden:
        pass

# ── View check-in/checkout en DM ─────────
def _view_checkinout_dm(rid: str) -> discord.ui.View:
    view = discord.ui.View(timeout=None)
    view.add_item(discord.ui.Button(
        label="🏨 CHECK-IN", style=discord.ButtonStyle.green, custom_id=f"checkin:{rid}"))
    view.add_item(discord.ui.Button(
        label="🚪 CHECK-OUT", style=discord.ButtonStyle.red, custom_id=f"checkout:{rid}"))
    return view

# ── Handlers DM interacciones ─────────────
async def _dm_handle_checkin(interaction: discord.Interaction, rid: str):
    await interaction.response.defer()
    db    = cargar_db(RESERVAS_DB)
    local = next((r for r in db.values() if r.get("reserva_b44_id") == rid), None)
    if local:
        if local.get("estado") not in ("confirmada",):
            await interaction.followup.send(embed=embed_von("⚠️ Ya procesada", f"Estado actual: **{local.get('estado')}**.", COLOR_NEGRO)); return
        local["estado"] = "checkin"
        guardar_db(RESERVAS_DB, db)
        if local.get("room_b44_id"):
            await b44.update_room_status(local["room_b44_id"], "occupied", local.get("usuario_nombre",""))
    else:
        # Reserva web sin entrada local — se actualiza solo en Base44 (el DM es privado al dueño)
        print(f"[DM Check-in] Reserva {rid} sin entrada local, actualizando solo Base44")
    await b44.update_reservation(rid, {"status": "active"})
    e = discord.Embed(
        title="🔑 Check-In Completado",
        description="¡Bienvenido al **Von Crastenburg Hotel**! Su habitación está lista.\n*Su descanso es nuestro lujo.*",
        color=COLOR_DORADO,
    )
    e.add_field(name="📋 Estado", value="🟢 En estancia", inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.followup.send(embed=e)
    try:
        dv = discord.ui.View(timeout=None)
        dv.add_item(discord.ui.Button(label="✅ Check-in realizado", style=discord.ButtonStyle.grey, custom_id=f"_ci_done:{rid}", disabled=True))
        dv.add_item(discord.ui.Button(label="🚪 CHECK-OUT", style=discord.ButtonStyle.red, custom_id=f"checkout:{rid}"))
        await interaction.message.edit(view=dv)
    except Exception:
        pass

async def _dm_handle_checkout(interaction: discord.Interaction, rid: str):
    await interaction.response.defer()
    db    = cargar_db(RESERVAS_DB)
    local = next((r for r in db.values() if r.get("reserva_b44_id") == rid), None)
    if local:
        if local.get("estado") not in ("confirmada","checkin"):
            await interaction.followup.send(embed=embed_von("⚠️ Ya procesada", f"Estado actual: **{local.get('estado')}**.", COLOR_NEGRO)); return
        local["estado"] = "completada"
        guardar_db(RESERVAS_DB, db)
        if local.get("room_b44_id"):
            await b44.update_room_status(local["room_b44_id"], "cleaning")
    else:
        # Reserva web sin entrada local — se actualiza solo en Base44 (el DM es privado al dueño)
        print(f"[DM Check-out] Reserva {rid} sin entrada local, actualizando solo Base44")
    await b44.update_reservation(rid, {"status": "completed"})
    e = discord.Embed(
        title="🚪 Check-Out Completado",
        description="Gracias por su visita. ¡Le esperamos pronto en el **Von Crastenburg**! 🥂",
        color=COLOR_DORADO,
    )
    e.add_field(name="📋 Estado", value="✅ Estancia completada", inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.followup.send(embed=e)
    try:
        dv = discord.ui.View(timeout=None)
        dv.add_item(discord.ui.Button(label="✅ Check-in realizado", style=discord.ButtonStyle.grey, custom_id=f"_ci_done:{rid}", disabled=True))
        dv.add_item(discord.ui.Button(label="✅ Check-out realizado", style=discord.ButtonStyle.grey, custom_id=f"_co_done:{rid}", disabled=True))
        await interaction.message.edit(view=dv)
    except Exception:
        pass
    await _enviar_valoracion_dm(interaction.user, rid)

async def _dm_handle_valoracion(interaction: discord.Interaction, rid: str, stars: int):
    await interaction.response.defer()
    uid  = str(interaction.user.id)
    db   = cargar_db(VALORACIONES_DB)
    db[f"{uid}_{rid}"] = {
        "uid": uid, "nombre": interaction.user.display_name,
        "estrellas": stars, "reserva_id": rid,
        "fecha": datetime.now().strftime("%d/%m/%Y %H:%M"),
    }
    guardar_db(VALORACIONES_DB, db)
    txt = "⭐" * stars
    e   = discord.Embed(
        title="✨ ¡Gracias por tu valoración!",
        description=f"Has puntuado tu estancia con **{txt}** ({stars}/5).\n¡Hasta la próxima en el Von Crastenburg! 🥂",
        color=COLOR_DORADO,
    )
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.followup.send(embed=e)
    try:
        dv = discord.ui.View(timeout=None)
        dv.add_item(discord.ui.Button(label=f"Valoración enviada {txt}", style=discord.ButtonStyle.grey, custom_id="_val_done", disabled=True))
        await interaction.message.edit(view=dv)
    except Exception:
        pass

# ── on_interaction — DM buttons (via add_listener, no @bot.event) ─
async def _on_interaction_dm_buttons(interaction: discord.Interaction):
    """Manejador de botones de check-in, checkout y valoración enviados por DM.
    Registrado con bot.add_listener para no interferir con el árbol de slash-commands."""
    if interaction.type != discord.InteractionType.component:
        return
    if interaction.response.is_done():
        return  # Ya fue manejado por una vista registrada — no intervenir
    cid = (interaction.data or {}).get("custom_id", "")
    if cid.startswith("checkin:"):
        await _dm_handle_checkin(interaction, cid[8:])
    elif cid.startswith("checkout:"):
        await _dm_handle_checkout(interaction, cid[9:])
    elif cid.startswith("valorar:"):
        parts = cid.split(":")
        if len(parts) == 3:
            try:
                await _dm_handle_valoracion(interaction, parts[1], int(parts[2]))
            except Exception as ex:
                print(f"[Valoración] {ex}")

bot.add_listener(_on_interaction_dm_buttons, "on_interaction")

# ── /panelturnos ──────────────────────────
@bot.tree.command(name="panelturnos", description="[Staff] 👔 Publicar el panel de turnos activos")
async def panelturnos(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso","Solo el staff.", COLOR_NEGRO), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    canal = discord.utils.get(interaction.guild.text_channels, name="panel-turnos")
    if not canal:
        await interaction.followup.send(embed=embed_von("❌ Canal no encontrado","Crea un canal llamado `panel-turnos` primero.", COLOR_NEGRO), ephemeral=True); return
    embed  = await _build_panel_turnos_embed()
    msg_id = _cargar_panel_turnos_msg()
    if msg_id:
        try:
            old = await canal.fetch_message(msg_id); await old.delete()
        except Exception:
            pass
    msg = await canal.send(embed=embed)
    _guardar_panel_turnos_msg(msg.id)
    await interaction.followup.send(embed=embed_von("✅ Panel publicado", f"Panel de turnos publicado en {canal.mention}. Se actualiza cada 60s.", COLOR_DORADO), ephemeral=True)

# ── /ranking_huespedes ────────────────────
@bot.tree.command(name="ranking_huespedes", description="⭐ Ver el ranking de valoraciones de huéspedes")
async def ranking_huespedes(interaction: discord.Interaction):
    db = cargar_db(VALORACIONES_DB)
    if not db:
        await interaction.response.send_message(embed=embed_von("⭐ Sin valoraciones","Aún no hay valoraciones registradas.", COLOR_DORADO), ephemeral=True); return
    totales: dict[str,list] = {}
    nombres: dict[str,str]  = {}
    for entry in db.values():
        uid = entry.get("uid","?")
        totales.setdefault(uid,[]).append(entry.get("estrellas",0))
        nombres[uid] = entry.get("nombre", uid)
    ranking = sorted([(uid, sum(v)/len(v), len(v)) for uid,v in totales.items()], key=lambda x: x[1], reverse=True)
    e = discord.Embed(title="⭐ Ranking de huéspedes — Von Crastenburg", color=COLOR_DORADO)
    medallas = ["🥇","🥈","🥉"]
    for i,(uid,media,n) in enumerate(ranking[:10]):
        med = medallas[i] if i < 3 else f"#{i+1}"
        e.add_field(
            name=f"{med} {nombres.get(uid,uid)}",
            value=f"{'⭐'*round(media)} {media:.1f}/5 · {n} estancia{'s' if n>1 else ''}",
            inline=False,
        )
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.response.send_message(embed=e)

# ── /servicio ─────────────────────────────
class ServicioSelect(discord.ui.Select):
    def __init__(self):
        super().__init__(
            placeholder="Elige el servicio que necesitas…",
            options=[
                discord.SelectOption(label="🍳 Desayuno en habitación",  value="desayuno",    description="Servicio de desayuno a su habitación"),
                discord.SelectOption(label="🛁 Toallas adicionales",     value="toallas",     description="Solicitar toallas extra"),
                discord.SelectOption(label="🔕 No molestar",             value="no_molestar", description="Activar el modo no molestar"),
                discord.SelectOption(label="🧹 Limpieza de habitación",  value="limpieza",    description="Solicitar servicio de limpieza"),
                discord.SelectOption(label="🍾 Servicio de bebidas",     value="bebidas",     description="Refrescos, agua, carta de vinos"),
                discord.SelectOption(label="❓ Otro / Consulta general", value="otro",        description="Cualquier otra solicitud"),
            ],
        )

    async def callback(self, interaction: discord.Interaction):
        ETIQ = {"desayuno":"🍳 Desayuno en habitación","toallas":"🛁 Toallas adicionales",
                "no_molestar":"🔕 No molestar","limpieza":"🧹 Limpieza de habitación",
                "bebidas":"🍾 Servicio de bebidas","otro":"❓ Consulta general"}
        etiqueta = ETIQ.get(self.values[0], self.values[0])
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            await interaction.followup.send("Solo funciona en el servidor.", ephemeral=True); return
        nombre_canal = f"servicio-{interaction.user.name.lower().replace(' ','-')}"
        canal = discord.utils.get(guild.text_channels, name=nombre_canal)
        if not canal:
            ow = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user:   discord.PermissionOverwrite(read_messages=True, send_messages=True),
                guild.me:           discord.PermissionOverwrite(read_messages=True, send_messages=True),
            }
            for role in guild.roles:
                if role.permissions.manage_messages:
                    ow[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
            canal = await guild.create_text_channel(nombre_canal, overwrites=ow)
        se = discord.Embed(
            title=f"🛎️ Solicitud — {etiqueta}",
            description=f"**Huésped:** {interaction.user.mention}\n**Servicio:** {etiqueta}\n\nEl staff le atenderá en breve. Puede escribir aquí los detalles.",
            color=COLOR_DORADO,
        )
        se.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await canal.send(embed=se, view=CerrarTicketView())
        await interaction.followup.send(embed=embed_von("✅ Servicio solicitado", f"Tu solicitud de **{etiqueta}** ha sido enviada.\nEl staff te atenderá en {canal.mention}.", COLOR_DORADO), ephemeral=True)

class ServicioView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=120)
        self.add_item(ServicioSelect())

@bot.tree.command(name="servicio", description="🛎️ Solicitar un servicio de habitación")
async def servicio(interaction: discord.Interaction):
    e = discord.Embed(
        title="🛎️ Servicio de Habitaciones — Von Crastenburg",
        description="Selecciona el servicio que necesitas y el staff se pondrá en contacto contigo.",
        color=COLOR_DORADO,
    )
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.response.send_message(embed=e, view=ServicioView(), ephemeral=True)

# ── /tienda ───────────────────────────────
class TiendaSelect(discord.ui.Select):
    def __init__(self):
        super().__init__(
            placeholder="Elige un artículo…",
            options=[
                discord.SelectOption(
                    label=f"{it['emoji']} {it['nombre']}",
                    value=it["id"],
                    description=f"Precio: {it['precio']} VonCoins",
                )
                for it in TIENDA_ITEMS
            ],
        )

    async def callback(self, interaction: discord.Interaction):
        item = next((i for i in TIENDA_ITEMS if i["id"] == self.values[0]), None)
        if not item:
            await interaction.response.send_message("Artículo no encontrado.", ephemeral=True); return
        db  = cargar_db(HOTEL_DB_FILE)
        uid = str(interaction.user.id)
        if uid not in db:
            await interaction.response.send_message(embed=embed_von("❌ No registrado","Usa `/registro` primero.", COLOR_NEGRO), ephemeral=True); return
        puntos = db[uid].get("puntos",0)
        if puntos < item["precio"]:
            await interaction.response.send_message(
                embed=embed_von("❌ Saldo insuficiente", f"Tienes **{puntos}** VonCoins y el artículo cuesta **{item['precio']}**.", COLOR_NEGRO),
                ephemeral=True,
            ); return
        db[uid]["puntos"] = puntos - item["precio"]
        guardar_db(HOTEL_DB_FILE, db)
        compras = cargar_db(TIENDA_COMPRAS_DB)
        compras[f"{uid}_{datetime.now().strftime('%Y%m%d%H%M%S')}"] = {
            "uid": uid, "nombre": interaction.user.display_name,
            "item_id": item["id"], "item_nombre": item["nombre"],
            "precio": item["precio"], "fecha": datetime.now().strftime("%d/%m/%Y %H:%M"),
        }
        guardar_db(TIENDA_COMPRAS_DB, compras)
        e = discord.Embed(
            title=f"🛍️ ¡Compra realizada! {item['emoji']}",
            description=f"Has adquirido **{item['nombre']}**.\nEl staff gestionará tu solicitud en breve.",
            color=COLOR_DORADO,
        )
        e.add_field(name="💳 Coste",          value=f"{item['precio']} VonCoins",    inline=True)
        e.add_field(name="💰 Saldo restante", value=f"{db[uid]['puntos']} VonCoins",  inline=True)
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        await interaction.response.send_message(embed=e, ephemeral=True)
        if interaction.guild:
            await log_staff(interaction.guild, embed_von(
                f"🛍️ Compra en tienda — {item['emoji']} {item['nombre']}",
                f"**{interaction.user.display_name}** compró **{item['nombre']}** por {item['precio']} VonCoins.",
                COLOR_DORADO,
            ))

class TiendaView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=120)
        self.add_item(TiendaSelect())

@bot.tree.command(name="tienda", description="🏪 Tienda del hotel — canjea VonCoins por servicios")
async def tienda(interaction: discord.Interaction):
    db     = cargar_db(HOTEL_DB_FILE)
    uid    = str(interaction.user.id)
    puntos = db.get(uid,{}).get("puntos",0) if uid in db else 0
    desc   = "\n".join(f"{it['emoji']} **{it['nombre']}** — `{it['precio']} VonCoins`" for it in TIENDA_ITEMS)
    e = discord.Embed(title="🏪 Tienda Von Crastenburg", description=f"💰 Tu saldo: **{puntos} VonCoins**\n\n{desc}", color=COLOR_DORADO)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
    await interaction.response.send_message(embed=e, view=TiendaView(), ephemeral=True)

# ── /stats ────────────────────────────────
@bot.tree.command(name="stats", description="[Staff] 📊 Dashboard de estadísticas del hotel")
async def stats(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(embed=embed_von("❌ Sin permiso","Solo el staff.", COLOR_NEGRO), ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    results = await asyncio.gather(b44.get_all_rooms(limit=60), b44.get_reservations(status="pending", limit=50), return_exceptions=True)
    rooms   = results[0] if isinstance(results[0], list) else []
    pend    = results[1] if isinstance(results[1], list) else []
    libres  = sum(1 for r in rooms if r.get("status") == "available")
    ocup    = sum(1 for r in rooms if r.get("status") == "occupied")
    reserv  = sum(1 for r in rooms if r.get("status") == "reserved")
    limp    = sum(1 for r in rooms if r.get("status") == "cleaning")
    total   = len(rooms)
    pct     = round((ocup+reserv)/total*100) if total else 0
    ahora   = datetime.now()
    inicio_sem = ahora - timedelta(days=ahora.weekday())
    rdb     = cargar_db(RESERVAS_DB)
    fdb     = cargar_db(FICHAS_DB)
    ingresos = 0
    tipo_cnt: dict[str,int] = {}
    for r in rdb.values():
        if r.get("estado") in ("confirmada","checkin","completada"):
            try:
                fd = datetime.strptime(r.get("creada","")[:10], "%d/%m/%Y")
                if fd >= inicio_sem:
                    ingresos += HABITACIONES.get(r.get("tipo","doble"),{}).get("precio",0)
            except Exception:
                pass
            tipo = r.get("tipo","doble")
            tipo_cnt[tipo] = tipo_cnt.get(tipo,0) + 1
    ms      = max(tipo_cnt, key=tipo_cnt.get) if tipo_cnt else "—"
    ms_nom  = HABITACIONES.get(ms,{}).get("nombre", ms)
    hoy     = ahora.strftime("%d/%m/%Y")
    en_turno= sum(1 for f in fdb.values() if f.get("fecha")==hoy and f.get("salida") is None)
    e = discord.Embed(title="📊 Dashboard — Von Crastenburg", color=COLOR_DORADO)
    e.add_field(name="🏠 Ocupación",            value=f"**{pct}%** ({ocup+reserv}/{total})", inline=True)
    e.add_field(name="🟢 Libres",               value=str(libres),                           inline=True)
    e.add_field(name="🔵 En limpieza",          value=str(limp),                             inline=True)
    e.add_field(name="🟠 Solicitudes web",      value=str(len(pend)),                        inline=True)
    e.add_field(name="💰 Ingresos (esta sem.)", value=f"{ingresos} €",                       inline=True)
    e.add_field(name="🏆 Más solicitada",       value=ms_nom,                                inline=True)
    e.add_field(name="👔 En turno ahora",       value=str(en_turno),                         inline=True)
    e.set_footer(text=f"🔄 {ahora.strftime('%d/%m/%Y %H:%M')}  ·  VonStay")
    await interaction.followup.send(embed=e, ephemeral=True)


# ==========================================
# PERIÓDICO DEL HOTEL
# ==========================================

def _claves_periodico(db: dict) -> list[str]:
    """Devuelve las claves ordenadas numéricamente."""
    return sorted(db.keys(), key=lambda k: int(k))

def _build_periodico_embed(edicion: dict, num: int, total: int) -> discord.Embed:
    titulo = edicion.get("titular") or f"Edición #{num}"
    e = discord.Embed(
        title=f"📰 Von Crastenburg Gazette — Edición #{num}",
        description=f"**{titulo}**",
        color=COLOR_DORADO,
    )
    e.set_image(url=edicion["imagen_url"])
    e.add_field(name="✍️ Redactor",  value=edicion.get("autor", "—"), inline=True)
    e.add_field(name="📅 Publicado", value=edicion.get("fecha", "—"), inline=True)
    e.add_field(name="📖 Edición",   value=f"{num} / {total}",        inline=True)
    e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP  ·  /periodico para leer")
    return e

class PeriodicoNavView(discord.ui.View):
    """Botones de navegación ← → para hojear ediciones."""
    def __init__(self, num: int, total: int):
        super().__init__(timeout=180)
        self.num   = num
        self.total = total
        self._sync_botones()

    def _sync_botones(self):
        self.anterior.disabled = (self.num <= 1)
        self.siguiente.disabled = (self.num >= self.total)
        self.ultima_btn.disabled = (self.num >= self.total)

    def _get_edicion(self, n: int) -> tuple[str, dict] | tuple[None, None]:
        db     = cargar_db(PERIODICO_DB)
        claves = _claves_periodico(db)
        if 0 < n <= len(claves):
            c = claves[n - 1]
            return c, db[c]
        return None, None

    @discord.ui.button(label="◀ Anterior", style=discord.ButtonStyle.secondary)
    async def anterior(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.num = max(1, self.num - 1)
        self._sync_botones()
        _, edicion = self._get_edicion(self.num)
        if not edicion:
            await interaction.response.defer(); return
        await interaction.response.edit_message(
            embed=_build_periodico_embed(edicion, self.num, self.total), view=self)

    @discord.ui.button(label="Siguiente ▶", style=discord.ButtonStyle.secondary)
    async def siguiente(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.num = min(self.total, self.num + 1)
        self._sync_botones()
        _, edicion = self._get_edicion(self.num)
        if not edicion:
            await interaction.response.defer(); return
        await interaction.response.edit_message(
            embed=_build_periodico_embed(edicion, self.num, self.total), view=self)

    @discord.ui.button(label="📰 Última", style=discord.ButtonStyle.primary, custom_id="periodico_ultima")
    async def ultima_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.num = self.total
        self._sync_botones()
        _, edicion = self._get_edicion(self.num)
        if not edicion:
            await interaction.response.defer(); return
        await interaction.response.edit_message(
            embed=_build_periodico_embed(edicion, self.num, self.total), view=self)


async def _difundir_periodico_dm(guild: discord.Guild, embed: discord.Embed, canal_id: int | None, num: int):
    """Tarea en segundo plano: envía la edición por MD a todos los miembros
    (no-bot) del servidor, con concurrencia limitada para no saturar la API
    de Discord, y publica un resumen al terminar."""
    try:
        try:
            miembros = [m async for m in guild.fetch_members(limit=None) if not m.bot]
        except discord.HTTPException:
            miembros = [m for m in guild.members if not m.bot]

        semaforo = asyncio.Semaphore(5)
        enviados = fallidos = 0

        async def _enviar(miembro: discord.Member):
            nonlocal enviados, fallidos
            async with semaforo:
                try:
                    await miembro.send(embed=embed)
                    enviados += 1
                except (discord.Forbidden, discord.HTTPException):
                    fallidos += 1
                await asyncio.sleep(0.3)  # respeta límites de rate-limit

        await asyncio.gather(*(_enviar(m) for m in miembros))

        print(f"[Periódico] Edición #{num}: MD enviado a {enviados} miembro(s), {fallidos} fallido(s).")

        canal = bot.get_channel(canal_id) if canal_id else None
        if canal:
            await canal.send(
                embed=embed_von("📩 Difusión por MD completada",
                    f"Edición **#{num}**: enviada a **{enviados}** miembro(s)"
                    + (f", {fallidos} con MD cerrado/no disponible." if fallidos else "."),
                    COLOR_DORADO),
            )
    except Exception as e:
        print(f"[Periódico] Error en difusión por MD de la edición #{num}: {e}")


@bot.tree.command(name="publicar-periodico", description="[Redacción] 📰 Publicar una nueva edición del periódico (imagen)")
@app_commands.describe(
    imagen="Foto/imagen del periódico",
    titular="Titular de la edición (opcional)",
)
async def publicar_periodico(
    interaction: discord.Interaction,
    imagen: discord.Attachment,
    titular: str = "",
):
    # Comprobar rol
    tiene_rol = any(r.id == ID_ROL_PERIODICO for r in getattr(interaction.user, "roles", []))
    if not tiene_rol:
        await interaction.response.send_message(
            embed=embed_von("❌ Sin permiso",
                "Solo los miembros del equipo de redacción pueden publicar una edición si quieres puedes postularte en <#1524002883765538886> GRACIAS.", COLOR_NEGRO),
            ephemeral=True,
        )
        return

    # Validar que sea imagen
    if not imagen.content_type or not imagen.content_type.startswith("image/"):
        await interaction.response.send_message(
            embed=embed_von("❌ Archivo no válido",
                "El archivo adjunto debe ser una imagen (jpg, png, gif, webp…).", COLOR_NEGRO),
            ephemeral=True,
        )
        return

    await interaction.response.defer(ephemeral=True)

    db    = cargar_db(PERIODICO_DB)
    num   = (max(int(k) for k in db.keys()) + 1) if db else 1
    clave = str(num)
    fecha = datetime.now().strftime("%d/%m/%Y")

    db[clave] = {
        "titular":    titular.strip(),
        "imagen_url": imagen.url,
        "autor":      interaction.user.display_name,
        "fecha":      fecha,
    }
    guardar_db(PERIODICO_DB, db)

    total = len(db)
    embed = _build_periodico_embed(db[clave], num, total)

    canal = bot.get_channel(ID_CANAL_PERIODICO)
    if canal:
        await canal.send(embed=embed)

    if interaction.guild:
        bot.loop.create_task(
            _difundir_periodico_dm(interaction.guild, embed, ID_CANAL_PERIODICO, num)
        )

    if canal:
        resumen = (
            f"La **edición #{num}** ha sido publicada en {canal.mention}.\n"
            f"📩 Enviando por MD a todos los miembros en segundo plano…"
        )
        await interaction.followup.send(
            embed=embed_von("✅ Edición publicada", resumen, COLOR_DORADO),
            ephemeral=True,
        )
    else:
        resumen = (
            f"Edición guardada (#{num}) pero no se pudo enviar al canal `{ID_CANAL_PERIODICO}`.\n"
            "Comprueba que el bot tenga acceso a ese canal.\n"
            f"📩 Enviando por MD a todos los miembros en segundo plano…"
        )
        await interaction.followup.send(
            embed=embed_von("⚠️ Canal no encontrado", resumen, COLOR_NEGRO),
            ephemeral=True,
        )


@bot.tree.command(name="periodico", description="📰 Leer el periódico del hotel — Von Crastenburg Gazette")
async def periodico(interaction: discord.Interaction):
    db = cargar_db(PERIODICO_DB)
    if not db:
        await interaction.response.send_message(
            embed=embed_von("📰 Sin ediciones",
                "Aún no se ha publicado ninguna edición.\nUsa `/publicar-periodico` para crear la primera.",
                COLOR_DORADO),
            ephemeral=True,
        )
        return
    claves = _claves_periodico(db)
    total  = len(claves)
    clave  = claves[-1]          # última edición
    num    = total
    embed  = _build_periodico_embed(db[clave], num, total)
    view   = PeriodicoNavView(num=num, total=total)
    await interaction.response.send_message(embed=embed, view=view)


# ==========================================
# INICIAR BOT
# ==========================================

WEBHOOK_URL = f"https://{os.getenv('REPLIT_DEV_DOMAIN', 'localhost')}/webhook/reserva"
print(f"[VonStay] Webhook URL: {WEBHOOK_URL}")

keep_alive(bot)
bot.run(TOKEN)
