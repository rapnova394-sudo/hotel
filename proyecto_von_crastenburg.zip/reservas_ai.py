"""
Agente de Reservas IA — Von Crastenburg Hotel
Motor de IA dedicado EXCLUSIVAMENTE a la gestión de reservas hoteleras.

Características:
- System Prompt especializado en reservas, check-in/out, habitaciones, política del hotel
- Memoria persistente por canal de ticket (reservas_ai_memory.json)
- Contexto dual: historial del bot (reservas_db.json) + historial web (Base44 API)
- Mismo backend Gemini que hotel_ai.py (endpoint OpenAI-compatible)
- Escalado inteligente con [ESCALAR] cuando el caso requiere staff humano
"""

import os
import json
import asyncio
import aiohttp
import tempfile
from datetime import datetime
import libre_ai

# ══════════════════════════════════════════════════════════════════
# BACKEND — Google Gemini (endpoint compatible con OpenAI)
# ══════════════════════════════════════════════════════════════════

_BASE_URL  = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
_API_KEY   = os.environ.get("GEMINI_API_KEY", "")
_MODELO    = "gemini-2.0-flash"

def _headers() -> dict:
    return {"Authorization": f"Bearer {_API_KEY}", "Content-Type": "application/json"}


async def _completion(messages: list[dict], max_tokens: int = 1400, temperature: float = 0.6) -> str:
    """Llama a Gemini y devuelve el texto de la primera choice. Reintenta ante 429."""
    payload = {
        "model": _MODELO,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    ultimo_error = ""
    for intento in range(3):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(_BASE_URL, headers=_headers(), json=payload) as r:
                    if r.status == 200:
                        body = await r.json(content_type=None)
                        content = body["choices"][0]["message"]["content"]
                        return content if isinstance(content, str) else ""
                    if r.status == 429:
                        await asyncio.sleep(2 ** intento)
                        continue
                    texto = await r.text()
                    raise RuntimeError(f"HTTP_{r.status}: {texto[:200]}")
        except RuntimeError:
            raise
        except Exception as ex:
            ultimo_error = str(ex)
            if intento < 2:
                await asyncio.sleep(2 ** intento)
    raise RuntimeError(ultimo_error or "Error desconocido llamando a Gemini")


# ══════════════════════════════════════════════════════════════════
# SYSTEM PROMPT ESPECIALIZADO EN RESERVAS
# ══════════════════════════════════════════════════════════════════

SYSTEM_RESERVAS = """# VON CRASTENBURG — AGENTE DE RESERVAS IA

Eres el **Agente de Reservas IA** del Von Crastenburg Hotel, un asistente especializado EXCLUSIVAMENTE en la gestión de reservas hoteleras.

## TU FUNCIÓN

Gestionas todo lo relacionado con reservas:
- Consultar, modificar y cancelar reservas
- Proceso de check-in y check-out
- Información sobre tipos de habitación, disponibilidad y precios
- Aclarar dudas sobre el sistema de reservas (web VonStay y comandos del bot)
- Incidencias relacionadas con habitaciones (cambios, problemas durante la estancia)
- Historial completo de estancias del huésped

## DATOS DEL HOTEL

- **Tipos de habitación:**
  - 🛏️ **Doble** (Estándar) — Habitación doble cómoda
  - 💎 **Lujo** (Deluxe) — Habitación premium con servicios adicionales
  - 👑 **Suite** (Suite VIP) — Máxima categoría del hotel
- **Moneda:** € (euros). Nunca uses otras monedas.
- **Sistema de reservas:** VonStay — Portal web: https://von-stay-luxe-revo-rp.base44.app
- **Comandos del bot Discord:**
  - `/reservar [tipo] [fecha]` — Nueva reserva
  - `/checkin [código]` — Hacer check-in al llegar
  - `/checkout [código]` — Hacer check-out al irse
  - `/cancelar [código]` — Cancelar una reserva
  - `/verreservas` — Ver todas las reservas activas
  - `/disponibilidad` — Ver habitaciones disponibles

## PROCESO DE RESERVA

1. El huésped usa `/reservar` en Discord o reserva en la web VonStay
2. Recibe un **código de reserva** único (formato `RES-XXXX`)
3. Al llegar, hace check-in con `/checkin RES-XXXX`
4. Durante la estancia puede solicitar servicios adicionales
5. Al irse, hace check-out con `/checkout RES-XXXX`

## ESTADOS DE UNA RESERVA

- **pendiente** → Reserva creada, esperando confirmación del staff
- **confirmada** → Reserva aprobada, lista para check-in
- **activa** → El huésped está en el hotel (check-in realizado)
- **finalizada** → Estancia completada (check-out realizado)
- **cancelada** → Reserva anulada

## REGLAS DE OPERACIÓN

1. **Responde siempre en español.**
2. **Usa formato Markdown de Discord:** **negritas**, `código en bloque`, listas con -, separadores —
3. **Sé directo y resolutivo.** El huésped quiere soluciones, no explicaciones largas.
4. **Una sola pregunta a la vez** si necesitas más datos. Nunca bombardees al usuario.
5. **Consulta el historial del huésped** (inyectado en el contexto) antes de responder para dar respuestas personalizadas.
6. **Los códigos de reserva** siempre en `código de bloque`.
7. Si el problema requiere intervención humana del staff (disputas de pago, incidencias graves, apelaciones), añade EXACTAMENTE la etiqueta `[ESCALAR]` al final de tu respuesta y resume brevemente qué necesita el staff.
8. **No inventes información.** Si no tienes datos suficientes, pregunta UNA COSA concreta.
9. Tus respuestas son concisas pero completas. Estructura: situación → acción → resultado → próximo paso.

## METACOGNICIÓN

Antes de responder, verifica:
- ¿Tengo el código de reserva del huésped? (si es necesario para la consulta)
- ¿El estado de la reserva es compatible con lo que pide? (ej: no se puede hacer check-in de una reserva cancelada)
- ¿La consulta está dentro de mi área (reservas) o necesita escalarse?
"""

# ══════════════════════════════════════════════════════════════════
# MEMORIA PERSISTENTE (por canal de ticket)
# ══════════════════════════════════════════════════════════════════

AI_MEMORY_FILE   = "reservas_ai_memory.json"
MAX_HISTORIAL    = 100     # Mensajes máximos guardados por conversación en disco
MAX_HISTORIAL_CTX = 20    # Mensajes máximos enviados al modelo en cada llamada

_conversaciones: dict[str, list[dict]] = {}
_lock_memoria = asyncio.Lock()
_guardado_pendiente: asyncio.Task | None = None
_memoria_sucia = False


def _cargar_memoria() -> dict:
    if not os.path.exists(AI_MEMORY_FILE):
        return {}
    try:
        with open(AI_MEMORY_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _guardar_memoria_sync(data: dict):
    """Escritura atómica: temp-file + os.replace para evitar corrupción."""
    try:
        directorio = os.path.dirname(os.path.abspath(AI_MEMORY_FILE)) or "."
        fd, tmp = tempfile.mkstemp(dir=directorio, prefix=".reservas_ai_", suffix=".tmp")
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(tmp, AI_MEMORY_FILE)
        finally:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    except Exception as e:
        print(f"[Reservas IA] Error guardando memoria: {e}")


async def _persistir():
    global _guardado_pendiente, _memoria_sucia
    _memoria_sucia = True
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        _guardar_memoria_sync(dict(_conversaciones))
        return
    if _guardado_pendiente is None or _guardado_pendiente.done():
        _guardado_pendiente = loop.create_task(_guardar_en_hilo())


async def _guardar_en_hilo():
    global _memoria_sucia, _guardado_pendiente
    while True:
        async with _lock_memoria:
            _memoria_sucia = False
            datos = dict(_conversaciones)
        try:
            await asyncio.to_thread(_guardar_memoria_sync, datos)
        except Exception as e:
            print(f"[Reservas IA] Error inesperado guardando: {e}")
        if not _memoria_sucia:
            _guardado_pendiente = None
            return


def _init_memoria():
    """Carga la memoria desde disco al arrancar el módulo."""
    global _conversaciones
    _conversaciones = _cargar_memoria()


_init_memoria()


def get_historial(user_id: str, scope: str = "reserva") -> list:
    """Devuelve el historial de conversación de un usuario en un scope dado."""
    return list(_conversaciones.get(f"{scope}:{user_id}", []))


def limpiar_historial(user_id: str, scope: str | None = None):
    """Limpia el historial de un usuario (scope específico o todos)."""
    if scope:
        _conversaciones.pop(f"{scope}:{user_id}", None)
    else:
        for k in [kk for kk in list(_conversaciones) if kk.endswith(f":{user_id}")]:
            _conversaciones.pop(k, None)


# ══════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL DE CONSULTA
# ══════════════════════════════════════════════════════════════════

async def consultar_reservas_ia(
    user_id: str,
    display_name: str,
    mensaje: str,
    contexto_reservas: str = "",
    permitir_escalar: bool = True,
    scope: str = "reserva",
) -> str:
    """
    Consulta al Agente de Reservas IA con memoria persistente por scope
    (generalmente el ID del canal de ticket).

    Retorna la respuesta del agente como texto.
    Si el agente determina que el caso necesita staff humano, incluye [ESCALAR] al final.
    """
    uid = f"{scope}:{user_id}"

    async with _lock_memoria:
        if uid not in _conversaciones:
            _conversaciones[uid] = []
        historial = _conversaciones[uid]

    # Construir mensaje de usuario con contexto inyectado
    contenido_usuario = f"[Huésped: {display_name} | ID Discord: {user_id}]"
    if contexto_reservas:
        contenido_usuario += f"\n\n[CONTEXTO DEL SISTEMA — Datos actuales del huésped]\n{contexto_reservas}"
    if permitir_escalar:
        contenido_usuario += (
            "\n\n[INSTRUCCIÓN OPERATIVA] Si el caso requiere intervención humana del staff "
            "(disputas de pago, incidencias graves, apelaciones, errores de sistema), "
            "añade EXACTAMENTE la etiqueta [ESCALAR] al final de tu respuesta."
        )
    contenido_usuario += f"\n\n{mensaje}"

    async with _lock_memoria:
        historial.append({"role": "user", "content": contenido_usuario})

    try:
        contexto_envio = historial[-MAX_HISTORIAL_CTX:]
        messages = [{"role": "system", "content": SYSTEM_RESERVAS}, *contexto_envio]

        respuesta = await _completion(messages=messages, max_tokens=1400, temperature=0.6)

        if not respuesta:
            respuesta = "No pude generar una respuesta. ¿Puedes reformular tu consulta?"

        async with _lock_memoria:
            historial.append({"role": "assistant", "content": respuesta})
            if len(historial) > MAX_HISTORIAL:
                _conversaciones[uid] = historial[-MAX_HISTORIAL:]

        await _persistir()
        return respuesta

    except Exception as e:
        err = str(e)
        print(f"[Reservas IA] Error: {err} — usando libre_ai como respaldo en paralelo")

        # ── Respaldo local (libre_ai) ────────────────────────────────
        # El turno del usuario se conserva; solo se retira si el respaldo
        # local también falla.
        try:
            respuesta_local = libre_ai.consultar_reservas(
                mensaje       = mensaje,
                scope         = uid,
                reservas_bot  = None,
                reservas_web  = None,
            )
            async with _lock_memoria:
                historial.append({"role": "assistant", "content": respuesta_local})
                if len(historial) > MAX_HISTORIAL:
                    _conversaciones[uid] = historial[-MAX_HISTORIAL:]
            await _persistir()
            return respuesta_local
        except Exception as e_local:
            print(f"[Reservas IA] Error también en libre_ai: {e_local}")

        # Retirar el mensaje del usuario del historial si ambos motores fallaron
        async with _lock_memoria:
            if historial and historial[-1]["role"] == "user":
                historial.pop()

        return (
            "🏨 Un momento, por favor. Estoy teniendo dificultades para procesar tu consulta de reservas ahora mismo. "
            "Si necesitas ayuda inmediata, un miembro del staff puede atenderte."
        )


# ══════════════════════════════════════════════════════════════════
# CONSTRUCCIÓN DE CONTEXTO DE RESERVAS
# ══════════════════════════════════════════════════════════════════

# Mapa de emojis por estado de reserva
_ESTADO_EMOJI = {
    "confirmada": "✅",
    "pendiente":  "⏳",
    "activa":     "🔑",
    "cancelada":  "❌",
    "finalizada": "🏁",
}

# Mapa de emojis por tipo de habitación
_TIPO_EMOJI = {
    "doble":    "🛏️",
    "lujo":     "💎",
    "suite":    "👑",
    "standard": "🛏️",
    "deluxe":   "💎",
    "vip_suite":"👑",
}


def construir_contexto_reservas(
    perfil: dict | None,
    reservas_bot: list,
    reservas_web: list,
) -> str:
    """
    Construye el bloque de contexto de reservas que se inyecta al sistema de IA.
    Combina datos del bot (reservas_db.json) y del portal web (Base44).
    """
    lineas: list[str] = [f"Fecha y hora actual: {datetime.now().strftime('%d/%m/%Y %H:%M')}"]

    if perfil:
        lineas.append(
            f"Perfil del huésped: rango={perfil.get('rango', 'Visitante')}, "
            f"saldo={perfil.get('monedero', 0)}€, "
            f"check-in activo={perfil.get('checkin_activo', False)}, "
            f"habitación asignada={perfil.get('habitacion', 'ninguna')}"
        )

    # ── Reservas del bot ──────────────────────────────────────────
    if reservas_bot:
        lineas.append(f"\n═══ RESERVAS BOT DISCORD ({len(reservas_bot)} encontrada/s) ═══")
        for r in reservas_bot[:8]:
            emoji_e = _ESTADO_EMOJI.get(r.get("estado", ""), "•")
            emoji_t = _TIPO_EMOJI.get(r.get("tipo", "").lower(), "🛏️")
            lineas.append(
                f"{emoji_e} Código: {r.get('codigo', '?')} | "
                f"{emoji_t} {r.get('tipo', '?').capitalize()} | "
                f"Entrada: {r.get('fecha', '?')} | "
                f"Salida: {r.get('fecha_salida', '?')} | "
                f"Estado: {r.get('estado', '?')}"
            )
    else:
        lineas.append("\n═══ RESERVAS BOT: Sin reservas registradas en el bot ═══")

    # ── Reservas web (Base44) ─────────────────────────────────────
    if reservas_web:
        lineas.append(f"\n═══ RESERVAS WEB VonStay ({len(reservas_web)} encontrada/s) ═══")
        for r in reservas_web[:8]:
            estado  = r.get("status", r.get("estado", "?"))
            tipo    = r.get("room_type", r.get("tipo", "?"))
            entrada = r.get("check_in_date", r.get("fecha_entrada", r.get("fecha", "?")))
            salida  = r.get("check_out_date", r.get("fecha_salida", "?"))
            rid     = str(r.get("id", r.get("codigo", "?")))
            rid_short = rid[:12] + "..." if len(rid) > 12 else rid
            emoji_e = _ESTADO_EMOJI.get(estado, "•")
            emoji_t = _TIPO_EMOJI.get(str(tipo).lower(), "🛏️")
            lineas.append(
                f"{emoji_e} ID: {rid_short} | {emoji_t} {tipo} | "
                f"Entrada: {entrada} | Salida: {salida} | Estado: {estado}"
            )
    else:
        lineas.append("\n═══ RESERVAS WEB: Sin reservas en el portal VonStay ═══")

    return "\n".join(lineas)
