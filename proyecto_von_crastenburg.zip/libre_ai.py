"""
libre_ai.py — Motor de IA Local para Von Crastenburg Hotel
═══════════════════════════════════════════════════════════
Sin dependencias externas · Sin API keys · Sin cuotas · Respuesta instantánea

Implementa la misma interfaz que hotel_ai.py y reservas_ai.py para que
main.py pueda usarlo como backend sin cambios estructurales.
"""

from __future__ import annotations
import re
import random
from datetime import datetime
from typing import Any

# ══════════════════════════════════════════════════════════════════
# MODERACIÓN — Detección de infracciones
# ══════════════════════════════════════════════════════════════════

_PALABRAS_NIVEL_3: list[str] = [
    # contenido sexual/violento grave / doxxing
    "porno", "porn", "nsfw", "sexo explícito", "sex explicit",
    "matar", "asesin", "suicid", "bomba", "terroris", "nazis", "nazi",
    "violaci", "pedofil", "gore",
]

_PALABRAS_NIVEL_2: list[str] = [
    # insultos / odio / toxicidad
    "idiota", "imbécil", "imbecil", "estúpido", "estupido", "inútil", "inutil",
    "mierda", "puta", "puto", "joder", "hostia", "gilipollas", "capullo",
    "maricón", "maricon", "retrasado", "mongolo", "bastardo",
    "racista", "racismo", "homofob", "transfob",
    "te voy a", "voy a hacerte", "os voy a", "os haré",
]

_PALABRAS_NIVEL_1: list[str] = [
    "tonto", "bobo", "bruto", "me cago", "asco",
]

_RE_FLAGS = re.IGNORECASE | re.UNICODE


def _normalizar(texto: str) -> str:
    t = texto.lower()
    for a, b in [("á","a"),("é","e"),("í","i"),("ó","o"),("ú","u"),("ü","u"),("ñ","n")]:
        t = t.replace(a, b)
    return t


def _contiene(texto: str, palabras: list[str]) -> str | None:
    n = _normalizar(texto)
    for p in palabras:
        pn = _normalizar(p)
        if re.search(r'\b' + re.escape(pn) + r'\b', n):
            return p
    return None


def analizar_moderacion(texto: str) -> dict:
    """
    Analiza el texto y devuelve un dict compatible con hotel_ai.analizar_moderacion().
    Retorna: {es_infraccion, nivel_accion, razon, respuesta}
    """
    if hit := _contiene(texto, _PALABRAS_NIVEL_3):
        return {
            "es_infraccion": True,
            "nivel_accion": 3,
            "razon": f"Contenido gravemente inapropiado detectado: «{hit}»",
            "respuesta": (
                "⚠️ Tu mensaje ha sido eliminado por contener contenido inapropiado grave. "
                "El staff ha sido notificado. Comportamientos de este tipo pueden resultar en sanción."
            ),
        }
    if hit := _contiene(texto, _PALABRAS_NIVEL_2):
        return {
            "es_infraccion": True,
            "nivel_accion": 2,
            "razon": f"Lenguaje inapropiado: «{hit}»",
            "respuesta": random.choice([
                f"⚠️ Por favor mantén un tono respetuoso en el hotel. El uso de «{hit}» no está permitido.",
                f"⚠️ Este es un espacio de rol hotelero. El lenguaje ofensivo como «{hit}» está prohibido.",
                "⚠️ Recuerda las normas del Von Crastenburg: respeto ante todo.",
            ]),
        }
    if hit := _contiene(texto, _PALABRAS_NIVEL_1):
        return {
            "es_infraccion": True,
            "nivel_accion": 1,
            "razon": f"Lenguaje poco apropiado: «{hit}»",
            "respuesta": "💬 Por favor, mantén un tono amable y respetuoso. ¡Gracias!",
        }
    return {"es_infraccion": False, "nivel_accion": 0, "razon": "", "respuesta": ""}


# ══════════════════════════════════════════════════════════════════
# DETECCIÓN DE INTENCIÓN
# ══════════════════════════════════════════════════════════════════

# Cada entry: (score_mínimo, lista de términos)
_INTENTS: dict[str, tuple[int, list[str]]] = {
    "saludo":            (1, ["hola","buenas","buenos días","buenas tardes","buenas noches","hey","hi","saludos","buen dia"]),
    "despedida":         (1, ["adiós","adios","hasta luego","bye","chao","nos vemos","hasta pronto","gracias y adiós"]),
    "reserva_ver":       (2, ["ver reserva","mis reservas","ver mis reservas","consultar reserva","estado reserva","tengo reserva","reservas activas","verreservas"]),
    "reserva_crear":     (2, ["hacer reserva","nueva reserva","quiero reservar","reservar habitacion","reservar habitación","como reservo","como hago una reserva"]),
    "reserva_cancelar":  (2, ["cancelar reserva","cancelar mi reserva","cancelacion","cancelación","quiero cancelar","anular reserva"]),
    "checkin":           (2, ["check-in","checkin","hacer checkin","quiero hacer check","llegué","llegue","he llegado","acceder a mi habitacion"]),
    "checkout":          (2, ["check-out","checkout","hacer checkout","quiero salir","me voy","estancia terminada","irse"]),
    "habitacion_info":   (1, ["habitacion","habitación","suite","doble","lujo","tipos de habitacion","que habitaciones","habitaciones disponibles","disponibilidad","precio habitacion","cuanto cuesta"]),
    "saldo":             (1, ["saldo","monedero","dinero","credito","crédito","cuanto tengo","mis monedas","mi saldo"]),
    "normas":            (1, ["normas","reglas","reglas del hotel","normas del hotel","que se puede","que no se puede","politica","política"]),
    "servicios":         (1, ["restaurante","piscina","spa","gimnasio","servicio","habitacion servicio","room service","desayuno","eventos","sala"]),
    "staff":             (1, ["hablar con staff","necesito staff","quiero hablar con una persona","staff humano","manager","gerente","recepcionista"]),
    "problema":          (1, ["problema","queja","incidencia","reclamacion","reclamación","no funciona","esta roto","roto","fallo","error","mal"]),
    "agradecimiento":    (1, ["gracias","thank","perfecto","genial","entendido","ok gracias","muchas gracias"]),
}

def _detectar_intencion(texto: str) -> str:
    n = _normalizar(texto)
    scores: dict[str, int] = {}
    for intent, (minimo, terms) in _INTENTS.items():
        hits = sum(1 for t in terms if t in n)
        if hits >= minimo:
            scores[intent] = hits
    if not scores:
        return "desconocido"
    return max(scores, key=lambda k: scores[k])


def detectar_duda(texto: str) -> bool:
    """Devuelve True si el mensaje parece una duda/consulta que merece abrir ticket."""
    n = _normalizar(texto)
    dudas = [
        "como","cómo","cuando","cuándo","donde","dónde","por que","por qué",
        "qué es","que es","ayuda","help","duda","consulta","pregunta",
        "no sé","no se","no entiendo","no puedo","problema","me explicas",
        "podeis","podéis","podeis","podriais","podríais",
        "tengo una","quería preguntar","quisiera saber",
    ]
    return any(d in n for d in dudas)


def analizar_emocion(texto: str) -> str:
    """Detecta estado emocional básico del mensaje."""
    n = _normalizar(texto)
    if any(w in n for w in ["urgente","urgente","ahora mismo","ya","rapido","rápido","necesito ya","por favor ya"]):
        return "urgente"
    if any(w in n for w in ["enfadado","enfada","furioso","harto","harto","inaceptable","escandaloso","verguenza"]):
        return "enojado"
    if any(w in n for w in ["frustrado","frustrada","desesperado","no puedo mas","no puedo más","rendirse"]):
        return "frustrado"
    if any(w in n for w in ["no entiendo","confuso","confusa","no comprendo","no sé qué","qué significa","me explicas"]):
        return "confuso"
    return "neutro"


# ══════════════════════════════════════════════════════════════════
# BANCO DE RESPUESTAS
# ══════════════════════════════════════════════════════════════════

_HOY = lambda: datetime.now().strftime("%d/%m/%Y")

_RESPUESTAS: dict[str, list[str]] = {
    "saludo": [
        "¡Bienvenido al **Von Crastenburg Hotel** 🏨! Soy el Asistente IA del hotel. ¿En qué puedo ayudarte hoy?",
        "¡Buenas! 🌟 Estás contactando con el servicio de atención del **Von Crastenburg Hotel**. ¿Cómo puedo asistirte?",
        "¡Hola! 👋 Soy el Asistente Virtual del **Von Crastenburg**. ¿Qué necesitas?",
        "¡Bienvenido/a! Estoy aquí para ayudarte con todo lo relacionado con tu estancia en el **Von Crastenburg Hotel** 🏨. ¿En qué te ayudo?",
    ],
    "despedida": [
        "¡Hasta luego! Ha sido un placer atenderte en el **Von Crastenburg Hotel** 🏨 ¡Vuelve pronto!",
        "¡Que tengas un excelente día! En el **Von Crastenburg** siempre estaremos encantados de recibirte. ✨",
        "¡Adiós! Esperamos que tu experiencia en el hotel haya sido excepcional. 🌟",
    ],
    "agradecimiento": [
        "¡De nada! Es un placer ayudarte. 😊 ¿Hay algo más en lo que pueda asistirte?",
        "¡Con mucho gusto! En el **Von Crastenburg** tu satisfacción es nuestra prioridad. ¿Algo más?",
        "¡Para eso estamos! 🌟 Si necesitas cualquier otra cosa, no dudes en preguntar.",
    ],
    "reserva_ver": [
        "Para ver tus reservas activas usa el comando `/verreservas` en el servidor. Te mostrará todos tus códigos de reserva con su estado actual.",
        "Puedes consultar tus reservas con `/verreservas`. También puedes ver el detalle de una reserva específica indicando su código.",
        "Tus reservas están disponibles con el comando `/verreservas` 📋. Si tienes algún problema para encontrarlas, dime tu código y te ayudo.",
    ],
    "reserva_crear": [
        (
            "Para hacer una nueva reserva tienes dos opciones:\n"
            "**• Bot Discord:** `/reservar [tipo] [fecha]`\n"
            "**• Portal web:** [VonStay](https://von-stay-luxe-revo-rp.base44.app)\n\n"
            "**Tipos de habitación disponibles:**\n"
            "🛏️ `doble` — Habitación estándar\n"
            "💎 `lujo` — Habitación premium\n"
            "👑 `suite` — Suite VIP\n\n"
            "¿Qué tipo de habitación prefieres?"
        ),
    ],
    "reserva_cancelar": [
        "Para cancelar una reserva usa el comando `/cancelar [código]`, sustituyendo `[código]` por tu código de reserva (formato `RES-XXXX`).\n\nSi no recuerdas tu código, usa primero `/verreservas`.",
        "La cancelación se hace con `/cancelar RES-XXXX`. Ten en cuenta la política del hotel: las cancelaciones con menos de 24h de antelación pueden tener cargos. ¿Cuál es el código de tu reserva?",
    ],
    "checkin": [
        "Para hacer el check-in usa el comando `/checkin [código]` con tu código de reserva.\n\n⚠️ Asegúrate de que tu reserva está en estado **confirmada** antes de hacer el check-in. Si está **pendiente**, espera la confirmación del staff.",
        "El check-in se realiza con `/checkin RES-XXXX` 🔑. Una vez hecho, se te asignará tu habitación y quedará registrada tu entrada. ¿Tienes ya tu código de reserva?",
    ],
    "checkout": [
        "Para hacer el check-out usa el comando `/checkout [código]` con tu código de reserva.\n\nTras el checkout tu estancia quedará finalizada y la habitación liberada. ✅",
        "El check-out se hace con `/checkout RES-XXXX` 🏁. ¿Tienes alguna consulta sobre tu estancia antes de cerrarla?",
    ],
    "habitacion_info": [
        (
            "**Tipos de habitación en Von Crastenburg:**\n\n"
            "🛏️ **Doble (Estándar)** — Habitación cómoda para estancias regulares\n"
            "💎 **Lujo (Deluxe)** — Premium con servicios adicionales y vistas\n"
            "👑 **Suite (VIP)** — Máxima categoría, experiencia exclusiva\n\n"
            "Para ver disponibilidad usa `/disponibilidad`. Para reservar, `/reservar [tipo] [fecha]`."
        ),
    ],
    "saldo": [
        "Para consultar tu saldo usa el comando `/saldo` o `/perfil` 💰. Tu monedero acumula puntos canjeables por servicios del hotel. ¿Necesitas algo más?",
        "Tu saldo actual está disponible en tu perfil con `/perfil` 💳. ¿Tienes alguna pregunta sobre cómo usar el monedero?",
    ],
    "normas": [
        (
            "**Normas principales del Von Crastenburg Hotel:**\n\n"
            "• Respeto absoluto entre todos los usuarios\n"
            "• Roleplay realista acorde al entorno hotelero\n"
            "• Prohibido el contenido NSFW o violento\n"
            "• Las disputas se resuelven con el staff\n"
            "• Respetar las decisiones del personal del hotel\n\n"
            "Para ver las normas completas del servidor, revisa el canal de normas 📜"
        ),
    ],
    "servicios": [
        (
            "**Servicios del Von Crastenburg Hotel:**\n\n"
            "🍽️ Restaurante de alta cocina\n"
            "🏊 Piscina y área de relax\n"
            "💆 Spa y centro de bienestar\n"
            "🏋️ Gimnasio equipado\n"
            "🛎️ Room service 24h\n"
            "🎪 Salón de eventos\n\n"
            "¿Deseas información detallada sobre algún servicio en particular?"
        ),
    ],
    "staff": [
        "Entendido, voy a avisar al staff para que te atiendan personalmente. 👤 Un momento, por favor.",
        "De acuerdo, escalando tu caso al staff del hotel. 🏨 Un miembro del equipo te atenderá en breve.",
        "Solicitud de staff registrada. 📋 El equipo del **Von Crastenburg** estará contigo en un momento. Gracias por tu paciencia.",
    ],
    "problema": [
        "Entiendo que tienes un problema. Cuéntame los detalles y lo gestionaremos lo antes posible. 🔧",
        "Lamento que estés teniendo dificultades. Por favor, describe el problema con el mayor detalle posible y lo resolveremos. 🛠️",
        "Veo que hay una incidencia. Para resolverla de la mejor manera, necesito saber: ¿cuál es exactamente el problema y cuándo ocurrió?",
    ],
    "desconocido": [
        "No estoy seguro de entender exactamente tu consulta. ¿Podrías reformularla? Estoy aquí para ayudarte con **reservas, check-in/out, información del hotel** y más. 😊",
        "Mmm, no tengo una respuesta específica para eso. ¿Puedes contarme más detalles? También puedes solicitar la atención del **staff** si lo prefieres. 🏨",
        "Para consultas complejas, nuestro staff puede ayudarte mejor. ¿Deseas que avise a un miembro del equipo? 👤",
    ],
}

# Prefijos por emoción detectada
_PREFIJOS_EMOCION = {
    "urgente":   ["Entiendo la urgencia. ", "Atendemos tu caso de inmediato. "],
    "enojado":   ["Lamento los inconvenientes causados. ", "Entiendo tu frustración y lo tomamos en serio. "],
    "frustrado": ["Siento que estés pasando por esto. ", "Entendemos la situación y queremos ayudarte. "],
    "confuso":   ["Te lo explico con detalle. ", "No hay problema, lo aclaramos juntos. "],
    "neutro":    ["", ""],
}


# ══════════════════════════════════════════════════════════════════
# HISTORIAL DE CONVERSACIÓN (simple, en memoria)
# ══════════════════════════════════════════════════════════════════

_historiales: dict[str, list[dict]] = {}


def agregar_historial(scope: str, rol: str, contenido: str):
    if scope not in _historiales:
        _historiales[scope] = []
    _historiales[scope].append({"role": rol, "content": contenido})
    if len(_historiales[scope]) > 40:
        _historiales[scope] = _historiales[scope][-40:]


def get_historial(scope: str) -> list[dict]:
    return list(_historiales.get(scope, []))


def limpiar_historial(scope: str):
    _historiales.pop(scope, None)


# ══════════════════════════════════════════════════════════════════
# RESPUESTA DE TICKET (soporte general)
# ══════════════════════════════════════════════════════════════════

def responder_ticket(
    mensaje: str,
    scope: str = "ticket",
    user_data: dict | None = None,
    reservas: list | None = None,
) -> str:
    """Genera respuesta para un ticket de soporte general."""
    emocion  = analizar_emocion(mensaje)
    intencion = _detectar_intencion(mensaje)
    prefijo  = random.choice(_PREFIJOS_EMOCION.get(emocion, ["", ""]))

    # Detectar si pide staff explícitamente
    if intencion == "staff":
        agregar_historial(scope, "user", mensaje)
        agregar_historial(scope, "assistant", "[ESCALAR] Se ha solicitado staff.")
        return "[ESCALAR] El huésped solicita atención del staff directamente."

    # Respuesta base
    plantillas = _RESPUESTAS.get(intencion, _RESPUESTAS["desconocido"])
    respuesta  = prefijo + random.choice(plantillas)

    # Enriquecimiento con datos reales del usuario
    if user_data and intencion == "saldo":
        saldo = user_data.get("monedero", 0)
        respuesta = f"💰 Tu saldo actual es **{saldo}€**. " + random.choice([
            "¿Deseas canjear algún servicio?",
            "¿Necesitas algo más?",
        ])

    if reservas and intencion in ("reserva_ver", "checkin", "checkout", "reserva_cancelar"):
        if reservas:
            estado_emojis = {"confirmada":"✅","pendiente":"⏳","activa":"🔑","cancelada":"❌","finalizada":"🏁"}
            tipo_emojis   = {"doble":"🛏️","lujo":"💎","suite":"👑"}
            lista = "\n".join(
                f"{estado_emojis.get(r.get('estado',''),'•')} `{r.get('codigo','?')}` — "
                f"{tipo_emojis.get(r.get('tipo','').lower(),'🛏️')} {r.get('tipo','?').capitalize()} | "
                f"{r.get('fecha','?')} → {r.get('fecha_salida','?')} | *{r.get('estado','?')}*"
                for r in reservas[:5]
            )
            respuesta = f"📋 **Tus reservas actuales:**\n{lista}\n\n¿Qué deseas hacer con alguna de ellas?"

    agregar_historial(scope, "user", mensaje)
    agregar_historial(scope, "assistant", respuesta)
    return respuesta


# ══════════════════════════════════════════════════════════════════
# RESPUESTA GENERAL (chat libre fuera de tickets)
# ══════════════════════════════════════════════════════════════════

def responder_general(mensaje: str, scope: str = "general") -> str:
    """Genera respuesta en canales generales del servidor."""
    intencion = _detectar_intencion(mensaje)
    emocion   = analizar_emocion(mensaje)
    prefijo   = random.choice(_PREFIJOS_EMOCION.get(emocion, ["",""]))

    plantillas = _RESPUESTAS.get(intencion, _RESPUESTAS["desconocido"])
    respuesta  = prefijo + random.choice(plantillas)

    agregar_historial(scope, "user", mensaje)
    agregar_historial(scope, "assistant", respuesta)
    return respuesta


# ══════════════════════════════════════════════════════════════════
# RESERVAS — consulta con contexto
# ══════════════════════════════════════════════════════════════════

_RESPUESTAS_RESERVA: dict[str, list[str]] = {
    "reserva_ver": [
        "📋 Aquí tienes un resumen de tus reservas. ¿Qué deseas hacer con alguna de ellas?",
        "Estas son tus reservas registradas. ¿Necesitas modificar o consultar alguna en concreto?",
    ],
    "reserva_crear": [
        "Para crear una nueva reserva, usa `/reservar [tipo] [fecha]` en el servidor, o accede al [portal VonStay](https://von-stay-luxe-revo-rp.base44.app). ¿Qué tipo de habitación te interesa?",
    ],
    "reserva_cancelar": [
        "Para cancelar tu reserva, usa `/cancelar [código]`. ¿Qué código de reserva deseas cancelar?",
        "La cancelación se hace con `/cancelar RES-XXXX`. ¿Cuál es el código de la reserva que quieres anular?",
    ],
    "checkin": [
        "Para hacer el check-in usa `/checkin [código]`. Tu reserva debe estar en estado **confirmada**. ¿Cuál es tu código de reserva?",
    ],
    "checkout": [
        "Para hacer el check-out usa `/checkout [código]`. Esto cerrará tu estancia. ¿Necesitas algo más antes de proceder?",
    ],
    "problema": [
        "Entiendo que tienes una incidencia con tu reserva. Por favor, descríbemela con detalle y valoraré si puedo resolverla o si necesito escalarla al staff. 🔧",
        "Voy a registrar tu incidencia. ¿Puedes darme el código de reserva afectado y describir el problema? [ESCALAR]",
    ],
    "staff": [
        "Entendido, voy a avisar al staff para que gestionen tu caso personalmente. [ESCALAR]",
    ],
}


def consultar_reservas(
    mensaje: str,
    scope: str = "reserva",
    perfil: dict | None = None,
    reservas_bot: list | None = None,
    reservas_web: list | None = None,
) -> str:
    """Responde a consultas en tickets de reservas con contexto completo."""
    intencion = _detectar_intencion(mensaje)
    emocion   = analizar_emocion(mensaje)
    prefijo   = random.choice(_PREFIJOS_EMOCION.get(emocion, ["",""]))

    plantillas = _RESPUESTAS_RESERVA.get(
        intencion,
        _RESPUESTAS.get(intencion, _RESPUESTAS["desconocido"])
    )
    respuesta = prefijo + random.choice(plantillas)

    # Enriquecer con datos reales si las tenemos
    todas_reservas = (reservas_bot or []) + (reservas_web or [])
    if todas_reservas and intencion in ("reserva_ver", "checkin", "checkout", "reserva_cancelar"):
        estado_e = {"confirmada":"✅","pendiente":"⏳","activa":"🔑","cancelada":"❌","finalizada":"🏁"}
        tipo_e   = {"doble":"🛏️","lujo":"💎","suite":"👑","standard":"🛏️","deluxe":"💎","vip_suite":"👑"}
        lineas = []
        for r in todas_reservas[:6]:
            est  = r.get("status", r.get("estado","?"))
            tipo = r.get("room_type", r.get("tipo","?"))
            cod  = str(r.get("codigo", r.get("id","?")))[:12]
            entr = r.get("check_in_date", r.get("fecha","?"))
            sal  = r.get("check_out_date", r.get("fecha_salida","?"))
            lineas.append(
                f"{estado_e.get(est,'•')} `{cod}` — {tipo_e.get(str(tipo).lower(),'🛏️')} "
                f"**{str(tipo).capitalize()}** | {entr} → {sal} | *{est}*"
            )
        respuesta = prefijo + "📋 **Tus reservas:**\n" + "\n".join(lineas) + "\n\n¿Qué deseas hacer?"

    if perfil and intencion == "saldo":
        respuesta = f"💰 Tu saldo actual es **{perfil.get('monedero',0)}€**. ¿En qué más puedo ayudarte?"

    agregar_historial(scope, "user", mensaje)
    agregar_historial(scope, "assistant", respuesta)
    return respuesta


# ══════════════════════════════════════════════════════════════════
# RESUMEN DE TICKET (para escalado)
# ══════════════════════════════════════════════════════════════════

def generar_resumen_ticket(historial: list[dict]) -> str:
    """Genera un resumen conciso del ticket para el staff."""
    if not historial:
        return "• Sin mensajes registrados en el historial."

    msgs_usuario = [m["content"] for m in historial if m.get("role") == "user"]
    if not msgs_usuario:
        return "• El huésped no ha enviado mensajes aún."

    resumen = []
    if len(msgs_usuario) >= 1:
        resumen.append(f"• **Consulta inicial:** {msgs_usuario[0][:120]}")
    if len(msgs_usuario) >= 3:
        ultimo = msgs_usuario[-1]
        resumen.append(f"• **Último mensaje:** {ultimo[:120]}")
    resumen.append(f"• **Total de mensajes del huésped:** {len(msgs_usuario)}")

    # Detectar intención predominante
    conteos: dict[str,int] = {}
    for m in msgs_usuario:
        intent = _detectar_intencion(m)
        conteos[intent] = conteos.get(intent, 0) + 1
    if conteos:
        principal = max(conteos, key=lambda k: conteos[k])
        resumen.append(f"• **Tema principal detectado:** {principal.replace('_',' ').capitalize()}")

    return "\n".join(resumen)


# ══════════════════════════════════════════════════════════════════
# DETECCIÓN DE ESCALADA GRUPAL
# ══════════════════════════════════════════════════════════════════

_ESCALADA_PALABRAS = [
    "todos contra","están atacando","se están peleando","parad","para ya",
    "hay una pelea","acoso","me están acosando","nos están","basta ya",
    "esto es una locura","que alguien haga algo","necesito ayuda ya",
]

def detectar_escalada_grupal(mensajes: list[str]) -> dict:
    """Detecta si hay tensión grupal en los últimos mensajes."""
    if len(mensajes) < 3:
        return {"escalar": False, "mensaje": ""}

    texto_conjunto = " ".join(mensajes[-6:]).lower()
    if any(p in texto_conjunto for p in _ESCALADA_PALABRAS):
        return {
            "escalar": True,
            "mensaje": random.choice([
                "🕊️ Vamos a tomárnoslo con calma. El Von Crastenburg es un espacio de respeto mutuo. ¿Qué ha ocurrido?",
                "🏨 Un momento, por favor. En el Von Crastenburg resolvemos las situaciones con diálogo. ¿Podemos hablar?",
                "⚖️ Detengámonos un segundo. El staff está disponible para mediar si es necesario. ¿Cómo puedo ayudar?",
            ]),
        }

    # Heurística: muchos mensajes cortos seguidos (posible acaloramiento)
    recientes = mensajes[-5:]
    if len(recientes) == 5 and all(len(m) < 30 for m in recientes):
        usuarios_unicos = len(set(recientes))  # aproximado
        if usuarios_unicos >= 2:
            return {
                "escalar": True,
                "mensaje": "🏨 ¡Atención! Recordad que el Von Crastenburg es un espacio de convivencia. Si hay algún problema, el staff puede mediar.",
            }

    return {"escalar": False, "mensaje": ""}
