from flask import Flask, request, jsonify
from threading import Thread
import asyncio
import json
import os
import discord

app  = Flask("")
_bot = None

HOTEL_DB_FILE = "hotel_db.json"

# ─── Rutas ────────────────────────────────────────────────

@app.route("/")
def home():
    return "🏨 VonStay Bot — Von Crastenburg Hotel RP — activo"

@app.route("/webhook/reserva", methods=["POST"])
def webhook_reserva():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Sin datos JSON"}), 400
    if not _bot or not _bot.loop:
        return jsonify({"error": "Bot no disponible aún"}), 503

    asyncio.run_coroutine_threadsafe(_enviar_dm_reserva(data), _bot.loop)
    return jsonify({"ok": True, "mensaje": "DM encolado"}), 200

# ─── Buscar usuario: primero por ID, luego por username en guilds ─

async def _buscar_usuario(data: dict):
    # Intenta por ID directo
    raw_id = data.get("discord_user_id") or data.get("user_id") or data.get("userId")
    if raw_id:
        try:
            return await _bot.fetch_user(int(raw_id))
        except Exception:
            pass

    # Intenta por username buscando en todos los guilds
    username = (
        data.get("discord_username") or
        data.get("usuario_discord")  or
        data.get("username")         or
        data.get("Usuario Discord")  or
        ""
    ).strip().lower()

    if not username:
        return None

    # Quitar discriminador si lo tiene (user#1234)
    base_name = username.split("#")[0]

    for guild in _bot.guilds:
        try:
            members = guild.members if guild.members else await guild.fetch_members(limit=None).flatten()
        except Exception:
            members = guild.members

        for m in members:
            if (
                m.name.lower() == base_name or
                m.display_name.lower() == base_name or
                str(m).lower() == username
            ):
                return m

    return None

# ─── DM de confirmación ───────────────────────────────────

async def _enviar_dm_reserva(data: dict):
    COLOR_DORADO = 0xD4AF37
    TIPOS = {
        "suite":            ("👑", "Suite Royal",      500),
        "suite royal":      ("👑", "Suite Royal",      500),
        "doble":            ("🛏️", "Habitación Doble", 200),
        "habitación doble": ("🛏️", "Habitación Doble", 200),
        "lujo":             ("💎", "Suite de Lujo",    350),
        "suite de lujo":    ("💎", "Suite de Lujo",    350),
    }
    try:
        user = await _buscar_usuario(data)
        if not user:
            print(f"[Webhook] Usuario no encontrado: {data}")
            return

        tipo_raw = str(data.get("tipo") or data.get("habitacion") or data.get("room_type") or "doble").lower()
        emoji, nombre_hab, precio = TIPOS.get(tipo_raw, ("🏨", tipo_raw.capitalize(), 0))

        codigo        = data.get("codigo")         or data.get("reserva_id") or data.get("id") or "N/A"
        fecha_entrada = data.get("fecha_entrada")  or data.get("fecha")      or data.get("check_in")  or "—"
        fecha_salida  = data.get("fecha_salida")   or data.get("check_out")  or "—"
        nombre        = data.get("nombre")         or data.get("nombre_rp")  or data.get("name") or getattr(user, "display_name", "—")
        personas      = data.get("personas")       or data.get("num_personas") or "1"

        e = discord.Embed(
            title="✨ Reserva Confirmada — Von Crastenburg",
            description=(
                f"Estimado/a **{nombre}**,\n"
                "su reserva ha sido recibida y está siendo procesada.\n"
                "*Su descanso es nuestro lujo.*"
            ),
            color=COLOR_DORADO,
        )
        e.add_field(name="🏷️ Código",             value=f"`{codigo}`",          inline=True)
        e.add_field(name=f"{emoji} Habitación",    value=nombre_hab,             inline=True)
        e.add_field(name="👥 Personas",            value=str(personas),          inline=True)
        e.add_field(name="📅 Entrada",             value=fecha_entrada,          inline=True)
        e.add_field(name="📅 Salida",              value=fecha_salida,           inline=True)
        if precio:
            e.add_field(name="💰 Precio",          value=f"{precio} €/noche",    inline=True)
        e.add_field(name="📋 Estado",              value="⏳ Pendiente de confirmación por staff", inline=False)
        e.add_field(
            name="🌐 Ver reserva",
            value="[Accede a la web](https://von-stay-luxe-revo-rp.base44.app/reservations)",
            inline=False,
        )
        e.set_footer(text="✨ VonStay • Von Crastenburg Hotel RP")
        e.set_thumbnail(url="attachment://logo_vc.png")

        await user.send(embed=e, file=discord.File("assets/logo_vc.png", filename="logo_vc.png"))
        print(f"[Webhook] ✅ DM enviado a {user} — reserva {codigo}")

    except discord.Forbidden:
        print(f"[Webhook] ⚠️ DMs desactivados para el usuario")
    except Exception as ex:
        print(f"[Webhook] ❌ Error: {ex}")

# ─── Búsqueda de rango/perfil por ID de Discord (para la web) ─

def _cargar_hotel_db() -> dict:
    if not os.path.exists(HOTEL_DB_FILE):
        return {}
    try:
        with open(HOTEL_DB_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


async def _buscar_perfil_por_id(discord_id: str) -> dict | None:
    """Busca a un miembro por ID de Discord en todos los servidores del bot
    y combina su información en vivo (nombre, roles) con su ficha del hotel (rango)."""
    if not _bot:
        return None

    miembro = None
    for guild in _bot.guilds:
        m = guild.get_member(int(discord_id))
        if m:
            miembro = m
            break

    if miembro is None:
        try:
            usuario = await _bot.fetch_user(int(discord_id))
        except Exception:
            return None
        if usuario is None:
            return None
        return {
            "found": True,
            "en_servidor": False,
            "discord_id": str(discord_id),
            "username": str(usuario),
            "display_name": usuario.display_name,
            "rango": None,
            "roles": [],
        }

    db     = _cargar_hotel_db()
    perfil = db.get(str(discord_id), {})

    return {
        "found": True,
        "en_servidor": True,
        "discord_id": str(discord_id),
        "username": str(miembro),
        "display_name": miembro.display_name,
        "rango": perfil.get("rango", "Visitante"),
        "roles": [r.name for r in miembro.roles if r.name != "@everyone"],
    }


@app.route("/api/discord_lookup/<discord_id>", methods=["GET"])
def discord_lookup(discord_id):
    """Endpoint para que la web VonStay busque el rango/perfil de un usuario
    a partir de su ID de Discord (para facilitar identificar el DM correcto al confirmar reservas).
    Requiere la cabecera 'api_key' con el mismo valor que BASE44_API_KEY."""
    api_key_esperada = os.getenv("BASE44_API_KEY", "")
    if not api_key_esperada:
        return jsonify({"error": "Endpoint no configurado (falta BASE44_API_KEY)"}), 503
    auth_header = request.headers.get("Authorization", "")
    recibida = (
        request.headers.get("X-Api-Key")
        or request.headers.get("api_key")
        or request.args.get("api_key")
        or (auth_header[7:] if auth_header.startswith("Bearer ") else None)
    )
    if recibida != api_key_esperada:
        return jsonify({"error": "No autorizado"}), 401

    if not discord_id.isdigit():
        return jsonify({"error": "discord_id inválido"}), 400
    if not _bot or not _bot.loop:
        return jsonify({"error": "Bot no disponible aún"}), 503

    try:
        future = asyncio.run_coroutine_threadsafe(_buscar_perfil_por_id(discord_id), _bot.loop)
        resultado = future.result(timeout=10)
    except Exception as ex:
        return jsonify({"error": f"Error buscando usuario: {ex}"}), 500

    if not resultado:
        return jsonify({"found": False, "discord_id": discord_id}), 404

    return jsonify(resultado), 200

# ─── Función pública para uso desde main.py ───────────────

async def enviar_dm_manual(bot, user_id: int, data: dict):
    global _bot
    _bot = bot
    await _enviar_dm_reserva({**data, "discord_user_id": str(user_id)})

# ─── Arranque ─────────────────────────────────────────────

def _run():
    app.run(host="0.0.0.0", port=8080)

def keep_alive(bot_instance):
    global _bot
    _bot = bot_instance
    t = Thread(target=_run, daemon=True)
    t.start()
