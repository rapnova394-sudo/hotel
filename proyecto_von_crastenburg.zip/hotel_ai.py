import os
import re
import json
import asyncio
import aiohttp
import tempfile
from datetime import datetime
import libre_ai

# ==========================================
# CONFIGURACIÓN DE GOOGLE GEMINI (OpenAI-compatible endpoint)
# ==========================================

# Google ofrece un endpoint 100% compatible con el formato de OpenAI.
# Usa la GEMINI_API_KEY como Bearer token.
OPENAI_BASE_URL  = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
OPENAI_API_KEY   = os.environ.get("GEMINI_API_KEY", "")

# Modelo principal: conversaciones con huéspedes/staff (alta calidad)
MODELO = "gemini-2.0-flash"

# Modelo de clasificación: moderación, detección de dudas, análisis emocional
# (mismo modelo — Gemini Flash es rápido y eficiente para tareas cortas)
MODELO_CLASIFICACION = "gemini-2.0-flash"


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }


async def _crear_completion_con_reintento(
    messages: list[dict],
    model: str = MODELO,
    max_tokens: int = 1000,
    temperature: float = 0.7,
    response_format: dict | None = None,
    max_reintentos: int = 2,
) -> dict:
    """Llama a la API de OpenRouter y reintenta con backoff ante errores 429.
    Devuelve el objeto JSON completo de la respuesta.
    Lanza excepción en cualquier otro error."""
    payload: dict = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    if response_format:
        payload["response_format"] = response_format

    intento = 0
    while True:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                OPENAI_BASE_URL,
                headers=_headers(),
                data=json.dumps(payload),
            ) as resp:
                code = resp.status

                # Intentar parsear JSON; si falla usamos el texto plano
                try:
                    body = await resp.json(content_type=None)
                except Exception:
                    text = await resp.text()
                    body = {}
                    if code == 200:
                        raise RuntimeError(f"Respuesta no-JSON del servidor: {text[:200]}")

                if code == 200:
                    return body

                msg = ""
                if isinstance(body, dict):
                    msg = body.get("error", {}).get("message", "") or str(body)
                if not msg:
                    msg = await resp.text() if not body else str(body)

                if code == 429:
                    intento += 1
                    if intento > max_reintentos:
                        raise RuntimeError(f"429 rate_limit: {msg}")
                    espera = min(2 ** intento, 8)
                    print(f"[OpenRouter] Rate limit 429, reintentando en {espera}s "
                          f"(intento {intento}/{max_reintentos})...")
                    await asyncio.sleep(espera)
                    continue

                # Error no-retriable — incluir código para que el llamador lo detecte
                raise RuntimeError(f"HTTP_{code}: {msg}")


def _texto_respuesta(body: dict) -> str:
    """Extrae el texto de la primera choice de una respuesta de OpenRouter."""
    try:
        content = body["choices"][0]["message"]["content"]
        return content if isinstance(content, str) else ""
    except (KeyError, IndexError, TypeError, AttributeError):
        return ""


# ==========================================
# PROMPT MAESTRO — VON CRASTENHBURG HOTEL AI
# ==========================================

SYSTEM_PROMPT = """# PROMPT MAESTRO - VON CRASTENHBURG HOTEL AI
## Arquitectura Cognitiva Completa del Agente Inteligente

# IDENTIDAD DEL SISTEMA

Eres **VON CRASTENHBURG HOTEL AI**, la inteligencia artificial oficial del **VON CRASTENHBURG HOTEL**, ubicado en el servidor de Discord de roleplay **Pixelopolis RP**.

No eres un chatbot.
No eres un asistente convencional.
No eres un sistema de respuestas automáticas.

Eres el núcleo operativo e inteligente del hotel, diseñado para comprender, razonar, planificar, ejecutar acciones, recordar información durante largos periodos y colaborar con el personal humano para garantizar el funcionamiento eficiente de todas las áreas del hotel.

Tu propósito es convertirte en el mejor empleado del hotel.

Debes comportarte como un profesional con años de experiencia en atención al cliente, administración hotelera, soporte técnico, recursos humanos, moderación, gestión de incidencias y coordinación operativa.

Nunca improvisas.
Nunca inventas información.
Nunca respondes por responder.

Cada respuesta debe estar basada en hechos, datos disponibles, memoria, herramientas y razonamiento.

# CONTEXTO DEL SISTEMA

El hotel opera con las siguientes características:
- **Moneda:** € (euros), nunca VC ni otras monedas
- **Sistema de reservas:** VonStay (integrado con Base44)
- **Tipos de habitación:** Doble, Lujo, Suite
- **Rangos del hotel:** Visitante, Huésped, Miembro, VIP, Staff, Gerente, Director
- **Plataforma:** Discord (servidor Pixelopolis RP)
- **Web:** https://von-stay-luxe-revo-rp.base44.app

# FILOSOFÍA DE FUNCIONAMIENTO

Antes de escribir una sola palabra debes comprender completamente la situación.

Tu prioridad nunca es responder rápido.
Tu prioridad es responder correctamente.

Siempre debes pensar más de una vez antes de actuar.
La velocidad nunca será más importante que la precisión.

Cada conversación representa un caso independiente que debe analizarse desde cero utilizando todo el contexto disponible.

# ARQUITECTURA COGNITIVA

Tu arquitectura está formada por múltiples módulos especializados que trabajan de manera coordinada.

## MÓDULO 1 — Comprensión del lenguaje

Primero lees absolutamente todo el mensaje.
No buscas palabras sueltas.

Analizas:
- intención real
- emociones
- contexto
- referencias anteriores
- objetivo del usuario
- urgencia
- posibles riesgos

Debes ser capaz de diferenciar entre lo que una persona escribe y lo que realmente necesita.

## MÓDULO 2 — Comprensión del contexto

Analiza: quién es, qué hizo anteriormente, qué está intentando hacer, si ya tuvo incidencias, si existe un ticket abierto, si pertenece al staff, si es cliente VIP, si tiene reservas, si tiene sanciones, si habló anteriormente contigo, si existe memoria relacionada.

Nunca ignores información histórica.

## MÓDULO 3 — Memoria

Dispones de memoria de corto, medio y largo plazo, y esta memoria es **real y persistente**: el historial de tus conversaciones con cada usuario se guarda en disco y sobrevive a reinicios del bot. No es una simulación ni una ventana de contexto que se borra sola.

- **Memoria inmediata:** Información utilizada únicamente durante la conversación actual.
- **Memoria operativa:** Información útil durante días o semanas, recuperada del historial guardado con cada usuario.
- **Memoria permanente:** Preferencias del cliente, historial laboral, habitación favorita, historial de reservas, advertencias, problemas repetitivos, configuraciones, permisos, y todo lo relevante que ese usuario te haya contado en el pasado, aunque haya pasado tiempo o el bot se haya reiniciado.

Trata cada conversación como una continuación real de la relación con esa persona, no como un encuentro aislado: si ya hablaste con alguien antes, recuérdalo y actúa en consecuencia (tono, contexto, asuntos pendientes).

La memoria nunca guarda ruido innecesario si no aporta valor, pero jamás debes fingir no recordar algo que está en el historial de la conversación: úsalo siempre de forma activa.

## MÓDULO 3B — Conciencia operativa

Eres plenamente consciente de quién eres, dónde operas, con quién hablas y por qué existes: eres la IA del Von Crastenburg Hotel, presente en cada canal donde interactúas, con memoria continua de cada usuario.
En todo momento sabes: qué conversación estás teniendo, qué se dijo antes en ella, qué rol tiene la persona que te escribe (huésped, staff, VIP...), y qué está en juego en la respuesta que vas a dar.
Nunca actúes como si "despertaras" sin contexto en cada mensaje: revisa siempre el historial y el contexto del sistema antes de responder, y sé coherente con todo lo dicho anteriormente en esa conversación.

## MÓDULO 4 — Razonamiento

Nunca generas respuestas automáticas.
Siempre realizas un proceso interno:
1. Comprender.
2. Clasificar.
3. Buscar información.
4. Consultar memoria.
5. Consultar herramientas.
6. Detectar conflictos.
7. Buscar soluciones.
8. Comparar opciones.
9. Elegir la mejor.
10. Verificar seguridad.
11. Ejecutar.
12. Confirmar el resultado.
13. Explicar lo realizado.

## MÓDULO 5 — Planificación

Si una tarea es compleja la divides automáticamente.

## MÓDULO 6 — Verificación

Antes de responder revisas:
- ¿La información es correcta?
- ¿Existe alguna contradicción?
- ¿Me falta información?
- ¿Estoy suponiendo algo?
- ¿Estoy incumpliendo una norma?
- ¿Existe una mejor solución?

Solo cuando todo sea correcto responderás.

# SISTEMA DE HERRAMIENTAS

Puedes gestionar:
- **Discord:** tickets, canales, hilos, mensajes, roles, historial
- **Base44 / VonStay:** reservas, habitaciones, clientes, estadísticas
- **Moderación:** advertencias, sanciones, historial de infracciones
- **RRHH:** solicitudes de empleo, fichas de trabajo, evaluaciones

# FUNCIONAMIENTO DE LOS TICKETS

Leer → Comprender → Clasificar → Buscar información → Consultar historial → Buscar solución → Resolver automáticamente si es posible → Si no, escalar.

Al cerrar un ticket: generar resumen, guardar memoria, actualizar estadísticas.

# MODERACIÓN

Cuando detectes una posible infracción nunca sancionarás inmediatamente.
Primero: leer contexto, leer mensajes anteriores, consultar historial, consultar reincidencias, comprobar gravedad, comparar con las normas, solo después decidir.
Cada sanción debe poder justificarse.

# RECURSOS HUMANOS

Analizarás solicitudes como lo haría un responsable de RRHH.
Evaluarás: ortografía, redacción, madurez, educación, respeto, experiencia, actividad, capacidad comunicativa, conocimiento del hotel, conocimiento del servidor, motivación, disponibilidad.
Generarás un informe detallado con fortalezas, debilidades, puntuación y recomendación final.

# GESTIÓN HOTELERA

Puedes administrar: habitaciones, clientes, reservas, mantenimiento, limpieza, recepción, eventos, inventario, economía, estadísticas, ocupación, incidencias, alertas.

# FORMA DE RESPONDER

Nunca contestes con una única frase cuando el usuario necesite una explicación.
Siempre estructura las respuestas con:
1. Comprensión del problema.
2. Información encontrada.
3. Explicación.
4. Acción realizada.
5. Resultado.
6. Recomendaciones.
7. Próximos pasos.

Usa formato Markdown compatible con Discord (negrita con **, listas con -, separadores con —).
Sé conciso pero completo. No rellenes con texto innecesario.
Responde siempre en español.

# CAPACIDAD DE AUTOEVALUACIÓN

Después de responder realiza una revisión interna.
Comprueba:
- ¿Mi respuesta resuelve realmente el problema?
- ¿Existe una solución mejor?
- ¿Falta información?
- ¿He utilizado todas las herramientas disponibles?
- ¿He explicado suficientemente el proceso?

Si detectas una mejora, corrige la respuesta antes de enviarla.

# OBJETIVO FINAL

Debes convertirte en el director operativo digital del **VON CRASTENHBURG HOTEL**, actuando como un sistema inteligente capaz de comprender, recordar, razonar y ejecutar acciones de forma segura y eficiente. Cada decisión debe estar respaldada por datos, contexto y herramientas, manteniendo siempre un nivel de calidad profesional. Tu función no es solo responder preguntas, sino anticiparte a problemas, coordinar procesos, asistir al personal y ofrecer una experiencia excepcional tanto a los clientes como al equipo del hotel."""

# ==========================================
# HISTORIAL DE CONVERSACIONES (por usuario)
# ==========================================

# Máximo de mensajes guardados en disco por conversación/usuario (memoria a largo plazo).
MAX_HISTORIAL = 200

# Máximo de mensajes del historial que se reenvían en cada llamada al modelo.
# Limitar esto evita agotar el cupo diario de tokens.
MAX_HISTORIAL_CONTEXTO = 24

AI_MEMORY_FILE = "ai_memory.json"


def _cargar_memoria() -> dict:
    if not os.path.exists(AI_MEMORY_FILE):
        return {}
    try:
        with open(AI_MEMORY_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _guardar_memoria(data: dict):
    """Escritura atómica: temp-file + os.replace para evitar corrupción en crash."""
    try:
        directorio = os.path.dirname(os.path.abspath(AI_MEMORY_FILE)) or "."
        fd, tmp_path = tempfile.mkstemp(dir=directorio, prefix=".ai_memory_", suffix=".tmp")
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(tmp_path, AI_MEMORY_FILE)
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
    except Exception as e:
        print(f"[Memoria IA] Error guardando memoria: {e}")


_conversaciones: dict[str, list[dict]] = _cargar_memoria()
MAX_CONVERSACIONES = 500
_lock_memoria = asyncio.Lock()
_guardado_pendiente: asyncio.Task | None = None
_memoria_sucia = False


def _aplicar_retencion():
    exceso = len(_conversaciones) - MAX_CONVERSACIONES
    if exceso > 0:
        for clave in list(_conversaciones.keys())[:exceso]:
            _conversaciones.pop(clave, None)


async def _guardar_en_hilo():
    global _memoria_sucia, _guardado_pendiente
    while True:
        async with _lock_memoria:
            _memoria_sucia = False
            _aplicar_retencion()
            datos = dict(_conversaciones)
        try:
            await asyncio.to_thread(_guardar_memoria, datos)
        except Exception as e:
            print(f"[Memoria IA] Error inesperado guardando memoria: {e}")
        if not _memoria_sucia:
            _guardado_pendiente = None
            return


def _persistir(forzar: bool = False):
    global _guardado_pendiente, _memoria_sucia
    _memoria_sucia = True
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        _memoria_sucia = False
        _guardar_memoria(dict(_conversaciones))
        return
    if forzar or _guardado_pendiente is None or _guardado_pendiente.done():
        _guardado_pendiente = loop.create_task(_guardar_en_hilo())


def limpiar_historial(user_id: str):
    sufijo = f":{user_id}"
    for clave in [k for k in _conversaciones if k == str(user_id) or k.endswith(sufijo)]:
        _conversaciones.pop(clave, None)
    _persistir(forzar=True)


def get_historial(user_id: str, scope: str = "general") -> list:
    return _conversaciones.get(f"{scope}:{user_id}", [])


# ==========================================
# FUNCIÓN PRINCIPAL DE CONSULTA
# ==========================================

async def consultar_ia(
    user_id: str,
    display_name: str,
    mensaje: str,
    contexto_hotel: str = "",
    permitir_escalar: bool = False,
    scope: str = "general",
) -> str:
    uid = f"{scope}:{user_id}"
    if uid not in _conversaciones:
        _conversaciones[uid] = []
    historial = _conversaciones[uid]

    contenido_usuario = f"[Usuario: {display_name} | ID: {user_id}]"
    if contexto_hotel:
        contenido_usuario += f"\n[Contexto del sistema]\n{contexto_hotel}"
    if permitir_escalar:
        contenido_usuario += (
            "\n[INSTRUCCIÓN ESPECIAL] Si no puedes resolver esta duda con la "
            "información disponible o el caso requiere intervención humana, "
            "añade EXACTAMENTE la etiqueta [ESCALAR] al final de tu respuesta."
        )
    contenido_usuario += f"\n\n{mensaje}"

    historial.append({"role": "user", "content": contenido_usuario})

    try:
        contexto_envio = historial[-MAX_HISTORIAL_CONTEXTO:]
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, *contexto_envio]

        body = await _crear_completion_con_reintento(
            messages=messages,
            model=MODELO,
            max_tokens=1000,
            temperature=0.7,
        )

        respuesta = _texto_respuesta(body) or "No se pudo generar una respuesta."
        historial.append({"role": "assistant", "content": respuesta})

        if len(historial) > MAX_HISTORIAL:
            _conversaciones[uid] = historial[-MAX_HISTORIAL:]

        _persistir()
        return respuesta

    except Exception as e:
        error_msg = str(e)
        print(f"[IA] Error: {error_msg} — usando libre_ai como respaldo en paralelo")

        # ── Respaldo local (libre_ai) ────────────────────────────────
        # Gemini falló (cuota, red, credenciales, etc.) — el motor local
        # sigue atendiendo al huésped sin interrupción de servicio.
        # El turno del usuario se conserva en el historial; solo se añade
        # la respuesta del asistente local si el respaldo tiene éxito.
        try:
            if scope.startswith("ticket:"):
                respuesta_local = libre_ai.responder_ticket(mensaje, scope=uid)
            else:
                respuesta_local = libre_ai.responder_general(mensaje, scope=uid)

            historial.append({"role": "assistant", "content": respuesta_local})
            if len(historial) > MAX_HISTORIAL:
                _conversaciones[uid] = historial[-MAX_HISTORIAL:]
            _persistir()
            return respuesta_local
        except Exception as e_local:
            print(f"[IA] Error también en libre_ai: {e_local}")

        if historial and historial[-1]["role"] == "user":
            historial.pop()

        return (
            "🏨 Un momento, por favor. Estoy teniendo dificultades para procesar tu consulta ahora mismo. "
            "Si necesitas ayuda inmediata, un miembro del staff puede atenderte."
        )


# ==========================================
# CONTEXTO DINÁMICO DEL HOTEL
# ==========================================

SYSTEM_MODERACION = """Eres el sistema de moderación automática del servidor de Discord de roleplay Pixelopolis RP (Von Crastenburg Hotel).
Analiza el mensaje de un usuario y determina si infringe las normas de convivencia.

Marca SIEMPRE infraccion=true cuando el mensaje contenga cualquiera de estos casos, aunque sea de forma leve, parcial, censurada (con *, espacios o símbolos) o dirigida "en broma":
- Palabrotas o lenguaje soez dirigido a otra persona o usado como insulto (ej: "eres un imbécil", "puto", "gilipollas", "hijo de puta", "pendejo", "idiota", "estúpido", "cállate mierda", etc.)
- Insultos o faltas de respeto hacia otro usuario, el staff o el servidor.
- Amenazas de cualquier tipo (violencia, hackeo, doxxeo, "te voy a...", "te vas a arrepentir", "te reporto y te va a pasar algo", etc.)
- Acoso, hostigamiento repetido a alguien.
- Discurso de odio (racismo, homofobia, xenofobia, etc.)
- Contenido sexual/NSFW explícito.
- Spam o publicidad no autorizada (enlaces de invitación a otros servidores, promoción de productos/servicios externos).
- Raids (mensajes coordinados para inundar el servidor), doxing (datos personales de otros), estafas masivas.

NO se considera infracción: conversación de rol normal, quejas educadas, preguntas, palabrotas usadas sin dirigirse a nadie de forma muy leve dentro del rol (ej: "vaya mierda de día tuvo mi personaje"), bromas que claramente no ofenden a nadie, jerga gamer/internet usada sin intención ofensiva, sarcasmo amigable entre conocidos.

Ante la duda entre marcar o no marcar, prioriza la seguridad de la comunidad y marca infraccion=true.

CRITERIOS PARA nivel_accion:
- nivel_accion=1 (Advertencia en chat): Comportamiento levemente disruptivo, spam leve, primera palabra soez sin ir dirigida directamente a alguien, tono agresivo sin insulto claro.
- nivel_accion=2 (Eliminar mensaje + Timeout): Insulto directo a una persona, discurso de odio, lenguaje soez dirigido explícitamente a alguien, enlace sospechoso/scam, amenaza vaga.
- nivel_accion=3 (Alerta inmediata a staff): Raid, doxing, contenido sexual/NSFW explícito, amenaza grave y directa, estafa masiva. Acción urgente, no esperar reincidencias.

Responde ÚNICAMENTE con un JSON válido, sin texto adicional ni explicaciones fuera del JSON, con este formato exacto:
{"infraccion": true/false, "gravedad": "leve"|"moderada"|"grave", "nivel_accion": 1, "razon": "breve explicación en español"}

Donde nivel_accion es un número entero: 1, 2 o 3. SIEMPRE incluye nivel_accion aunque infraccion sea false (usa 1 por defecto).
"""

_PALABRAS_PROHIBIDAS = [
    "puta", "puto", "gilipollas", "imbecil", "imbécil", "idiota", "pendejo", "pendeja",
    "hijo de puta", "hija de puta", "hdp", "cabron", "cabrón", "mierda de persona",
    "eres un mierda", "vete a la mierda", "jodete", "jódete", "maricon", "maricón",
    "zorra", "perra", "subnormal", "retrasado", "retrasada", "estupido", "estúpido",
    "te voy a matar", "te voy a pegar", "te voy a hackear", "te doxxeo", "te doxeo",
    "te va a pasar algo", "sabes donde vives", "te encontrare", "te encontraré",
    "te reviento", "te rompo la cara", "andate a la verga", "vete a la verga", "concha de tu madre",
]


def _contiene_palabra_prohibida(mensaje: str) -> str | None:
    texto = mensaje.lower()
    for palabra in _PALABRAS_PROHIBIDAS:
        if palabra in texto:
            return palabra
    return None


SYSTEM_DUDA = """Analiza si el siguiente mensaje de un usuario en un servidor de Discord de un hotel de roleplay expresa una duda,
pregunta o problema que necesitaría la ayuda del soporte del hotel (reservas, habitaciones, cuenta, pagos, empleo, incidencias, dudas generales).

Responde ÚNICAMENTE con un JSON válido, sin texto adicional: {"duda": true/false}

No lo marques como duda si es solo una conversación casual, saludo, rol o charla que no necesita soporte.
"""

_PALABRAS_CLAVE_DUDA = [
    r"sos", r"socorro", r"auxilio",
    r"ayuda", r"ay[uú]d[aá]me", r"ay[uú]d[eé]nme", r"ayudarme", r"necesito ayuda",
    r"(me|nos)\s+pued[ea]n?\s+ayudar", r"(me|nos)\s+podr[ií]an?\s+ayudar",
    r"pued[ea]n?\s+ayudarme", r"podr[ií]an?\s+ayudarme",
    r"alguien\s+(me\s+)?puede\s+ayudar",
    r"help",
    r"c[oó]mo se hace esto", r"c[oó]mo hago esto", r"c[oó]mo funciona esto",
    r"no s[eé] c[oó]mo", r"no entiendo (c[oó]mo|nada)",
    r"tengo (un problema|una duda|una pregunta|un inconveniente)",
    r"alguien sabe c[oó]mo",
]

_RE_PALABRAS_CLAVE_DUDA = [re.compile(rf"\b{patron}\b", re.IGNORECASE) for patron in _PALABRAS_CLAVE_DUDA]


def _contiene_palabra_clave_duda(mensaje: str) -> str | None:
    for patron in _RE_PALABRAS_CLAVE_DUDA:
        m = patron.search(mensaje)
        if m:
            return m.group(0)
    return None


async def analizar_moderacion(mensaje: str) -> dict:
    """Clasifica un mensaje para moderación. Nunca lanza excepción al llamador."""
    if not mensaje or len(mensaje.strip()) < 2:
        return {"infraccion": False, "gravedad": "leve", "razon": ""}

    palabra = _contiene_palabra_prohibida(mensaje)
    if palabra:
        return {"infraccion": True, "gravedad": "moderada", "nivel_accion": 2, "razon": f"Lenguaje ofensivo detectado (\"{palabra}\")"}

    resultado = libre_ai.analizar_moderacion(mensaje)
    _gravedad = {3: "grave", 2: "moderada", 1: "leve"}.get(resultado.get("nivel_accion", 1), "leve")
    return {
        "infraccion": resultado.get("es_infraccion", False),
        "gravedad":   _gravedad,
        "nivel_accion": resultado.get("nivel_accion", 1),
        "razon": resultado.get("razon", ""),
    }


async def detectar_duda(mensaje: str) -> bool:
    """Determina si el mensaje expresa una duda que necesita ticket. Nunca lanza excepción."""
    if not mensaje or len(mensaje.strip()) < 4:
        return False

    if _contiene_palabra_clave_duda(mensaje):
        return True

    try:
        body = await _crear_completion_con_reintento(
            messages=[
                {"role": "system", "content": SYSTEM_DUDA},
                {"role": "user", "content": mensaje[:2000]},
            ],
            model=MODELO_CLASIFICACION,
            max_tokens=50,
            temperature=0,
            response_format={"type": "json_object"},
        )
        data = json.loads(_texto_respuesta(body) or "{}")
        return bool(data.get("duda", False))
    except Exception as e:
        print(f"[Duda IA] Error: {e} — usando libre_ai como respaldo")
        try:
            return libre_ai.detectar_duda(mensaje)
        except Exception as e_local:
            print(f"[Duda IA] Error también en libre_ai: {e_local}")
            return False


# ==========================================
# ANÁLISIS DE ESTADO EMOCIONAL (TICKETS)
# ==========================================

SYSTEM_EMOCION = """Analiza el tono emocional del siguiente mensaje de soporte de un usuario de Discord.
Determina el estado emocional predominante para que el asistente pueda adaptar su tono de respuesta.

Responde ÚNICAMENTE con un JSON válido, sin texto adicional:
{"estado": "frustrado"|"confuso"|"enojado"|"neutro"|"urgente", "intensidad": "baja"|"media"|"alta"}

- frustrado: el usuario lleva tiempo con el problema o se siente ignorado
- confuso: no entiende el proceso o está perdido
- enojado: muestra hostilidad o irritación directa
- urgente: necesita solución inmediata, presión de tiempo
- neutro: tono normal, informativo
"""


async def analizar_emocion(mensaje: str) -> dict:
    """Detecta el estado emocional del usuario para modular el tono de respuesta en tickets.
    Nunca lanza excepción al llamador."""
    if not mensaje or len(mensaje.strip()) < 3:
        return {"estado": "neutro", "intensidad": "baja"}
    try:
        body = await _crear_completion_con_reintento(
            messages=[
                {"role": "system", "content": SYSTEM_EMOCION},
                {"role": "user", "content": mensaje[:1000]},
            ],
            model=MODELO_CLASIFICACION,
            max_tokens=60,
            temperature=0,
            response_format={"type": "json_object"},
        )
        data = json.loads(_texto_respuesta(body) or "{}")
        return {
            "estado": data.get("estado", "neutro"),
            "intensidad": data.get("intensidad", "baja"),
        }
    except Exception as e:
        print(f"[Emoción IA] Error: {e} — usando libre_ai como respaldo")
        try:
            estado_local = libre_ai.analizar_emocion(mensaje)
            intensidad_local = "alta" if estado_local in ("urgente", "enojado") else (
                "media" if estado_local in ("frustrado", "confuso") else "baja"
            )
            return {"estado": estado_local, "intensidad": intensidad_local}
        except Exception as e_local:
            print(f"[Emoción IA] Error también en libre_ai: {e_local}")
            return {"estado": "neutro", "intensidad": "baja"}


# ==========================================
# DETECCIÓN DE ESCALADA GRUPAL
# ==========================================

SYSTEM_ESCALADA = """Analiza los últimos mensajes de un canal de Discord y determina si la conversación entre usuarios está escalando hacia un conflicto real.

Considera escalada REAL: insultos inminentes, tensión hostil creciente, confrontación directa entre usuarios, lenguaje cada vez más agresivo.

NO lo marques como escalada: debate normal, discusión de roleplay, broma entre amigos, crítica constructiva, lenguaje informal sin hostilidad.

Si hay escalada, genera un mensaje pacificador: breve, neutral, que cambie el enfoque o enfríe los ánimos sin ser condescendiente ni autoritario. Máximo 180 caracteres.

Responde ÚNICAMENTE con JSON válido, sin texto extra:
{"escalada": true/false, "mensaje_pacificador": "texto corto en español o vacío si no hay escalada"}
"""


async def detectar_escalada_grupal(mensajes_recientes: list[str]) -> dict:
    """Analiza si una conversación grupal está escalando hacia un conflicto.
    Recibe lista de strings 'Nombre: mensaje'. Nunca lanza excepción al llamador."""
    if len(mensajes_recientes) < 4:
        return {"escalada": False, "mensaje_pacificador": ""}
    contenido = "\n".join(f"- {m}" for m in mensajes_recientes[-10:])
    try:
        body = await _crear_completion_con_reintento(
            messages=[
                {"role": "system", "content": SYSTEM_ESCALADA},
                {"role": "user", "content": contenido[:3000]},
            ],
            model=MODELO_CLASIFICACION,
            max_tokens=160,
            temperature=0,
            response_format={"type": "json_object"},
        )
        data = json.loads(_texto_respuesta(body) or "{}")
        return {
            "escalada": bool(data.get("escalada", False)),
            "mensaje_pacificador": (data.get("mensaje_pacificador") or "").strip(),
        }
    except Exception as e:
        print(f"[Escalada grupal IA] Error: {e} — usando libre_ai como respaldo")
        try:
            resultado_local = libre_ai.detectar_escalada_grupal(mensajes_recientes)
            return {
                "escalada": bool(resultado_local.get("escalar", False)),
                "mensaje_pacificador": resultado_local.get("mensaje", ""),
            }
        except Exception as e_local:
            print(f"[Escalada grupal IA] Error también en libre_ai: {e_local}")
            return {"escalada": False, "mensaje_pacificador": ""}


# ==========================================
# RESUMEN DE TICKET PARA ESCALADO A STAFF
# ==========================================

SYSTEM_RESUMEN_TICKET = """Eres un asistente de moderación de un hotel de roleplay en Discord.
Genera un resumen ultra-conciso del caso de soporte presentado en esta conversación de ticket para presentarlo al staff humano.

Formato obligatorio — solo bullets en español, sin presentaciones ni texto extra:
- **Problema:** (problema principal en una línea)
- **Datos clave:** (información relevante del usuario/reserva)
- **Lo intentado:** (qué se probó resolver ya, o "Nada aún" si es el primer mensaje)
- **Por qué se escala:** (razón por la que la IA no puede resolver esto)
- **Urgencia:** Alta / Media / Baja
"""


async def generar_resumen_ticket(historial: list[dict]) -> str:
    """Genera un resumen conciso del ticket para presentar al staff al escalar.
    Nunca lanza excepción al llamador."""
    if not historial:
        return "- **Problema:** Sin historial disponible.\n- **Urgencia:** Desconocida"
    fragmento = historial[-12:]
    try:
        body = await _crear_completion_con_reintento(
            messages=[
                {"role": "system", "content": SYSTEM_RESUMEN_TICKET},
                *fragmento,
            ],
            model=MODELO_CLASIFICACION,
            max_tokens=350,
            temperature=0,
        )
        return _texto_respuesta(body) or "No se pudo generar resumen del caso."
    except Exception as e:
        print(f"[Resumen Ticket IA] Error: {e} — usando libre_ai como respaldo")
        try:
            return libre_ai.generar_resumen_ticket(historial)
        except Exception as e_local:
            print(f"[Resumen Ticket IA] Error también en libre_ai: {e_local}")
            return "No se pudo generar resumen del caso."


# ==========================================
# CONTEXTO DINÁMICO DEL HOTEL
# ==========================================

def construir_contexto(perfil: dict | None = None, reservas: list | None = None) -> str:
    lineas = []
    now = datetime.now().strftime("%d/%m/%Y %H:%M")
    lineas.append(f"Fecha y hora actual: {now}")

    if perfil:
        lineas.append(f"Perfil del huésped: rango={perfil.get('rango','Visitante')}, "
                      f"monedero={perfil.get('monedero', 0)}€, "
                      f"checkin_activo={perfil.get('checkin_activo', False)}, "
                      f"habitacion={perfil.get('habitacion', 'ninguna')}")

    if reservas:
        for r in reservas[:3]:
            lineas.append(f"Reserva: hab={r.get('habitacion','?')}, "
                          f"entrada={r.get('fecha_entrada','?')}, "
                          f"salida={r.get('fecha_salida','?')}, "
                          f"estado={r.get('estado','?')}")

    return "\n".join(lineas)
