"""
Módulo de integración con la API REST de Base44.
Base URL: https://von-stay-luxe-revo-rp.base44.app/api
"""

import os
import json
import aiohttp

BASE_URL = "https://von-stay-luxe-revo-rp.base44.app/api"
_API_KEY  = os.getenv("BASE44_API_KEY", "")

# ─── Agente personal Base44 (notificaciones de tickets) ────
_AGENT_API_KEY = os.getenv("BASE44_AGENT_API_KEY", "")
_AGENT_URL = "https://app.base44.com/api/agents/6a4fd6f031dfc22f20a2071c/conversations/6a4fd6f3110fe595b95a938a/messages"

# Mapeo tipos del bot → tipos de Base44
BOT_TO_B44 = {
    "doble": "standard",
    "lujo":  "deluxe",
    "suite": "vip_suite",
}

def _headers():
    return {"api_key": _API_KEY, "Content-Type": "application/json"}

TIMEOUT = aiohttp.ClientTimeout(total=8)

# ─── Helpers genéricos ────────────────────────────────────

async def _get(path: str, params: dict | None = None):
    try:
        async with aiohttp.ClientSession(headers=_headers(), timeout=TIMEOUT) as s:
            async with s.get(f"{BASE_URL}{path}", params=params) as r:
                if r.status == 200:
                    return await r.json()
    except Exception as ex:
        print(f"[Base44 GET {path}] {ex}")
    return None

async def _post(path: str, payload: dict):
    try:
        async with aiohttp.ClientSession(headers=_headers(), timeout=TIMEOUT) as s:
            async with s.post(f"{BASE_URL}{path}", json=payload) as r:
                if r.status in (200, 201):
                    return await r.json()
    except Exception as ex:
        print(f"[Base44 POST {path}] {ex}")
    return None

async def _put(path: str, payload: dict):
    try:
        async with aiohttp.ClientSession(headers=_headers(), timeout=TIMEOUT) as s:
            async with s.put(f"{BASE_URL}{path}", json=payload) as r:
                if r.status == 200:
                    return await r.json()
    except Exception as ex:
        print(f"[Base44 PUT {path}] {ex}")
    return None

# ─── Rooms ────────────────────────────────────────────────

async def get_all_rooms(limit: int = 50) -> list:
    """Devuelve todas las habitaciones del hotel."""
    data = await _get("/entities/Room", {"limit": limit, "sort_by": "room_number"})
    if isinstance(data, list):
        return data
    return []

async def get_available_room(bot_tipo: str) -> dict | None:
    """Devuelve la primera habitación disponible del tipo indicado."""
    b44_type = BOT_TO_B44.get(bot_tipo, bot_tipo)
    params = {
        "q":        json.dumps({"type": b44_type, "status": "available"}),
        "limit":    1,
        "sort_by":  "room_number",
    }
    data = await _get("/entities/Room", params)
    if isinstance(data, list) and data:
        return data[0]
    return None

async def update_room_status(room_id: str, status: str, assigned_guest: str = ""):
    """Actualiza el estado de una habitación. Status: available/reserved/occupied/cleaning/maintenance."""
    payload: dict = {"status": status}
    if assigned_guest:
        payload["assigned_guest"] = assigned_guest
    elif status == "available":
        payload["assigned_guest"] = ""
    return await _put(f"/entities/Room/{room_id}", payload)

# ─── Reservations ─────────────────────────────────────────

async def create_reservation(data: dict) -> dict | None:
    """Crea un registro Reservation en Base44."""
    return await _post("/entities/Reservation", data)

async def get_reservations(status: str | None = None, limit: int = 50) -> list:
    params = {"limit": limit, "sort_by": "-created_date"}
    if status:
        params["q"] = json.dumps({"status": status})
    data = await _get("/entities/Reservation", params)
    if isinstance(data, list):
        return data
    return []

async def update_reservation(reservation_id: str, fields: dict):
    return await _put(f"/entities/Reservation/{reservation_id}", fields)

# ─── Guests ───────────────────────────────────────────────

async def get_guests(limit: int = 200) -> list:
    data = await _get("/entities/Guest", {"limit": limit})
    if isinstance(data, list):
        return data
    return []

async def get_guest_by_discord_user(discord_user: str) -> dict | None:
    guests = await _get("/entities/Guest", {"q": json.dumps({"username": discord_user.split("#")[0]}), "limit": 5})
    if isinstance(guests, list) and guests:
        return guests[0]
    return None

async def get_guest_by_rp_name(rp_name: str) -> dict | None:
    guests = await _get("/entities/Guest", {"q": json.dumps({"rp_name": rp_name}), "limit": 5})
    if isinstance(guests, list) and guests:
        return guests[0]
    return None

# ─── BotLog ───────────────────────────────────────────────

VALID_TYPES = {
    "checkin", "checkout", "reservation", "job_accepted",
    "job_rejected", "room_call", "no_molestar", "relocation",
    "reminder_checkin", "reminder_checkout",
}

async def botlog(
    tipo: str,
    rp_name: str,
    discord_user: str = "",
    message_preview: str = "",
    status: str = "sent",
    extra: str = "",
):
    if tipo not in VALID_TYPES:
        tipo = "reservation"
    return await _post("/entities/BotLog", {
        "type":            tipo,
        "rp_name":         rp_name,
        "discord_user":    discord_user,
        "message_preview": message_preview[:200] if message_preview else "",
        "status":          status,
        "extra":           extra,
    })

# ─── JobApplications ─────────────────────────────────────

async def get_job_applications(status: str | None = None, limit: int = 50) -> list:
    params = {"limit": limit, "sort_by": "-created_date"}
    if status:
        params["q"] = json.dumps({"status": status})
    data = await _get("/entities/JobApplication", params)
    if isinstance(data, list):
        return data
    return []

async def update_job_application(app_id: str, fields: dict):
    return await _put(f"/entities/JobApplication/{app_id}", fields)

# ─── Notifications ────────────────────────────────────────

async def create_notification(title: str, message: str, tipo: str = "general", link: str = "") -> dict | None:
    """Crea una Notification. tipo: reservation/status_change/vip_alert/event/general."""
    payload = {"title": title, "message": message, "type": tipo, "read": False}
    if link:
        payload["link"] = link
    return await _post("/entities/Notification", payload)

async def get_notifications(read: bool | None = None, limit: int = 50) -> list:
    params = {"limit": limit, "sort_by": "-created_date"}
    if read is not None:
        params["q"] = json.dumps({"read": read})
    data = await _get("/entities/Notification", params)
    if isinstance(data, list):
        return data
    return []

async def mark_notification_read(notification_id: str):
    return await _put(f"/entities/Notification/{notification_id}", {"read": True})

# ─── StaffMembers ─────────────────────────────────────────

async def get_staff_members(status: str | None = None, limit: int = 100) -> list:
    """status: active/inactive/on_leave"""
    params = {"limit": limit}
    if status:
        params["q"] = json.dumps({"status": status})
    data = await _get("/entities/StaffMember", params)
    if isinstance(data, list):
        return data
    return []

async def get_staff_member_by_discord(discord_user: str) -> dict | None:
    data = await _get("/entities/StaffMember", {"q": json.dumps({"discord": discord_user}), "limit": 5})
    if isinstance(data, list) and data:
        return data[0]
    return None

async def update_staff_member(staff_id: str, fields: dict):
    return await _put(f"/entities/StaffMember/{staff_id}", fields)

# ─── ContactMessages ──────────────────────────────────────

async def create_contact_message(name: str, message: str, discord_user: str = "", subject: str = "") -> dict | None:
    payload = {"name": name, "message": message}
    if discord_user:
        payload["discord"] = discord_user
    if subject:
        payload["subject"] = subject
    return await _post("/entities/ContactMessage", payload)

async def get_contact_messages(read: bool | None = None, limit: int = 50) -> list:
    params = {"limit": limit, "sort_by": "-created_date"}
    if read is not None:
        params["q"] = json.dumps({"read": read})
    data = await _get("/entities/ContactMessage", params)
    if isinstance(data, list):
        return data
    return []

# ─── HotelEvents ──────────────────────────────────────────

async def get_hotel_events(status: str | None = None, limit: int = 50) -> list:
    """status: upcoming/active/completed/cancelled"""
    params = {"limit": limit, "sort_by": "date"}
    if status:
        params["q"] = json.dumps({"status": status})
    data = await _get("/entities/HotelEvent", params)
    if isinstance(data, list):
        return data
    return []

async def create_hotel_event(title: str, date: str, tipo: str, **extra) -> dict | None:
    """tipo: private_party/business_meeting/vip_event/social_event"""
    payload = {"title": title, "date": date, "type": tipo, **extra}
    return await _post("/entities/HotelEvent", payload)

async def update_hotel_event(event_id: str, fields: dict):
    return await _put(f"/entities/HotelEvent/{event_id}", fields)

# ─── MenuItems ────────────────────────────────────────────

async def get_menu_items(category: str | None = None, only_available: bool = False, limit: int = 100) -> list:
    """category: food/drinks/services"""
    q: dict = {}
    if category:
        q["category"] = category
    if only_available:
        q["is_available"] = True
    params = {"limit": limit}
    if q:
        params["q"] = json.dumps(q)
    data = await _get("/entities/MenuItem", params)
    if isinstance(data, list):
        return data
    return []

# ─── ActivityLog ──────────────────────────────────────────

VALID_ACTIVITY_TYPES = {
    "create", "update", "delete", "login", "logout",
    "status_change", "reservation", "checkin", "checkout", "system",
}

async def log_activity(
    action_type: str,
    description: str,
    performed_by: str = "",
    entity_type: str = "",
    details: str = "",
) -> dict | None:
    if action_type not in VALID_ACTIVITY_TYPES:
        action_type = "system"
    payload = {"action_type": action_type, "description": description}
    if performed_by:
        payload["performed_by"] = performed_by
    if entity_type:
        payload["entity_type"] = entity_type
    if details:
        payload["details"] = details
    return await _post("/entities/ActivityLog", payload)

async def get_activity_log(limit: int = 50) -> list:
    data = await _get("/entities/ActivityLog", {"limit": limit, "sort_by": "-created_date"})
    if isinstance(data, list):
        return data
    return []

# ─── Agente personal Base44 ───────────────────────────────

async def notify_agent(content: str) -> bool:
    """Envía un mensaje a la conversación del agente personal de Base44.
    Se usa, por ejemplo, para avisar cada vez que se abre un ticket.
    No lanza excepciones: si falla, solo lo registra en consola."""
    if not _AGENT_API_KEY:
        print("[Base44 Agente] BASE44_AGENT_API_KEY no configurada, no se notifica.")
        return False
    headers = {"api_key": _AGENT_API_KEY, "Content-Type": "application/json"}
    payload = {"role": "user", "content": content}
    try:
        async with aiohttp.ClientSession(headers=headers, timeout=TIMEOUT) as s:
            async with s.post(_AGENT_URL, json=payload) as r:
                if r.status in (200, 201):
                    return True
                print(f"[Base44 Agente] Respuesta inesperada {r.status}: {await r.text()}")
    except Exception as ex:
        print(f"[Base44 Agente] Error notificando: {ex}")
    return False
